// ═══════════════════════════════════════════════
// strategy.js — 進場閘門 + 出場決策 + RugCheck 安全檢查
// ═══════════════════════════════════════════════

// ── RugCheck 安全閘門 ──
export async function rugGate(mint, cfg) {
  if (!cfg.enabled) return { pass: true, reason: "rugcheck 停用" };
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 12000);
    const r = await fetch("https://api.rugcheck.xyz/v1/tokens/" + mint + "/report", { signal: ctrl.signal });
    clearTimeout(t);
    if (!r.ok) return { pass: false, reason: "rugcheck 無回應(HTTP " + r.status + ")，保守拒絕" };
    const d = await r.json();
    const risks = Array.isArray(d.risks) ? d.risks : [];
    const dangers = risks.filter(x => (x.level || "").toLowerCase() === "danger");
    if (dangers.length > cfg.maxDangerRisks) {
      return { pass: false, reason: "高危風險 " + dangers.length + " 項: " + dangers.map(x => x.name).join(", ") };
    }
    const th = Array.isArray(d.topHolders) ? d.topHolders : [];
    if (th.length) {
      const top10 = th.slice(0, 10).reduce((a, h) => a + (parseFloat(h.pct) || 0), 0);
      if (top10 > cfg.maxTop10HolderPct) {
        return { pass: false, reason: "前10大持倉 " + top10.toFixed(1) + "% 過度集中" };
      }
    }
    return { pass: true, reason: "通過" };
  } catch (e) {
    return { pass: false, reason: "rugcheck 連線失敗，保守拒絕" };
  }
}

// ── 進場判定 ──
export function shouldEnter(t, pair, cfg, state) {
  const e = cfg.entry;
  if (t.fatal) return { ok: false, why: "流動性致命不足" };
  if (t.score < e.minScore) return { ok: false, why: "分數不足 " + t.score };
  if (e.maxScore && t.score > e.maxScore) return { ok: false, why: "分數過熱 " + t.score + "（90+陷阱）" };
  if (e.maxTurnover && t.turnover > e.maxTurnover) return { ok: false, why: "換手紅旗 " + (t.turnover*100).toFixed(0) + "%（刷量嫌疑）" };
  if (t.liq < e.minLiquidityUsd) return { ok: false, why: "流動性低於門檻" };
  if (t.mcap > e.maxMcapUsd) return { ok: false, why: "市值超過上限" };
  if (t.t24 < e.minTxns24h) return { ok: false, why: "交易筆數不足" };
  if (t.br1 < e.minBuyRatio1h) return { ok: false, why: "1H買壓不足 " + (t.br1 * 100).toFixed(0) + "%" };
  if (t.h24 > e.maxPriceChange24h) return { ok: false, why: "24H已漲 " + t.h24.toFixed(0) + "% 追高風險" };
  const addr = pair.baseToken.address;
  if (state.positions.some(p => p.addr === addr && p.status === "open")) return { ok: false, why: "已持倉" };
  if (state.blacklist.includes(addr)) return { ok: false, why: "黑名單(曾停損)" };
  const cd = (state.cooldowns || {})[addr];
  if (cd && Date.now() - cd < (cfg.entry.cooldownHours || 24) * 36e5) return { ok: false, why: "冷卻期中(24h內剛出場)" };
  return { ok: true, why: "符合進場條件" };
}

// ── 出場判定（每次 tick 對每個持倉跑一次）──
// 回傳 null（續抱）或 { action: "sell", ratio, why }
export function shouldExit(pos, curPrice, cfg, curLiq) {
  const x = cfg.exit;
  if (!curPrice || curPrice <= 0) {
    return { action: "sell", ratio: 1, why: "查無報價（池可能被抽乾）緊急出場" };
  }
  // 0. 流動性抽乾預警：池子比進場時萎縮超過門檻 → 慢刀rug逃生
  //    （瞬間抽池救不了，但莊家分批撤流動性時能提早出場）
  if (x.liqDrainPct != null && pos.entryLiq > 0 && curLiq != null && curLiq > 0) {
    const drainPct = (curLiq / pos.entryLiq - 1) * 100;
    if (drainPct <= x.liqDrainPct) {
      return { action: "sell", ratio: 1, why: `流動性抽乾預警 池萎縮${drainPct.toFixed(0)}%（$${(pos.entryLiq/1e3).toFixed(0)}K→$${(curLiq/1e3).toFixed(0)}K）緊急出場` };
    }
  }
  const pnlPct = (curPrice / pos.entryPrice - 1) * 100;
  pos.peak = Math.max(pos.peak || pos.entryPrice, curPrice);
  const fromPeakPct = (curPrice / pos.peak - 1) * 100;
  const heldH = (Date.now() - pos.openedAt) / 36e5;

  // 1. 硬停損
  if (pnlPct <= x.stopLossPct) {
    return { action: "sell", ratio: 1, why: `停損 ${pnlPct.toFixed(1)}%` };
  }
  // 2. 第一段停利：達標賣一半，剩下讓利潤跑
  if (!pos.tp1Done && pnlPct >= x.takeProfit1Pct) {
    return { action: "sell", ratio: x.takeProfit1SellRatio, why: `停利1段 +${pnlPct.toFixed(0)}% 賣${x.takeProfit1SellRatio * 100}%`, markTp1: true };
  }
  // 3. 移動停損：從峰值回落超過設定 → 全出（只在已有獲利或TP1後啟動）
  if ((pos.tp1Done || pnlPct > 20) && fromPeakPct <= x.trailingStopPct) {
    return { action: "sell", ratio: 1, why: `移動停損 峰值回落${fromPeakPct.toFixed(0)}%（現${pnlPct.toFixed(0)}%）` };
  }
  // 4. 時間停損：抱太久沒表現就換標的
  if (heldH >= x.maxHoldHours && pnlPct < 20) {
    return { action: "sell", ratio: 1, why: `時間停損 持有${heldH.toFixed(0)}h 僅${pnlPct.toFixed(0)}%` };
  }
  return null;
}

// ── 熔斷檢查 ──
export function circuitBroken(state, cfg) {
  const cb = cfg.circuitBreaker;
  const today = new Date().toISOString().slice(0, 10);
  const dailyPnl = state.ledger
    .filter(l => l.time.slice(0, 10) === today && l.side === "sell")
    .reduce((a, l) => a + (l.pnlSOL || 0), 0);
  if (dailyPnl <= -cb.maxDailyLossSOL) return "當日虧損達 " + dailyPnl.toFixed(3) + " SOL，今日熔斷停機";
  const totalPnl = state.ledger.filter(l => l.side === "sell").reduce((a, l) => a + (l.pnlSOL || 0), 0);
  if (totalPnl <= -cb.maxTotalLossSOL) return "累計虧損達 " + totalPnl.toFixed(3) + " SOL，總熔斷停機（請人工檢討策略）";
  return null;
}
