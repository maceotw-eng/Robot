#!/usr/bin/env python3
"""
Defect 1: build the market -> EVENT mapping the cluster bootstrap actually needs.

Charter rev3 3.6 named `conditionId` as the cluster key. On Polymarket a
conditionId is one-to-one with a market - it is the CTF condition identifier,
and every leg of a multi-outcome event carries its own. Clustering on it yields
N clusters for N markets, which is what the 0a run reported
(markets 72605 | clusters 72605) and why the intervals were the narrow
leg-level ones that 3.6 exists to prevent.

MEASURE BEFORE YOU SPEND (methodology note 5). This script has three stages and
the first two cost nothing or almost nothing:

  --stage check    read the sample and see whether an event field is ALREADY
                   present. If the harvest kept it, the whole job is free.
  --stage measure  time both API routes on a small sample and report the
                   projected query count and wall clock for each, then stop.
  --stage fetch    run the route you chose.

Two routes exist and they differ by two orders of magnitude:
  per-market : /markets?id=<id>          -> one call per market (~72,605)
  by-event   : /events?limit=&offset=    -> each page returns events WITH their
                                            markets, so one page maps many

    python3 fetch_event_map.py sample_100k.ndjson --stage check
    python3 fetch_event_map.py sample_100k.ndjson --stage measure
    python3 fetch_event_map.py sample_100k.ndjson --stage fetch --route by-event
"""

import argparse
import json
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter

GAMMA = "https://gamma-api.polymarket.com"
UA = {"User-Agent": "pm2-eventmap/1.0", "Accept": "application/json"}

# Fields that could already carry event identity, cheapest first.
EVENT_FIELDS = ["events", "eventId", "event_id", "negRiskMarketID",
                "negRiskRequestID", "groupItemTitle", "slug"]


class Limiter:
    def __init__(self, per_sec):
        self.interval = 1.0 / per_sec if per_sec > 0 else 0.0
        self.next_at = 0.0

    def wait(self):
        now = time.monotonic()
        if now < self.next_at:
            time.sleep(self.next_at - now)
        self.next_at = max(now, self.next_at) + self.interval


def get(url, params, limiter, retries=4, timeout=40):
    full = url + "?" + urllib.parse.urlencode(params)
    for attempt in range(retries):
        limiter.wait()
        try:
            req = urllib.request.Request(full, headers=UA)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return json.loads(r.read().decode("utf-8")), None
        except urllib.error.HTTPError as exc:
            if exc.code in (429, 500, 502, 503, 504):
                time.sleep(min(30, 2 ** attempt))
                continue
            return None, "HTTP %d" % exc.code
        except (urllib.error.URLError, ssl.SSLError, OSError, TimeoutError) as exc:
            time.sleep(1.5 * (attempt + 1))
    return None, "exhausted"


def jload(v):
    if isinstance(v, (list, dict)):
        return v
    if isinstance(v, str) and v.strip():
        try:
            return json.loads(v)
        except json.JSONDecodeError:
            return None
    return None


def event_id_from(market):
    """Pull an event identity out of a market object, if one is there."""
    ev = jload(market.get("events"))
    if isinstance(ev, list) and ev and isinstance(ev[0], dict) and ev[0].get("id"):
        return str(ev[0]["id"]), "events[0].id"
    for f in ("eventId", "event_id"):
        if market.get(f):
            return str(market[f]), f
    # negRisk groups are the multi-outcome families; a decent secondary key.
    for f in ("negRiskMarketID", "negRiskRequestID"):
        if market.get(f):
            return str(market[f]), f
    return None, None


def load_sample(path):
    out = []
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                out.append(json.loads(line))
    return out


def stage_check(markets):
    print("=" * 68)
    print("STAGE 1 - is an event key already in the sample? (zero API cost)")
    print("=" * 68)
    present = Counter()
    for m in markets:
        for f in EVENT_FIELDS:
            if m.get(f) not in (None, "", [], {}):
                present[f] += 1
    n = len(markets)
    for f in EVENT_FIELDS:
        print("  %-18s %7d / %d  (%.2f%%)" % (f, present[f], n,
                                              100.0 * present[f] / n if n else 0))
    resolved = sum(1 for m in markets if event_id_from(m)[0])
    print("\n  markets with a usable event id RIGHT NOW: %d / %d (%.2f%%)"
          % (resolved, n, 100.0 * resolved / n if n else 0))
    if resolved > 0.95 * n:
        print("\n  => The mapping is already in hand. No API work needed.")
        print("     Run --stage fetch --route local to emit the map.")
    else:
        ids = Counter()
        for m in markets:
            eid, _ = event_id_from(m)
            if eid:
                ids[eid] += 1
        multi = sum(1 for v in ids.values() if v > 1)
        print("     distinct event ids found: %d, of which multi-leg: %d"
              % (len(ids), multi))
        print("\n  => Not enough. Run --stage measure to price the two API routes.")
    return resolved


def stage_measure(markets, limiter, probe=200):
    print("=" * 68)
    print("STAGE 2 - price both routes on %d markets, then stop" % probe)
    print("=" * 68)
    sample = markets[:probe]
    n_total = len(markets)

    print("\n[route A] per-market  /markets?id=<id>")
    t0 = time.time()
    hits = 0
    for m in sample[:min(40, probe)]:
        data, err = get(GAMMA + "/markets", {"id": m.get("id")}, limiter)
        rows = data if isinstance(data, list) else ([data] if data else [])
        if rows and event_id_from(rows[0])[0]:
            hits += 1
    ela = time.time() - t0
    per_call = ela / max(1, min(40, probe))
    a_calls = n_total
    a_hours = a_calls * per_call / 3600.0
    print("   %d/%d probe calls yielded an event id" % (hits, min(40, probe)))
    print("   %.3f s/call  ->  %s calls  ->  %.2f hours"
          % (per_call, f"{a_calls:,}", a_hours))

    print("\n[route B] by-event  /events?limit=100&offset=")
    t0 = time.time()
    mapped = {}
    pages = 0
    for page in range(5):
        data, err = get(GAMMA + "/events",
                        {"limit": 100, "offset": page * 100, "closed": "true"},
                        limiter)
        if not isinstance(data, list) or not data:
            break
        pages += 1
        for ev in data:
            for mk in (ev.get("markets") or []):
                if mk.get("id") is not None:
                    mapped[str(mk["id"])] = str(ev.get("id"))
    ela = time.time() - t0
    per_page = ela / max(1, pages)
    markets_per_page = len(mapped) / max(1, pages)
    b_pages = (n_total / markets_per_page) if markets_per_page else float("inf")
    b_hours = b_pages * per_page / 3600.0
    print("   %d pages -> %d market->event pairs (%.1f markets/page)"
          % (pages, len(mapped), markets_per_page))
    print("   %.3f s/page  ->  ~%s pages  ->  %.2f hours"
          % (per_page, f"{b_pages:,.0f}" if b_pages != float('inf') else "inf",
             b_hours))

    print("\n" + "=" * 68)
    if b_hours < a_hours:
        print("RECOMMEND route B (by-event): %.2f h vs %.2f h  (%.0fx cheaper)"
              % (b_hours, a_hours, a_hours / b_hours if b_hours else 0))
    else:
        print("RECOMMEND route A (per-market): %.2f h vs %.2f h" % (a_hours, b_hours))
    print("Nothing was written. Choose a route and run --stage fetch.")
    print("=" * 68)
    return {"route_a_hours": round(a_hours, 3), "route_b_hours": round(b_hours, 3)}


def stage_fetch(markets, route, limiter, out_path):
    wanted = {str(m.get("id")) for m in markets}
    mapping = {}
    basis = Counter()

    if route == "local":
        for m in markets:
            eid, how = event_id_from(m)
            if eid:
                mapping[str(m["id"])] = eid
                basis[how] += 1

    elif route == "per-market":
        for i, m in enumerate(markets, 1):
            data, err = get(GAMMA + "/markets", {"id": m.get("id")}, limiter)
            rows = data if isinstance(data, list) else ([data] if data else [])
            if rows:
                eid, how = event_id_from(rows[0])
                if eid:
                    mapping[str(m["id"])] = eid
                    basis[how] += 1
            if i % 500 == 0:
                print("  %d/%d  mapped %d" % (i, len(markets), len(mapping)),
                      flush=True)

    elif route == "by-event":
        offset = 0
        while True:
            data, err = get(GAMMA + "/events",
                            {"limit": 100, "offset": offset, "closed": "true"},
                            limiter)
            if not isinstance(data, list) or not data:
                break
            for ev in data:
                for mk in (ev.get("markets") or []):
                    mid = str(mk.get("id"))
                    if mid in wanted:
                        mapping[mid] = str(ev.get("id"))
                        basis["events_page"] += 1
            offset += len(data)
            if offset % 2000 == 0:
                print("  offset %d  mapped %d/%d"
                      % (offset, len(mapping), len(wanted)), flush=True)
            if len(mapping) >= len(wanted):
                break
    else:
        print("unknown route: %s" % route, file=sys.stderr)
        return 1

    sizes = Counter(mapping.values())
    multi = sum(1 for v in sizes.values() if v > 1)
    covered = len(mapping)
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump({"route": route, "markets_in_sample": len(markets),
                   "mapped": covered,
                   "coverage": round(covered / len(markets), 4) if markets else 0,
                   "distinct_events": len(sizes),
                   "multi_leg_events": multi,
                   "largest_event_legs": max(sizes.values()) if sizes else 0,
                   "basis": dict(basis),
                   "map": mapping}, fh, ensure_ascii=False)

    print("\nmapped %d / %d (%.2f%%)" % (covered, len(markets),
                                         100.0 * covered / len(markets)))
    print("distinct events %d | multi-leg events %d | largest event %d legs"
          % (len(sizes), multi, max(sizes.values()) if sizes else 0))
    print("\nUnmapped markets keep their own id as a singleton cluster; that is")
    print("conservative (it cannot narrow an interval) but the coverage figure")
    print("must be reported alongside the re-run.")
    print("wrote %s" % out_path)
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("sample")
    ap.add_argument("--stage", choices=("check", "measure", "fetch"),
                    default="check")
    ap.add_argument("--route", choices=("local", "per-market", "by-event"),
                    default="by-event")
    ap.add_argument("--out", default="event_map.json")
    ap.add_argument("--rate", type=float, default=3.0)
    ap.add_argument("--probe", type=int, default=200)
    args = ap.parse_args()

    markets = load_sample(args.sample)
    print("sample: %d markets\n" % len(markets))
    limiter = Limiter(args.rate)

    if args.stage == "check":
        stage_check(markets)
        return 0
    if args.stage == "measure":
        stage_measure(markets, limiter, args.probe)
        return 0
    return stage_fetch(markets, args.route, limiter, args.out)


if __name__ == "__main__":
    sys.exit(main())
