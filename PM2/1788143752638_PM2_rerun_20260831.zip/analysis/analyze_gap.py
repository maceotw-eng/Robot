#!/usr/bin/env python3
"""
Defect 4: is the T=1 checkpoint an ex-ante probability, or a convergence snapshot?

Implements attachment D.3's procedure and applies D.3's PRE-REGISTERED decision
lines verbatim. Nothing here is chosen after seeing the numbers; the thresholds
below were frozen in the review order before this script existed.

    | median gap < 2h AND frac<6h > 0.7  -> artifact confirmed; the two cells
    |                                       must be relabelled "convergence-end
    |                                       snapshot" and do not proceed to 0b
    | median gap > 12h, near-uniform     -> hypothesis falsified; cells stand
    | otherwise                          -> undecided, needs the D.4 price-path test

The control group is mandatory (D.3): the same distribution cut at the extreme
buckets. Without it a gap distribution is only a descriptive statistic - it
cannot explain why the positive deviation appears in 10-35c and nowhere else.

Zero API cost. checkpoint_gap_hours is already on every row; charter 3.1 froze
the obligation to record it precisely so this test would be possible later.

    python3 analyze_gap.py observations.ndjson --out gap_analysis.json \\
            --report gap_analysis.md
"""

import argparse
import json
import sys
from collections import defaultdict

SURVIVOR_BUCKETS = {"10-20", "20-35"}      # the two cells under suspicion
CONTROL_BUCKETS = {"90-95", "95-99"}       # D.3's mandatory control group

BUCKETS = [(1, 5), (5, 10), (10, 20), (20, 35), (35, 50),
           (50, 65), (65, 80), (80, 90), (90, 95), (95, 99)]


def bucket_of(cents):
    for lo, hi in BUCKETS:
        if lo <= cents < hi:
            return "%d-%d" % (lo, hi)
    if cents == 99:
        return "95-99"
    return None


def quantiles(values):
    v = sorted(values)
    n = len(v)
    if not n:
        return {}
    q = lambda p: v[min(n - 1, int(p * n))]
    return {"n": n, "p10": round(q(0.10), 3), "p50": round(q(0.50), 3),
            "p90": round(q(0.90), 3),
            "frac_lt_1h": round(sum(1 for x in v if x < 1) / n, 4),
            "frac_lt_6h": round(sum(1 for x in v if x < 6) / n, 4),
            "frac_lt_12h": round(sum(1 for x in v if x < 12) / n, 4)}


def verdict_for(stats):
    """D.3's frozen lines. No threshold is picked here."""
    if not stats:
        return "no data"
    if stats["p50"] < 2.0 and stats["frac_lt_6h"] > 0.7:
        return ("ARTIFACT CONFIRMED - relabel as convergence-end snapshot, "
                "not an ex-ante probability; does not proceed to 0b")
    if stats["p50"] > 12.0:
        return "hypothesis falsified - cell stands as an ex-ante measurement"
    return "UNDECIDED - needs the D.4 price-path test"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("observations")
    ap.add_argument("--out", default="gap_analysis.json")
    ap.add_argument("--report", default="gap_analysis.md")
    args = ap.parse_args()

    by_cell = defaultdict(list)
    by_group = defaultdict(list)
    rows = missing_gap = 0

    with open(args.observations, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            o = json.loads(line)
            if o.get("price") is None:
                continue
            rows += 1
            gap = o.get("checkpoint_gap_hours")
            if gap is None:
                missing_gap += 1
                continue
            buck = bucket_of(o["price"] * 100.0)
            if buck is None:
                continue
            w = o["window"]
            by_cell[(w, buck)].append(abs(gap))
            group = ("survivor_10-35" if buck in SURVIVOR_BUCKETS else
                     "control_extreme" if buck in CONTROL_BUCKETS else "other")
            by_group[(w, group)].append(abs(gap))

    cells = {"T=%d %s" % k: quantiles(v) for k, v in sorted(by_cell.items())}
    groups = {"T=%d %s" % k: quantiles(v) for k, v in sorted(by_group.items())}

    focus = {}
    for w in (1, 7, 30):
        for b in sorted(SURVIVOR_BUCKETS):
            st = quantiles(by_cell.get((w, b), []))
            if st:
                focus["T=%d %s" % (w, b)] = {"stats": st, "verdict": verdict_for(st)}

    # D.3: the control comparison is what makes this more than description.
    control = {}
    for w in (1, 7, 30):
        s = quantiles(by_group.get((w, "survivor_10-35"), []))
        c = quantiles(by_group.get((w, "control_extreme"), []))
        if s and c:
            control["T=%d" % w] = {
                "survivor_10-35_p50": s["p50"], "control_extreme_p50": c["p50"],
                "difference_hours": round(s["p50"] - c["p50"], 3),
                "reading": ("survivor cells sit CLOSER to settlement than the "
                            "controls - hypothesis strengthened"
                            if s["p50"] < c["p50"] * 0.8 else
                            "no material difference - gap cannot explain why only "
                            "10-35c shows a positive deviation; hypothesis weakened"
                            if abs(s["p50"] - c["p50"]) < 0.2 * max(c["p50"], 1e-9)
                            else "controls sit closer - hypothesis contradicted")}

    result = {"rows_with_price": rows, "rows_missing_gap": missing_gap,
              "per_cell": cells, "per_group": groups,
              "focus_cells": focus, "control_comparison": control,
              "decision_lines": "attachment D.3, frozen before this run"}
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(result, fh, indent=2, ensure_ascii=False)

    L = ["# Defect 4: checkpoint gap distribution (attachment D.3)", "",
         "Rows with a price: %d. Rows missing checkpoint_gap_hours: %d." % (rows, missing_gap),
         "", "Decision lines were frozen in the review order BEFORE this ran.", "",
         "## Cells under suspicion", "",
         "| cell | n | p10 | p50 | p90 | frac<1h | frac<6h | verdict |",
         "|---|---|---|---|---|---|---|---|"]
    for name, rec in focus.items():
        s = rec["stats"]
        L.append("| %s | %d | %.2f | %.2f | %.2f | %.3f | %.3f | **%s** |"
                 % (name, s["n"], s["p10"], s["p50"], s["p90"],
                    s["frac_lt_1h"], s["frac_lt_6h"], rec["verdict"]))

    L += ["", "## Mandatory control comparison (D.3)", "",
          "| window | survivor 10-35c p50 | control extreme p50 | diff (h) | reading |",
          "|---|---|---|---|---|"]
    for w, rec in control.items():
        L.append("| %s | %.2f | %.2f | %+.2f | %s |"
                 % (w, rec["survivor_10-35_p50"], rec["control_extreme_p50"],
                    rec["difference_hours"], rec["reading"]))

    L += ["", "## All cells", "",
          "| cell | n | p10 | p50 | p90 | frac<1h | frac<6h |",
          "|---|---|---|---|---|---|---|"]
    for name, s in cells.items():
        if s:
            L.append("| %s | %d | %.2f | %.2f | %.2f | %.3f | %.3f |"
                     % (name, s["n"], s["p10"], s["p50"], s["p90"],
                        s["frac_lt_1h"], s["frac_lt_6h"]))

    L += ["", "> Charter 3.1 froze the obligation to record the actual gap.",
          "> A recorded value that is never printed is not a record.", ""]
    with open(args.report, "w", encoding="utf-8") as fh:
        fh.write("\n".join(L))

    print("\n".join(L[:40]))
    print("\nwrote %s and %s" % (args.out, args.report))
    return 0


if __name__ == "__main__":
    sys.exit(main())
