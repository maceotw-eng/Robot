# PM-2 0a 覆核重跑指令包(2026-08-31)

**章程:**`PM2_charter_v1.1_FROZEN_rev4.md`
**sha256:**`1d05ec14dd16c95154680f50d19ea6884fb6b7f7e129cf39db719eb8b55e1dac`(32,281 bytes)
**前提:**判決暫緩生效。八項缺陷,七項已在分析層修好,一項(叢集鍵)需要補抓 event 對映。

> **不必重抓價格。** `observations.ndjson` 是乾淨的。以下全部吃現有檔案,
> 只有第三步會打 API,而且**先量再花**。

---

## 一、上傳到 GitHub `Robot/PM2/`

| 檔案 | 變更 |
|---|---|
| `analysis/pm2_pipeline.py` | **修正版**(54 項測試):分母自推、三態列印、網格外計數、gap 欄、MDE / obs-MDE、event map 支援 |
| `analysis/analyze_gap.py` | **新** —— 缺陷四,附件 D.3 的凍結判讀線 |
| `analysis/fetch_event_map.py` | **新** —— 缺陷一,三階段「先量再花」 |
| `PM2_charter_v1.1_FROZEN_rev4.md` | **新** —— 兩項條文更正 |

---

## 二、零 API 成本,先跑(約 10 分鐘)

```bash
cd ~/pm2/0a

# 缺陷四:T=1 是不是「收斂末端快照」
python3 analyze_gap.py observations.ndjson \
        --out gap_analysis.json --report gap_analysis.md

# 缺陷一:先看 event 鍵是不是本來就在樣本裡(可能完全不用打 API)
python3 fetch_event_map.py sample_100k.ndjson --stage check
```

`analyze_gap.py` 會自己套用 D.3 **凍結在先**的判讀線,不是我事後挑的門檻:

| 讀數 | 裁決 |
|---|---|
| 中位 gap < 2h 且 frac<6h > 0.7 | **artifact 實錘**,兩格改標「收斂末端快照」,不進 0b |
| 中位 gap > 12h | 假說證偽,兩格保留 |
| 其間 | 未定,需 D.4 價格軌跡檢定 |

**對照組是強制的**(D.3):同樣的分布切在 90-95 / 95-99。沒有對照組的 gap 分布只是描述統計。

---

## 三、event 對映:**先量,再決定花多少**

`--stage check` 的輸出決定下一步:

**情況 A —— 樣本裡已經有 event 鍵(覆蓋率 > 95%)**
```bash
python3 fetch_event_map.py sample_100k.ndjson --stage fetch --route local
```
零 API,幾秒鐘。

**情況 B —— 沒有,需要打 API。先量兩條路的成本:**
```bash
python3 fetch_event_map.py sample_100k.ndjson --stage measure
```
它會實測 `/markets?id=`(逐筆,約 72,605 次)與 `/events?limit=100`(分頁,一頁映多筆)
兩條路的秒/次與推估總時數,**然後停下,不寫任何東西**。看完數字再選:

```bash
setsid nohup python3 fetch_event_map.py sample_100k.ndjson \
       --stage fetch --route by-event --out event_map.json > evmap.log 2>&1 &
```

> §8 方法論第 5 條:假設沒被量過就不能拿去用。我沒有猜這個成本 ——
> 我本機打不到 Gamma(TLS 攔截),所以把量測做成腳本讓機器自己講。

---

## 四、重跑判決

```bash
cd ~/pm2/0a
python3 pm2_pipeline.py observations.ndjson \
        --event-map event_map.json \
        --t30-absence t30_absence.json \
        --out pm2_result_rev4.json --report pm2_report_rev4.md
```

**注意:`--cohort-sizes` 不要再傳。** 分母現在由觀測列自己推導
(fetcher 對每個世代內的 pair 都寫一列,含缺席,所以列數就是抽樣內世代數)。
若仍傳入母體級數字,程式會**拒用並在報告標記**,不再靜默混用。

沒有 `--event-map` 也能跑,但會在 stderr 警告,且報告首頁會印
「cluster degeneracy: clusters == markets」—— 那份報告不能當判決書。

---

## 五、傳回三個檔

`pm2_report_rev4.md`、`pm2_result_rev4.json`、`gap_analysis.md`
(若有 event map,再加 `event_map.json` 的前 30 行摘要即可,不必傳全檔)

---

## 六、重跑後必看的四個讀數

1. **`clusters` 是否真的小於 `legs`** —— 若仍相等,對映沒生效,停下
2. **四個存活格的 CI 寬度變化** —— 章程要求修正前後並報
3. **`obs/MDE` 欄** —— < 1.3 的存活格依 rev4 §5.0 **不得逕行進 0b**
4. **T=30 精確缺席率**(來自 `t30_absence.json`)是否 > 30% —— 超過則降級自動生效

---

## 七、仍未做(與本次無關,但還在)

錄影機 R-01~R-03 升級包依然沒部署,重複列 bug 每 6 小時繼續汙染 0b 的分母。
指令在 `docs/PM2_本週待辦_20260827.md`。
