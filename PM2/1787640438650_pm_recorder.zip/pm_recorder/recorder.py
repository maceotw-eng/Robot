#!/usr/bin/env python3
"""
PM-2 A-line recorder - Binance Prediction Markets snapshot capture.

Stdlib only (no pip install on the VPS). Python 3.8+.

One run = one snapshot of the selected market universe:
  market/list   -> topic universe (paginated)
  market/detail -> outcomes + tokenId   (skipped when list already carries them)
  order-book    -> full depth per outcome token
  last-trade    -> last traded price per market

Output: data/YYYY-MM-DD/snap_<ts>.ndjson[.gz], one JSON object per market outcome.

Credentials come from the environment (or an env file passed with --env):
  BINANCE_API_KEY, BINANCE_API_SECRET
"""

import argparse
import csv
import gzip
import hashlib
import hmac
import json
import logging
import os
import random
import ssl
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter, deque
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
log = logging.getLogger("pm2rec")


# ---------------------------------------------------------------- utilities

def utcnow():
    return datetime.now(timezone.utc)


def stamp(dt):
    return dt.strftime("%Y%m%dT%H%M%SZ")


def load_env_file(path):
    """Parse a KEY=VALUE env file into os.environ (existing vars win)."""
    if not path or not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, val = line.split("=", 1)
            os.environ.setdefault(key.strip(), val.strip().strip('"').strip("'"))


class BinanceError(Exception):
    def __init__(self, status, code, msg, endpoint):
        super().__init__("[%s] HTTP %s code=%s %s" % (endpoint, status, code, msg))
        self.status = status
        self.code = code
        self.msg = msg
        self.endpoint = endpoint


# ---------------------------------------------------------------- rate limit

class EndpointLimiter:
    """
    Sliding-window weight limiter. Binance gives each IP-limited endpoint its OWN
    12000/min budget, so we key one limiter per endpoint rather than sharing a pool.
    """

    def __init__(self, weight_per_min, safety_factor):
        self.budget = max(1.0, weight_per_min * safety_factor)
        self.events = deque()  # (monotonic_ts, weight)
        self.used = 0.0
        self.lock = threading.Lock()

    def acquire(self, weight):
        while True:
            with self.lock:
                now = time.monotonic()
                while self.events and now - self.events[0][0] >= 60.0:
                    self.used -= self.events.popleft()[1]
                if self.used + weight <= self.budget:
                    self.events.append((now, weight))
                    self.used += weight
                    return
                wait = 60.0 - (now - self.events[0][0]) + 0.05
            time.sleep(min(wait, 5.0))

    def note_server_usage(self, used_weight):
        """Reconcile with X-SAPI-USED-IP-WEIGHT-1M when the server counts more than we did."""
        with self.lock:
            if used_weight > self.used:
                self.events.append((time.monotonic(), used_weight - self.used))
                self.used = used_weight


# ---------------------------------------------------------------- API client

class PredictionClient:
    def __init__(self, cfg, api_key, api_secret):
        self.cfg = cfg
        self.api_key = api_key
        self.api_secret = api_secret.encode("utf-8")
        api = cfg["api"]
        self.bases = [api["base_url"]] + list(api.get("fallback_base_urls", []))
        self.base_idx = 0
        self.timeout = api.get("http_timeout_sec", 20)
        self.recv_window = api.get("recv_window_ms", 20000)
        self.user_agent = api.get("user_agent", "pm2-recorder/1.0")

        rl = cfg["rate_limit"]
        self.max_retries = rl.get("max_retries", 4)
        self.backoff_base = rl.get("backoff_base_sec", 2.0)
        self.sleep_on_418 = rl.get("sleep_on_418_sec", 120)
        self.limiters = {
            name: EndpointLimiter(rl["per_endpoint_weight_per_min"], rl["safety_factor"])
            for name in cfg["endpoints"]
        }
        self.ssl_ctx = ssl.create_default_context()
        self.raw_records = []
        self.raw_lock = threading.Lock()
        self.call_count = 0
        self.count_lock = threading.Lock()

    # -- signing -----------------------------------------------------------
    def _sign(self, params):
        """
        Binance SAPI REST: HMAC-SHA256 over the query string EXACTLY as sent.
        (The WSS handshake sorts params alphabetically; REST does not require it.
         We build the string once and sign that same string.)
        """
        qs = urllib.parse.urlencode(params, doseq=True)
        sig = hmac.new(self.api_secret, qs.encode("utf-8"), hashlib.sha256).hexdigest()
        return qs + "&signature=" + sig

    # -- transport ---------------------------------------------------------
    def call(self, endpoint_name, params=None, context=None):
        ep = self.cfg["endpoints"][endpoint_name]
        weight = ep.get("ip_weight", 200)
        limiter = self.limiters[endpoint_name]

        last_exc = None
        for attempt in range(self.max_retries + 1):
            limiter.acquire(weight)
            params_out = dict(params or {})
            if ep.get("signed", True):
                params_out["timestamp"] = int(time.time() * 1000)
                if self.recv_window:
                    params_out["recvWindow"] = self.recv_window
                qs = self._sign(params_out)
            else:
                qs = urllib.parse.urlencode(params_out, doseq=True)

            base = self.bases[self.base_idx]
            url = base + ep["path"] + ("?" + qs if qs else "")
            req = urllib.request.Request(url, method=ep.get("method", "GET"))
            req.add_header("X-MBX-APIKEY", self.api_key)
            req.add_header("User-Agent", self.user_agent)
            req.add_header("Accept", "application/json")

            try:
                with urllib.request.urlopen(req, timeout=self.timeout,
                                            context=self.ssl_ctx) as resp:
                    body = resp.read().decode("utf-8")
                    used = resp.headers.get("X-SAPI-USED-IP-WEIGHT-1M")
                    if used:
                        try:
                            limiter.note_server_usage(float(used))
                        except ValueError:
                            pass
                with self.count_lock:
                    self.call_count += 1
                data = json.loads(body) if body else None
                self._archive(endpoint_name, params, data, context)
                return data

            except urllib.error.HTTPError as exc:
                raw = ""
                try:
                    raw = exc.read().decode("utf-8")
                except Exception:
                    pass
                code, msg = None, raw[:400]
                try:
                    parsed = json.loads(raw)
                    code, msg = parsed.get("code"), parsed.get("msg", msg)
                except Exception:
                    pass

                if exc.code in (418, 429):
                    retry_after = exc.headers.get("Retry-After")
                    nap = float(retry_after) if retry_after else (
                        self.sleep_on_418 if exc.code == 418
                        else self.backoff_base * (2 ** attempt))
                    log.warning("%s rate limited (HTTP %s code=%s) -> sleeping %.1fs",
                                endpoint_name, exc.code, code, nap)
                    time.sleep(nap)
                    last_exc = BinanceError(exc.code, code, msg, endpoint_name)
                    continue

                if exc.code >= 500 or exc.code == 408:
                    # Read-only endpoints: rotate base host and retry.
                    self.base_idx = (self.base_idx + 1) % len(self.bases)
                    nap = self.backoff_base * (2 ** attempt) + random.uniform(0, 1)
                    log.warning("%s HTTP %s -> base=%s retry in %.1fs",
                                endpoint_name, exc.code, self.bases[self.base_idx], nap)
                    time.sleep(nap)
                    last_exc = BinanceError(exc.code, code, msg, endpoint_name)
                    continue

                # Other 4xx: bad key, bad param, IP not whitelisted. Not retryable.
                raise BinanceError(exc.code, code, msg, endpoint_name)

            except (urllib.error.URLError, ssl.SSLError, TimeoutError, OSError) as exc:
                nap = self.backoff_base * (2 ** attempt) + random.uniform(0, 1)
                log.warning("%s network error: %s -> retry in %.1fs",
                            endpoint_name, exc, nap)
                time.sleep(nap)
                last_exc = exc
                continue

        raise last_exc if last_exc else RuntimeError("exhausted retries: " + endpoint_name)

    def _archive(self, endpoint_name, params, data, context):
        if not self.cfg["output"].get("archive_raw_responses"):
            return
        scrubbed = {k: v for k, v in (params or {}).items()
                    if k not in ("timestamp", "signature", "recvWindow")}
        with self.raw_lock:
            self.raw_records.append({
                "endpoint": endpoint_name,
                "params": scrubbed,
                "context": context,
                "fetched_at_ms": int(time.time() * 1000),
                "response": data,
            })


# ---------------------------------------------------------------- selection

def _num(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def fetch_universe(client, sel):
    """Paginate market/list, then filter and cap."""
    page_size = min(int(sel.get("page_size", 100)), 100)
    max_pages = int(sel.get("max_pages", 20))
    strategy = sel.get("strategy", "ending_soonest")

    sort_by, order_by = {
        "ending_soonest": ("END_DATE", "ASC"),
        "top_volume": ("VOLUME", "DESC"),
    }.get(strategy, (None, None))

    topics, offset = [], 0
    for page in range(max_pages):
        params = {"offset": offset, "limit": page_size}
        if sort_by:
            params["sortBy"] = sort_by
            params["orderBy"] = order_by
        if sel.get("l1_category"):
            params["l1Category"] = sel["l1_category"]

        data = client.call("market_list", params, context={"page": page}) or {}
        batch = data.get("marketTopics") or []
        topics.extend(batch)
        log.info("market/list page=%d got=%d total=%s hasMore=%s",
                 page, len(batch), data.get("total"), data.get("hasMore"))
        if not batch or not data.get("hasMore"):
            break
        offset += len(batch)
        # The list is already sorted, so stop paging once we comfortably cover the cap.
        if strategy != "all" and len(topics) >= int(sel.get("max_topics", 150)) * 3:
            log.info("stopping pagination early: %d topics covers cap %s",
                     len(topics), sel.get("max_topics"))
            break

    return filter_universe(topics, sel)


def filter_universe(topics, sel):
    allowed = {s.upper() for s in sel.get("include_status") or []}
    min_vol = _num(sel.get("min_trade_volume"), 0.0)
    horizon = sel.get("max_days_to_resolution")
    now_ms = int(time.time() * 1000)

    kept, dropped = [], {"status": 0, "volume": 0, "horizon": 0}
    for topic in topics:
        if allowed and str(topic.get("status", "")).upper() not in allowed:
            dropped["status"] += 1
            continue
        if min_vol and _num(topic.get("tradeVolume")) < min_vol:
            dropped["volume"] += 1
            continue
        if horizon is not None:
            end = topic.get("endDate")
            if end and (int(end) - now_ms) > float(horizon) * 86400000.0:
                dropped["horizon"] += 1
                continue
        kept.append(topic)

    strategy = sel.get("strategy", "ending_soonest")
    if strategy == "ending_soonest":
        kept.sort(key=lambda t: (t.get("endDate") is None, t.get("endDate") or 0))
    elif strategy == "top_volume":
        kept.sort(key=lambda t: -_num(t.get("tradeVolume")))

    cap = int(sel.get("max_topics", 150))
    capped = kept[:cap] if cap > 0 else kept
    log.info("universe: raw=%d kept=%d capped=%d dropped=%s",
             len(topics), len(kept), len(capped), dropped)
    if len(kept) > len(capped):
        log.warning("TRUNCATED: %d topics passed filters but max_topics=%d - "
                    "%d markets are NOT in this snapshot",
                    len(kept), cap, len(kept) - len(capped))
    return capped, len(topics), dropped, len(kept)


def extract_markets(topic):
    """Pull markets[] whose outcomes already carry a tokenId."""
    out = []
    for market in topic.get("markets") or []:
        if not isinstance(market, dict):
            continue
        outcomes = [o for o in (market.get("outcomes") or [])
                    if isinstance(o, dict) and o.get("tokenId")]
        if outcomes:
            out.append((market, outcomes))
    return out


# ---------------------------------------------------------------- capture

def capture(client, cfg, snapshot_id, captured_at_ms):
    sel = cfg["selection"]
    topics, raw_count, dropped, kept_count = fetch_universe(client, sel)

    # --- resolve outcomes, reusing the list payload where possible ---------
    need_detail, resolved = [], {}
    for topic in topics:
        tid = topic.get("marketTopicId")
        markets = [] if sel.get("always_fetch_detail") else extract_markets(topic)
        if markets:
            resolved[tid] = (topic, markets)
        else:
            need_detail.append(topic)

    log.info("outcomes: %d topics resolved from list payload, %d need market/detail",
             len(resolved), len(need_detail))

    detail_errors = []
    workers = int(cfg["rate_limit"].get("max_workers", 4))

    def do_detail(topic):
        tid = topic.get("marketTopicId")
        try:
            detail = client.call("market_detail", {"marketTopicId": tid},
                                 context={"marketTopicId": tid})
            if detail:
                merged = dict(topic)
                merged.update(detail)
                return tid, merged, extract_markets(detail)
        except Exception as exc:
            log.error("market/detail failed topic=%s: %s", tid, exc)
            detail_errors.append({"marketTopicId": tid, "error": str(exc)})
        return tid, topic, []

    if need_detail:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            for tid, merged, markets in pool.map(do_detail, need_detail):
                if markets:
                    resolved[tid] = (merged, markets)

    # --- build the order-book fetch plan ----------------------------------
    plan = []
    for topic, markets in resolved.values():
        for market, outcomes in markets:
            picked = outcomes if sel.get("fetch_all_outcomes") else outcomes[:1]
            for outcome in picked:
                plan.append((topic, market, outcome))

    log.info("plan: %d order-book calls across %d topics", len(plan), len(resolved))

    ob_errors = []
    ltp_cache, ltp_lock = {}, threading.Lock()

    def last_trade(market_id):
        if not sel.get("fetch_last_trade_price"):
            return None
        with ltp_lock:
            if market_id in ltp_cache:
                return ltp_cache[market_id]
        try:
            data = client.call("last_trade_price", {"marketId": market_id},
                               context={"marketId": market_id}) or {}
            val = data.get("lastTradePrice")
        except Exception as exc:
            log.warning("last-trade-price failed market=%s: %s", market_id, exc)
            val = None
        with ltp_lock:
            ltp_cache[market_id] = val
        return val

    def do_one(item):
        topic, market, outcome = item
        market_id = market.get("marketId")
        token_id = outcome.get("tokenId")
        vendor = topic.get("vendor") or market.get("vendor")

        rec = {
            "snapshot_id": snapshot_id,
            "captured_at_ms": captured_at_ms,
            "source": "binance_w3w_prediction",
            "vendor": vendor,
            "chainId": topic.get("chainId"),

            "marketTopicId": topic.get("marketTopicId"),
            "slug": topic.get("slug"),
            "title": topic.get("title"),
            "question": topic.get("question"),
            "topicType": topic.get("topicType"),
            "symbol": topic.get("symbol"),
            "topic_status": topic.get("status"),
            "startDate": topic.get("startDate"),
            "endDate": topic.get("endDate"),
            "publishedAt": topic.get("publishedAt"),
            "participantCount": topic.get("participantCount"),
            "collateral": topic.get("collateral"),
            "feeRateBps": topic.get("feeRateBps"),
            "slippageBps": topic.get("slippageBps"),
            "isYieldBearing": topic.get("isYieldBearing"),
            "topic_tradeVolume": topic.get("tradeVolume"),
            "topic_liquidity": topic.get("liquidity"),

            "marketId": market_id,
            "externalId": market.get("externalId"),
            "conditionId": market.get("conditionId"),
            "market_title": market.get("title"),
            "market_question": market.get("question"),
            "market_status": market.get("status"),
            "tradingStatus": market.get("tradingStatus"),
            "market_tradeVolume": market.get("tradeVolume"),
            "market_liquidity": market.get("liquidity"),
            "decimalPrecision": market.get("decimalPrecision"),

            "outcome_name": outcome.get("name"),
            "outcome_index": outcome.get("index"),
            "tokenId": token_id,
            "detail_price": outcome.get("price"),
            "detail_chance": outcome.get("chance"),

            "lastTradePrice": None,
            "best_bid": None,
            "best_ask": None,
            "mid_price": None,
            "spread": None,
            "bid_levels": 0,
            "ask_levels": 0,
            "orderbook": None,
            "orderbook_error": None,
            "ob_fetch_ms": None,
        }

        t0 = time.time()
        try:
            book = client.call("order_book",
                               {"vendor": vendor, "marketId": market_id,
                                "tokenId": token_id},
                               context={"marketId": market_id, "tokenId": token_id}) or {}
            bids = book.get("bids") or []
            asks = book.get("asks") or []
            rec["orderbook"] = {
                "outcome": book.get("outcome"),
                "tokenId": book.get("tokenId"),
                "timestamp": book.get("timestamp"),
                "bids": bids,
                "asks": asks,
            }
            rec["bid_levels"] = len(bids)
            rec["ask_levels"] = len(asks)
            if bids:
                rec["best_bid"] = bids[0].get("price")
            if asks:
                rec["best_ask"] = asks[0].get("price")
            if rec["best_bid"] is not None and rec["best_ask"] is not None:
                bb = _num(rec["best_bid"], None)
                ba = _num(rec["best_ask"], None)
                if bb is not None and ba is not None:
                    rec["mid_price"] = (bb + ba) / 2.0
                    rec["spread"] = ba - bb
        except Exception as exc:
            rec["orderbook_error"] = str(exc)
            ob_errors.append({"marketId": market_id, "tokenId": token_id,
                              "error": str(exc)})
            log.error("order-book failed market=%s token=%s: %s",
                      market_id, token_id, exc)
        rec["ob_fetch_ms"] = int((time.time() - t0) * 1000)

        rec["lastTradePrice"] = last_trade(market_id)
        return rec

    records = []
    if plan:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            for rec in pool.map(do_one, plan):
                records.append(rec)

    stats = {
        "topics_listed_raw": raw_count,
        "topics_passed_filters": kept_count,
        "topics_in_snapshot": len(topics),
        "topics_truncated_by_cap": max(0, kept_count - len(topics)),
        "topics_dropped": dropped,
        "topics_with_outcomes": len(resolved),
        "detail_calls": len(need_detail),
        "detail_errors": len(detail_errors),
        "orderbook_attempted": len(plan),
        "orderbook_ok": sum(1 for r in records if r.get("orderbook")),
        "orderbook_errors": len(ob_errors),
        "empty_books": sum(1 for r in records
                           if r.get("orderbook")
                           and not r["orderbook"]["bids"]
                           and not r["orderbook"]["asks"]),
        "api_calls_total": client.call_count,
    }
    return records, stats, detail_errors + ob_errors


# ------------------------------------------------- registry and resolutions

"""
Why a registry exists at all
---------------------------
The recorder snapshots LIVE markets. A settled market stops being live: the WS
channel explicitly stops pushing it, and it is expected to leave market/list.
But 0b's denominator - the ACTUAL YES/NO frequency - is exactly the settled
population. If a market is not written down while it is visible, and then it
disappears, the outcome is unrecoverable: this API family has no history
endpoint to go back and ask.

So every market ever seen is registered, and every registered market past its
endDate is polled until we capture a resolution or exhaust the attempt budget.
The result lands in its own CSV, independent of the snapshot files.
"""

TERMINAL_VERDICTS = ("resolved", "voided", "unresolvable")

# Verdicts that may be counted as 0b's denominator. NOT provisional_price:
# see docs/PM2_R02_settlement_review.md for why price must never settle a market.
COUNTABLE_VERDICTS = ("resolved", "voided")


def _state_path(cfg, key, default):
    rel = cfg.get("resolution_tracking", {}).get(key, default)
    path = os.path.join(HERE, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path


def load_registry(path):
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (json.JSONDecodeError, OSError) as exc:
        log.error("registry unreadable (%s); starting a new one, "
                  "OLD ENTRIES ARE LOST: %s", path, exc)
        return {}


def save_registry(path, registry):
    tmp = path + ".part"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(registry, fh, ensure_ascii=False)
    os.replace(tmp, path)


def register_snapshot(registry, records, now_ms):
    """Upsert every market seen this run. Keyed by marketTopicId."""
    added = 0
    for rec in records:
        tid = rec.get("marketTopicId")
        if tid is None:
            continue
        key = str(tid)
        entry = registry.get(key)
        if entry is None:
            entry = {
                "marketTopicId": tid,
                "vendor": rec.get("vendor"),
                "slug": rec.get("slug"),
                "title": rec.get("title"),
                "question": rec.get("question"),
                "endDate": rec.get("endDate"),
                "first_seen_ms": now_ms,
                "markets": {},
                "resolution_state": "live",
                "attempts": 0,
                "last_attempt_ms": None,
            }
            registry[key] = entry
            added += 1
        entry["last_seen_ms"] = now_ms
        entry["endDate"] = rec.get("endDate") or entry.get("endDate")
        entry["last_status"] = rec.get("topic_status")
        mid = rec.get("marketId")
        if mid is not None:
            entry["markets"][str(mid)] = {
                "marketId": mid,
                "conditionId": rec.get("conditionId"),
                "externalId": rec.get("externalId"),
                "question": rec.get("market_question") or rec.get("question"),
                "last_price": rec.get("mid_price"),
                "last_volume": rec.get("market_tradeVolume"),
            }
    return added


def extract_resolution(detail, rules=None):
    """
    Read a settlement verdict off a market/detail payload.

    R-02 (2026-08-25). Field evidence from the Tokyo box shows a two-layer,
    two-status structure whose semantics do not line up with the naive reading:

        topic  layer: status = REGISTERED | CLOSED
        market layer: status = CLOSED  CAN COEXIST WITH  tradingStatus = OPEN

    and a market whose event has already happened (Bologna v Pisa, played,
    $1.03M volume) sits at status=CLOSED / tradingStatus=OPEN with prices
    0.999 / 0.001.

    The decisive rule this function now enforces: PRICE NEVER SETTLES A MARKET.
    PM-2 asks whether price predicts outcome. Deriving the outcome from the
    price makes that question circular, and silently dropping markets whose
    price never converged is selection on the dependent variable - both biases
    point the same way, toward "well calibrated". So converged-but-unconfirmed
    markets get verdict 'provisional_price', which is recorded, kept out of the
    countable denominator, and keeps being polled.

    Which (field, value) pairs ARE authoritative is config-driven and ships
    EMPTY, because that field has not been identified yet. Until it is filled
    in, nothing reaches verdict 'resolved' - and the repeated polling of
    ended markets is precisely the instrument that will reveal the transition.
    """
    rules = rules or {}
    authoritative = rules.get("authoritative_terminal") or []
    void_values = {str(v).upper() for v in (rules.get("void_values") or [])}
    hi_cut = float(rules.get("price_convergence_high", 0.99))
    lo_cut = float(rules.get("price_convergence_low", 0.01))
    price_is_authoritative = bool(rules.get("price_convergence_is_authoritative"))

    out = []
    topic_status = str(detail.get("status") or "").upper()
    for market in detail.get("markets") or []:
        if not isinstance(market, dict):
            continue
        m_status = str(market.get("status") or "").upper()
        t_status = str(market.get("tradingStatus") or "").upper()
        fields = {"status": m_status, "tradingStatus": t_status,
                  "topic_status": topic_status}

        prices = []
        for outcome in market.get("outcomes") or []:
            if not isinstance(outcome, dict):
                continue
            prices.append((outcome.get("name"), outcome.get("price"),
                           outcome.get("index")))

        winner, basis, verdict = None, None, "ended_unresolved"

        # 1. Void beats everything - a voided market has no outcome to count.
        if void_values and any(v in void_values for v in fields.values() if v):
            verdict, basis = "voided", "void_value_match"

        else:
            # 2. Authoritative settlement, if the config names one.
            for rule in authoritative:
                field = rule.get("field")
                wanted = {str(v).upper() for v in (rule.get("values") or [])}
                if field and str(fields.get(field, "")).upper() in wanted:
                    verdict = "resolved"
                    basis = "authoritative:%s=%s" % (field, fields.get(field))
                    break

            # 3. Price convergence - a HINT, never a settlement (unless the
            #    operator deliberately overrides, which PM-2 must not).
            settled = [(n, _num(p, None)) for n, p, _ in prices]
            hi = [(n, v) for n, v in settled if v is not None and v >= hi_cut]
            lo = [(n, v) for n, v in settled if v is not None and v <= lo_cut]
            converged = len(hi) == 1 and bool(lo)

            if verdict == "resolved":
                # Authoritative already fired; price only corroborates.
                if converged:
                    winner = hi[0][0]
                    basis += "+price_agrees"
                else:
                    basis += "+PRICE_DISAGREES"
            elif converged:
                winner = hi[0][0]
                if price_is_authoritative:
                    verdict, basis = "resolved", "price_convergence_OVERRIDE"
                else:
                    verdict, basis = "provisional_price", "price_convergence_not_authoritative"
            elif t_status and t_status not in ("OPEN", "TRADING"):
                basis = "trading_halted_no_winner"
            elif m_status == "CLOSED":
                basis = "market_closed_no_winner"

        out.append({
            "marketId": market.get("marketId"),
            "conditionId": market.get("conditionId"),
            "externalId": market.get("externalId"),
            "question": market.get("question"),
            "verdict": verdict,
            "winner": winner,
            "basis": basis,
            "countable": verdict in COUNTABLE_VERDICTS,
            "topic_status": topic_status,
            "market_status": m_status,
            "trading_status": t_status,
            "outcome_prices": json.dumps(
                [{"name": n, "price": p, "index": i} for n, p, i in prices],
                ensure_ascii=False),
        })
    return out


RESOLUTION_CSV_COLUMNS = [
    "captured_at", "marketTopicId", "marketId", "conditionId", "externalId",
    "slug", "question", "endDate", "verdict", "countable", "winner", "basis",
    "topic_status", "market_status", "trading_status", "outcome_prices",
    "attempts",
]


def append_resolutions(path, rows):
    if not rows:
        return
    exists = os.path.exists(path)
    with open(path, "a", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=RESOLUTION_CSV_COLUMNS,
                                extrasaction="ignore")
        if not exists:
            writer.writeheader()
        for row in rows:
            writer.writerow(row)


def resolution_sweep(client, cfg, registry):
    """Poll registered markets whose endDate has passed until settled or exhausted."""
    rt = cfg.get("resolution_tracking", {})
    if not rt.get("enabled", True):
        return {"skipped": True}, []

    now_ms = int(time.time() * 1000)
    grace = float(rt.get("grace_period_hours", 2)) * 3600000.0
    recheck = float(rt.get("recheck_interval_hours", 6)) * 3600000.0
    max_checks = int(rt.get("max_checks_per_run", 120))
    max_attempts = int(rt.get("max_attempts", 40))

    due = []
    for key, entry in registry.items():
        if entry.get("resolution_state") in ("resolved", "voided", "unresolvable"):
            continue
        end = entry.get("endDate")
        if not end or now_ms < int(end) + grace:
            continue
        last = entry.get("last_attempt_ms")
        if last and now_ms - last < recheck:
            continue
        due.append((key, entry))

    # Oldest-ended first: those are the ones most likely to have settled, and
    # the ones at most risk of ageing out of whatever the venue still serves.
    due.sort(key=lambda kv: kv[1].get("endDate") or 0)
    batch = due[:max_checks]
    log.info("resolution sweep: %d registered markets due, checking %d",
             len(due), len(batch))
    if len(due) > len(batch):
        log.warning("resolution backlog: %d due but max_checks_per_run=%d - "
                    "%d deferred to the next run", len(due), max_checks,
                    len(due) - len(batch))

    rows = []
    counts = Counter()
    workers = int(cfg["rate_limit"].get("max_workers", 4))

    def check(item):
        key, entry = item
        tid = entry["marketTopicId"]
        entry["attempts"] = int(entry.get("attempts", 0)) + 1
        entry["last_attempt_ms"] = now_ms
        try:
            detail = client.call("market_detail", {"marketTopicId": tid},
                                 context={"marketTopicId": tid,
                                          "purpose": "resolution_sweep"})
        except BinanceError as exc:
            # A 4xx here is itself the finding: settled markets may stop being
            # queryable at all. Record it rather than retrying forever.
            entry["last_error"] = str(exc)
            if entry["attempts"] >= max_attempts:
                entry["resolution_state"] = "unresolvable"
                return key, entry, [{"verdict": "unresolvable",
                                     "basis": "detail_error:%s" % exc.status,
                                     "marketId": None}]
            return key, entry, []
        except Exception as exc:
            entry["last_error"] = str(exc)
            return key, entry, []

        if not detail:
            if entry["attempts"] >= max_attempts:
                entry["resolution_state"] = "unresolvable"
            return key, entry, []

        found = extract_resolution(detail, cfg.get("settlement_rules"))

        # Emit a leg ONCE, on the sweep where it first reaches a terminal
        # verdict. Without this, a GROUPED topic with any still-pending leg
        # keeps the whole topic in the queue and re-emits its already-settled
        # legs on every 6-hourly sweep - up to 40 duplicate rows per leg, all
        # of them inflating 0b's denominator. GROUPED averages ~3.2 legs and
        # runs to a dozen-plus on match-score topics, so this is the norm.
        fresh = []
        for item in found:
            mid = str(item.get("marketId"))
            leg = entry["markets"].setdefault(mid, {"marketId": item.get("marketId")})
            prev = leg.get("resolution_state")
            leg["resolution_state"] = item["verdict"]
            leg["basis"] = item["basis"]
            leg["winner"] = item["winner"]
            if item["verdict"] in TERMINAL_VERDICTS and prev not in TERMINAL_VERDICTS:
                fresh.append(item)

        legs = list(entry["markets"].values())
        if legs and all(l.get("resolution_state") in TERMINAL_VERDICTS for l in legs):
            states = {l.get("resolution_state") for l in legs}
            entry["resolution_state"] = ("voided" if states == {"voided"}
                                         else "resolved")
        elif entry["attempts"] >= max_attempts:
            entry["resolution_state"] = "unresolvable"
            # Record where each unsettled leg gave up, so the gap is auditable
            # rather than just missing from the CSV.
            for item in found:
                if item["verdict"] not in TERMINAL_VERDICTS:
                    item = dict(item, verdict="unresolvable",
                                basis="max_attempts:" + str(item["basis"]),
                                countable=False)
                    fresh.append(item)
        return key, entry, fresh

    if batch:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            for key, entry, found in pool.map(check, batch):
                registry[key] = entry
                counts[entry.get("resolution_state", "pending")] += 1
                # `found` is already deduped to legs that newly turned terminal.
                for item in found:
                    row = dict(item)
                    row.update({
                        "captured_at": utcnow().isoformat(),
                        "marketTopicId": entry["marketTopicId"],
                        "slug": entry.get("slug"),
                        "endDate": entry.get("endDate"),
                        "attempts": entry.get("attempts"),
                    })
                    if not row.get("question"):
                        row["question"] = entry.get("question")
                    rows.append(row)

    stats = {
        "registry_size": len(registry),
        "due": len(due),
        "checked": len(batch),
        "deferred": max(0, len(due) - len(batch)),
        "outcomes": dict(counts),
        "rows_written": len(rows),
        "rows_countable": sum(1 for r in rows if r.get("countable")),
        "still_pending": sum(1 for e in registry.values()
                             if e.get("resolution_state")
                             not in TERMINAL_VERDICTS),
        "legs_provisional_price": sum(
            1 for e in registry.values()
            for l in e.get("markets", {}).values()
            if l.get("resolution_state") == "provisional_price"),
    }
    return stats, rows


def probe_resolution(client, cfg):
    """
    Diagnostic for the open question: once a market settles, is it still
    reachable? Answers, with evidence:
      1. Does market/list still return topics whose endDate is in the past?
      2. Does market/detail still answer for them?
      3. What do the status / outcome price fields look like once settled?
    Run this right after --dry-run succeeds.
    """
    now_ms = int(time.time() * 1000)
    print("=" * 66)
    print("RESOLUTION REACHABILITY PROBE")
    print("=" * 66)

    # Oldest-ending first is where already-ended markets would show up.
    data = client.call("market_list", {"offset": 0, "limit": 100,
                                       "sortBy": "END_DATE",
                                       "orderBy": "ASC"}) or {}
    topics = data.get("marketTopics") or []
    print("\n[1] market/list sortBy=END_DATE ASC")
    print("    total reported : %s" % data.get("total"))
    print("    returned       : %d" % len(topics))

    ended = [t for t in topics if t.get("endDate") and int(t["endDate"]) < now_ms]
    print("    with endDate in the PAST : %d" % len(ended))
    statuses = Counter(str(t.get("status")) for t in topics)
    print("    status values seen       : %s" % dict(statuses))

    if not ended:
        print("\n    => market/list appears to serve ONLY live markets.")
        print("       The registry + resolution sweep is therefore MANDATORY:")
        print("       settled outcomes cannot be recovered after the fact.")
        sample = topics[:3]
    else:
        print("\n    => ended markets DO remain listed. Their status values are")
        print("       the settlement signal to key on.")
        sample = ended[:3]

    print("\n[2] market/detail on %d oldest-ending topics" % len(sample))
    for topic in sample:
        tid = topic.get("marketTopicId")
        end = topic.get("endDate")
        age = "n/a" if not end else "%.1f h" % ((now_ms - int(end)) / 3600000.0)
        print("\n  --- topicId=%s  endDate=%s  (ended %s ago)  status=%s"
              % (tid, end, age, topic.get("status")))
        try:
            detail = client.call("market_detail", {"marketTopicId": tid})
        except BinanceError as exc:
            print("      market/detail FAILED: %s" % exc)
            print("      => settled markets are NOT queryable; the sweep must")
            print("         catch them inside the grace window after endDate.")
            continue
        if not detail:
            print("      market/detail returned empty")
            continue
        found = extract_resolution(detail, cfg.get("settlement_rules"))
        print("      topic status      : %s" % detail.get("status"))
        for item in found:
            print("      marketId=%s status=%s trading=%s"
                  % (item["marketId"], item["market_status"],
                     item["trading_status"]))
            print("        verdict=%s winner=%s basis=%s"
                  % (item["verdict"], item["winner"], item["basis"]))
            print("        outcome prices: %s" % item["outcome_prices"])

    print("\n" + "=" * 66)
    print("READ THIS OFF THE OUTPUT ABOVE:")
    print("  - if verdict=resolved with basis=price_convergence, settlement is")
    print("    readable from outcome prices and 0b's denominator is safe")
    print("  - if every verdict=ended_unresolved, the status fields do not")
    print("    encode the winner: report back and the extractor needs a new rule")
    print("  - if market/detail 4xx's on ended topics, tighten grace_period_hours")
    print("    so the sweep fires before markets become unreachable")
    print("=" * 66)
    return 0


# ---------------------------------------------------------------- output

def write_output(cfg, records, stats, errors, snapshot_id, started, client):
    out = cfg["output"]
    use_gzip = out.get("gzip", True)
    day = started.strftime("%Y-%m-%d")

    data_dir = os.path.join(HERE, out.get("data_dir", "data"), day)
    os.makedirs(data_dir, exist_ok=True)
    path = os.path.join(data_dir, "snap_%s.ndjson%s"
                        % (snapshot_id, ".gz" if use_gzip else ""))
    tmp = path + ".part"

    header = {
        "_type": "snapshot_meta",
        "snapshot_id": snapshot_id,
        "recorder_version": "1.0",
        "source": "binance_w3w_prediction",
        "started_at": started.isoformat(),
        "finished_at": utcnow().isoformat(),
        "duration_sec": round((utcnow() - started).total_seconds(), 1),
        "selection": cfg["selection"],
        "stats": stats,
        "errors": errors[:50],
        "error_count": len(errors),
    }

    def opener(p):
        if use_gzip:
            return gzip.open(p, "wt", encoding="utf-8")
        return open(p, "w", encoding="utf-8")

    with opener(tmp) as fh:
        fh.write(json.dumps(header, ensure_ascii=False) + "\n")
        for rec in records:
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
    os.replace(tmp, path)
    log.info("wrote %s (%d records, %d bytes)", path, len(records),
             os.path.getsize(path))

    raw_path = None
    if out.get("archive_raw_responses") and client.raw_records:
        raw_dir = os.path.join(HERE, out.get("raw_dir", "raw"), day)
        os.makedirs(raw_dir, exist_ok=True)
        raw_path = os.path.join(raw_dir, "raw_%s.ndjson%s"
                                % (snapshot_id, ".gz" if use_gzip else ""))
        rtmp = raw_path + ".part"
        with opener(rtmp) as fh:
            for rec in client.raw_records:
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
        os.replace(rtmp, raw_path)
        log.info("wrote raw archive %s (%d responses)", raw_path,
                 len(client.raw_records))

    return path, raw_path


# ---------------------------------------------------------------- lock

class RunLock:
    """Prevents overlapping cron runs (a slow run must not collide with the next tick)."""

    def __init__(self, path, stale_sec=1800):
        self.path = path
        self.stale_sec = stale_sec
        self.held = False

    def __enter__(self):
        if os.path.exists(self.path):
            age = time.time() - os.path.getmtime(self.path)
            if age < self.stale_sec:
                raise SystemExit("another run is in progress (lock age %.0fs): %s"
                                 % (age, self.path))
            log.warning("removing stale lock (age %.0fs)", age)
            os.remove(self.path)
        with open(self.path, "w") as fh:
            fh.write(str(os.getpid()))
        self.held = True
        return self

    def __exit__(self, *exc):
        if self.held and os.path.exists(self.path):
            os.remove(self.path)
        return False


# ---------------------------------------------------------------- main

def setup_logging(cfg, verbose):
    log_dir = os.path.join(HERE, cfg["output"].get("log_dir", "logs"))
    os.makedirs(log_dir, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)-7s %(message)s")
    log.setLevel(logging.DEBUG if verbose else logging.INFO)
    log.handlers[:] = []

    fh = logging.FileHandler(os.path.join(log_dir, "recorder.log"), encoding="utf-8")
    fh.setFormatter(fmt)
    log.addHandler(fh)
    sh = logging.StreamHandler(sys.stderr)
    sh.setFormatter(fmt)
    log.addHandler(sh)


def main():
    ap = argparse.ArgumentParser(description="PM-2 Binance prediction market recorder")
    ap.add_argument("--config", default=os.path.join(HERE, "config.json"))
    ap.add_argument("--env", default=os.path.join(HERE, ".env"),
                    help="KEY=VALUE file with BINANCE_API_KEY / BINANCE_API_SECRET")
    ap.add_argument("--dry-run", action="store_true",
                    help="probe auth with one cheap call, write nothing")
    ap.add_argument("--probe-resolution", action="store_true",
                    help="check whether settled markets stay queryable "
                         "(run this right after --dry-run succeeds)")
    ap.add_argument("--max-topics", type=int, help="override selection.max_topics")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    with open(args.config, "r", encoding="utf-8") as fh:
        cfg = json.load(fh)
    if args.max_topics is not None:
        cfg["selection"]["max_topics"] = args.max_topics

    setup_logging(cfg, args.verbose)
    load_env_file(args.env)

    api_key = os.environ.get("BINANCE_API_KEY", "").strip()
    api_secret = os.environ.get("BINANCE_API_SECRET", "").strip()
    if not api_key or not api_secret:
        log.error("BINANCE_API_KEY / BINANCE_API_SECRET not set (checked env and %s)",
                  args.env)
        return 2

    client = PredictionClient(cfg, api_key, api_secret)

    if args.dry_run:
        log.info("dry-run: category/list to verify credentials, signing and IP allowlist")
        try:
            data = client.call("category_list", {})
        except BinanceError as exc:
            log.error("DRY-RUN FAILED: %s", exc)
            if exc.status == 401 or exc.code in (-2015, -2014):
                log.error("-> bad API key, missing permission, or THIS IP IS NOT "
                          "WHITELISTED. Re-run on the VPS whose IP is on the allowlist.")
            elif exc.code == -1022:
                log.error("-> signature mismatch")
            elif exc.code == -1021:
                log.error("-> timestamp outside recvWindow; sync the clock (ntp)")
            return 1
        except Exception as exc:
            log.error("DRY-RUN FAILED (transport): %s", exc)
            return 1
        print(json.dumps(data, ensure_ascii=False, indent=2)[:4000])
        log.info("dry-run OK - credentials, signing and IP allowlist all good")
        return 0

    if args.probe_resolution:
        try:
            return probe_resolution(client, cfg)
        except BinanceError as exc:
            log.error("resolution probe failed: %s", exc)
            return 1

    started = utcnow()
    snapshot_id = stamp(started)
    now_ms = int(started.timestamp() * 1000)

    with RunLock(os.path.join(HERE, ".recorder.lock")):
        log.info("=== snapshot %s start ===", snapshot_id)
        try:
            records, stats, errors = capture(client, cfg, snapshot_id, now_ms)
        except BinanceError as exc:
            log.error("snapshot aborted: %s", exc)
            return 1

        # Registry first, sweep second: a market seen this run must be written
        # down before anything can go wrong later in the run.
        reg_path = _state_path(cfg, "registry_path", "state/registry.json")
        registry = load_registry(reg_path)
        added = register_snapshot(registry, records, now_ms)
        save_registry(reg_path, registry)
        log.info("registry: %d entries (+%d new this run)", len(registry), added)

        try:
            sweep_stats, rows = resolution_sweep(client, cfg, registry)
            if rows:
                append_resolutions(
                    _state_path(cfg, "resolutions_csv", "state/resolutions.csv"),
                    rows)
            save_registry(reg_path, registry)
            log.info("resolution sweep: %s", json.dumps(sweep_stats))
            stats["resolution_sweep"] = sweep_stats
        except Exception as exc:
            # A failed sweep must never cost us the snapshot that already succeeded.
            log.error("resolution sweep failed (snapshot is unaffected): %s", exc)
            stats["resolution_sweep"] = {"error": str(exc)}

        path, raw_path = write_output(cfg, records, stats, errors,
                                      snapshot_id, started, client)
        log.info("=== snapshot %s done in %.1fs - %s ===", snapshot_id,
                 (utcnow() - started).total_seconds(), json.dumps(stats))
        print(path)
        if raw_path:
            print(raw_path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
