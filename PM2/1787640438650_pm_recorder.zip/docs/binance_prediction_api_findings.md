# Binance Prediction Markets API — 文件確認結果
**查閱日期:2026-08-24 ｜ 來源:developers.binance.com(新版文件站)**

## 0. 一句話結論

**REST 可用。** 市場清單、市場詳情、訂單簿、最新成交價全部有 REST 端點。
WebSocket 是「額外的即時推播通道」,不是唯一途徑 —— 官方 orderbook 文件自己寫:
斷線重連後「first fetch a snapshot via REST API, then apply WSS deltas」。
**錄影機走純 REST 即可,不需要補 WS 版。**

## 1. 文件路徑更正

使用者給的 `developers.binance.com/docs/w3w_prediction` 已非有效路徑(會 302 回首頁)。
現行位置:

| 內容 | URL |
|---|---|
| REST API Reference | `/en/docs/catalog/web3-wallet-prediction-trading/api/rest-api` |
| OpenAPI 3.1.1 spec | 打包在 `/en/docs/assets/catalog_web3_wallet_prediction_trading_api_rest_api-w3w-prediction.yaml-*.js` |
| WS Orderbook | `/en/docs/products/w3w-prediction/websocket-api/orderbook.md` |
| WS 整合指南 | `/en/docs/products/w3w-prediction/websocket-api/integration-guide.md` |
| Change Log | `/en/docs/products/w3w-prediction/change-log.md` |
| 機器可讀索引 | `/en/docs/llms.txt` / `/en/docs/llms-full.txt` |

注意:該站是 SPA + 反爬(curl 直接拿會得到 HTTP 202 空 body 或 SPA 殼)。
要抓文件必須用瀏覽器同源 fetch,或走 `llms.txt`。

## 2. 產品定位

- API 名稱:**Prediction Trading REST API v1.0.0**,歸類在 Web3 Wallet 之下,共 36 個端點。
- 上游造市商是 **Predict.fun**(幣安轉包,不是幣安自營訂單簿)。
  → 這點對 PM-2 §5「Polymarket→幣安遷移驗證」有影響,見下方風險。
- Base URL:`https://api.binance.com`(備援 `api-gcp` / `api1~4.binance.com`)

## 3. 市場數據端點(market-data tag,共 6 支)

| 方法 | 路徑 | 用途 |
|---|---|---|
| GET | `/sapi/v1/w3w/wallet/prediction/category/list` | 分類清單(L1/L2) |
| GET | `/sapi/v1/w3w/wallet/prediction/market/list` | **市場清單(分頁)** |
| GET | `/sapi/v1/w3w/wallet/prediction/market/search` | 關鍵字搜尋 |
| GET | `/sapi/v1/w3w/wallet/prediction/market/detail` | **市場詳情(含 outcomes + tokenId)** |
| GET | `/sapi/v1/w3w/wallet/prediction/order-book` | **訂單簿(bids/asks)** |
| GET | `/sapi/v1/w3w/wallet/prediction/order-book/last-trade-price` | 最新成交價 |

## 4. 簽名方式 ⚠️ 全部都要簽

OpenAPI spec 上這 6 支 market-data 端點**每一支都標 `x-signed: true`**。
雖然它們沒有 `(PREDICTION_TRADE)` 權限標籤(那是帳戶/下單端點才有),
但**不是公開端點** —— 沒有憑證抓不到任何一筆行情。

簽名規格(標準 Binance SAPI):
- Header:`X-MBX-APIKEY: <api_key>`
- `timestamp`(毫秒)為**必填** query 參數
- `signature = HMAC_SHA256(secret_key, query_string)`,hex 輸出
- REST:簽的是**送出時的 query string 原順序**(不需排序)
- WSS:整合指南明寫要**依參數名字母排序**後才簽 —— 兩者規則不同,別混用

## 5. 速率限制 ⚠️ 這是錄影機的主要設計約束

- 每支 market-data 端點 `x-ip-weight: **200**`(很重)
- 文件:「Each endpoint with IP limits has an **independent** 12000 per minute limit.」
  → **每支端點各自** 12000/min ÷ 200 = **每分鐘 60 次**
- 回應 header `X-SAPI-USED-IP-WEIGHT-1M` 可即時讀取已用量
- 超限 429 → 續超會升級 418(IP ban)

實務推算:單輪要抓 N 個市場,order-book 就要 N 次呼叫 = N/60 分鐘。
N=150 → 2.5 分鐘;N=600 → 10 分鐘。cron 每 20 分鐘一輪,**必須設市場數上限**。
好消息是各端點預算獨立,detail / order-book / last-trade-price 可並行跑。

## 6. 關鍵回應欄位

### market/list
分頁:`offset`(預設 0)、`limit`(預設 20,**上限 100**)、`sortBy`
(`RECOMMENDED|VOLUME|PARTICIPANTS|CREATED_TIME|END_DATE`)、`orderBy`(`ASC|DESC`)、
`l1Category` / `l2Category`。回傳 `total` / `offset` / `limit` / `hasMore`。

每筆 `marketTopics[]`:
`marketTopicId, vendor, chainId, slug, title, question, description, topicType,
 chartType, symbol, participantCount, collateral, feeRateBps, slippageBps,
 isYieldBearing, tradeVolume, liquidity, publishedAt, startDate, endDate, status, markets[]`

> `feeRateBps` / `slippageBps` 直接給實際費率 —— **這正是 §4 說 0b 要用「實際費率」取代
> 1.0% 佔位假設的資料來源**,不必再猜。

### market/detail(參數 `marketTopicId`)
在 list 欄位之外多給 `variantData`、`timeline[]`,以及展開的:
```
markets[].marketId, externalId, conditionId, status, tradingStatus,
          tradeVolume, liquidity, decimalPrecision,
markets[].outcomes[].name, price, chance, index, tokenId
```
**`tokenId` 只在這裡拿得到 —— 而 order-book 必須用 tokenId 查。**
(list 回應的 `markets[]` 在 spec 裡是未展開的泛型 object,實跑時再確認有無 tokenId;
 有就能省掉一半呼叫,recorder 已做這個 fallback。)

### order-book(參數 `vendor`, `marketId`, `tokenId`)
```json
{"outcome":"Yes","tokenId":"...","timestamp":1717420800123,
 "bids":[{"price":"0.31","size":"800"}, ...],
 "asks":[{"price":"0.32","size":"500"}, ...]}
```
價格 ∈ (0,1),字串傳輸(避免浮點失真,用 Decimal 解析)。深度上游通常 ≤ 50 檔。

### order-book/last-trade-price(參數 `marketId`)
`{"marketId":123,"lastTradePrice":"0.32"}`

## 7. WebSocket(備查,本階段不用)

- `wss://api.binance.com/sapi/wss?random=&topic=&recvWindow=30000&timestamp=&signature=`
- topic:`web3_prediction_orderbook_{marketId}`(單市場)或
  `web3_prediction_orderbook_data`(聚合,一條流涵蓋所有市場)
- envelope 的 `data` 是**字串化 JSON,要二次 parse**
- at-most-once、**不保證順序**(用 `updateTimestampMs` 排序)、離線不補發
- 單連線 24h 需重連;每連線 5 msg/s;每 30s 送 PING
- 只推「活躍市場」,已結算/關閉市場不推

> 若日後 0b 需要 tick 級深度而非 20 分鐘快照,聚合 topic 是正解 —— 一條連線省掉
> 全部 order-book REST 呼叫,也繞開 60 次/分的天花板。目前 20 分鐘粒度用 REST 足夠。

## 8. 已知雷(文件自陳)

`POST .../trade/batch-cancel` 用 `cancelInfoList[0].orderId` 這種中括號索引參數,
但 Binance 簽名驗的是**未編碼原字串**,而 Python `requests` / Java / Go / Node 都會自動把
`[` `]` 百分比編碼 → 簽名不符。0a/0b 只讀行情不下單,暫不受影響,但 C 軌真要下單時會踩。

## 9. 對 PM-2 章程的影響(交叉引用)

1. **§4 費用假設**:`feeRateBps` + `slippageBps` 已由 API 直供,0b 不必估。
2. **§5 遷移驗證**:幣安的預測市場**是 Predict.fun 的轉包**,不是獨立場。
   「Polymarket→幣安遷移驗證(兩場同期分桶偏差同號)」的前提是兩個**獨立**市場;
   若 Predict.fun 與 Polymarket 流動性高度重疊或由同批做市商套利連動,
   「同號」會是機械性的,**不構成獨立驗證**。此點需在章程審查中提出。
3. **本 API 沒有歷史資料端點** —— 36 支端點全是即時/帳戶類,無 price history。
   這正是錄影機存在的理由(自己累積),也意味著 0a 的歷史只能靠 Polymarket。
