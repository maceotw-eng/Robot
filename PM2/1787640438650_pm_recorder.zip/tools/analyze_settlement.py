#!/usr/bin/env python3
"""
R-02: identify the AUTHORITATIVE settlement signal from real captured data.

Run on the Tokyo box against the recorder's raw archive:

    python3 analyze_settlement.py ~/pm_recorder/raw
    python3 analyze_settlement.py ~/pm_recorder/raw --out r02_evidence.json

Stdlib only. Read-only - it never writes into the recorder's data.

WHY THIS EXISTS
---------------
The recorder must know which markets actually settled, because that is 0b's
denominator. The tempting shortcut is to read the outcome off the price
(0.999 / 0.001). That shortcut is disqualifying: PM-2 asks whether price
predicts outcome, so deriving outcome from price makes the question circular,
and dropping markets whose price never converged is selection on the very
variable under study. Both biases point the same way.

So the authoritative signal has to be a field that is independent of price.
This tool does not guess which one it is - it measures:

  A. Schema census of market objects: every field, how often present, values.
  B. Cross-tab of (topic.status, market.status, market.tradingStatus) against
     price convergence and against whether endDate has passed.
  C. Status transitions per market across snapshots - the settlement moment.
  D. Candidate ranking: which (field, value) best separates settled-looking
     markets from still-live ones, scored independently of price.
"""

import argparse
import glob
import gzip
import json
import os
import sys
from collections import Counter, defaultdict

DAY_MS = 86400000
HI, LO = 0.99, 0.01


def num(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def open_maybe_gz(path):
    if path.endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8")
    return open(path, "r", encoding="utf-8")


def iter_raw_records(root):
    """Yield (snapshot_file, fetched_at_ms, topic_dict) from raw archives."""
    files = sorted(glob.glob(os.path.join(root, "**", "*.ndjson*"), recursive=True))
    if not files:
        print("no raw files under %s" % root, file=sys.stderr)
    for path in files:
        base = os.path.basename(path)
        try:
            with open_maybe_gz(path) as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    endpoint = rec.get("endpoint")
                    resp = rec.get("response")
                    ts = rec.get("fetched_at_ms")
                    if endpoint == "market_list" and isinstance(resp, dict):
                        for topic in resp.get("marketTopics") or []:
                            yield base, ts, topic
                    elif endpoint == "market_detail" and isinstance(resp, dict):
                        yield base, ts, resp
        except OSError as exc:
            print("skipping %s: %s" % (path, exc), file=sys.stderr)


def convergence(market):
    prices = [num(o.get("price")) for o in (market.get("outcomes") or [])
              if isinstance(o, dict)]
    prices = [p for p in prices if p is not None]
    if not prices:
        return None
    hi = [p for p in prices if p >= HI]
    lo = [p for p in prices if p <= LO]
    return len(hi) == 1 and bool(lo)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("raw_root", help="path to pm_recorder/raw")
    ap.add_argument("--out", default="r02_evidence.json")
    args = ap.parse_args()

    market_fields = Counter()
    market_types = defaultdict(Counter)
    market_samples = defaultdict(list)
    topic_status_values = Counter()

    combos = Counter()
    combo_detail = defaultdict(lambda: {"converged": 0, "not_converged": 0,
                                        "unknown_conv": 0, "past_end": 0,
                                        "before_end": 0, "n": 0})
    timeline = defaultdict(list)   # marketId -> [(ts, combo, converged)]
    total_markets = 0

    for _, ts, topic in iter_raw_records(args.raw_root):
        t_status = str(topic.get("status") or "")
        topic_status_values[t_status] += 1
        end = topic.get("endDate")

        for market in topic.get("markets") or []:
            if not isinstance(market, dict):
                continue
            total_markets += 1

            for key, val in market.items():
                if val in (None, "", [], {}):
                    continue
                market_fields[key] += 1
                market_types[key][type(val).__name__] += 1
                bucket = market_samples[key]
                text = str(val)[:70]
                if len(bucket) < 5 and text not in bucket:
                    bucket.append(text)

            m_status = str(market.get("status") or "")
            tr_status = str(market.get("tradingStatus") or "")
            combo = "topic=%s | market=%s | trading=%s" % (t_status, m_status, tr_status)
            combos[combo] += 1

            conv = convergence(market)
            rec = combo_detail[combo]
            rec["n"] += 1
            if conv is True:
                rec["converged"] += 1
            elif conv is False:
                rec["not_converged"] += 1
            else:
                rec["unknown_conv"] += 1
            if end and ts:
                if int(ts) > int(end):
                    rec["past_end"] += 1
                else:
                    rec["before_end"] += 1

            mid = market.get("marketId")
            if mid is not None and ts:
                timeline[mid].append((int(ts), combo, conv))

    # ---- C. transitions -------------------------------------------------
    transitions = Counter()
    changed = 0
    for mid, points in timeline.items():
        points.sort()
        prev = None
        for _, combo, _ in points:
            if prev is not None and combo != prev:
                transitions["%s   ==>   %s" % (prev, combo)] += 1
                changed += 1
            prev = combo

    # ---- D. candidate ranking -------------------------------------------
    # A useful authoritative signal separates markets cleanly and is not just a
    # restatement of price. Score each combo by how one-sided its convergence is
    # AND flag combos that mix converged and un-converged (those cannot settle).
    candidates = []
    for combo, rec in combo_detail.items():
        known = rec["converged"] + rec["not_converged"]
        if known == 0:
            continue
        purity = rec["converged"] / known
        candidates.append({
            "combo": combo,
            "n": rec["n"],
            "converged": rec["converged"],
            "not_converged": rec["not_converged"],
            "convergence_purity": round(purity, 4),
            "past_end": rec["past_end"],
            "before_end": rec["before_end"],
            "verdict": ("clean-settled-looking" if purity >= 0.99 else
                        "clean-live-looking" if purity <= 0.01 else
                        "MIXED - cannot be an authoritative settlement signal"),
        })
    candidates.sort(key=lambda c: (-c["convergence_purity"], -c["n"]))

    out = {
        "raw_root": os.path.abspath(args.raw_root),
        "total_market_observations": total_markets,
        "topic_status_values": dict(topic_status_values),
        "market_field_census": {
            k: {"present": v,
                "present_pct": round(100.0 * v / max(1, total_markets), 1),
                "types": dict(market_types[k]),
                "samples": market_samples[k]}
            for k, v in market_fields.most_common()
        },
        "status_combos": dict(combos.most_common()),
        "combo_analysis": candidates,
        "status_transitions_observed": dict(transitions.most_common(40)),
        "markets_that_changed_status": changed,
        "distinct_markets_tracked": len(timeline),
    }

    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=2, ensure_ascii=False)

    # ---- report ---------------------------------------------------------
    print("=" * 78)
    print("R-02 SETTLEMENT SIGNAL EVIDENCE")
    print("=" * 78)
    print("market observations : %d over %d distinct markets"
          % (total_markets, len(timeline)))
    print("topic.status values : %s" % dict(topic_status_values))

    print("\n-- market-level fields (looking for a price-independent settlement flag) --")
    for key, info in list(out["market_field_census"].items()):
        if any(w in key.lower() for w in
               ("status", "resolv", "settl", "winner", "payout", "outcome",
                "closed", "void", "result", "final")):
            print("  %-22s %5.1f%%  %s" % (key, info["present_pct"],
                                           " ; ".join(info["samples"])[:80]))

    print("\n-- status combinations vs price convergence --")
    print("  %-58s %6s %6s %7s" % ("combo", "n", "conv", "purity"))
    for cand in candidates[:20]:
        print("  %-58s %6d %6d %7.3f  %s"
              % (cand["combo"][:58], cand["n"], cand["converged"],
                 cand["convergence_purity"], cand["verdict"]))

    print("\n-- observed status transitions (the settlement moment) --")
    if transitions:
        for text, count in transitions.most_common(15):
            print("  %5d x  %s" % (count, text))
    else:
        print("  none yet - needs snapshots spanning a settlement event.")
        print("  Re-run after the recorder has been up across at least one")
        print("  market's endDate plus its settlement lag.")

    print("\n" + "=" * 78)
    print("HOW TO READ THIS")
    print("  1. If some field (not price) flips exactly when a market settles,")
    print("     that is the authoritative signal -> put it in config.json under")
    print("     settlement_rules.authoritative_terminal and legs become countable.")
    print("  2. Any combo marked MIXED cannot be authoritative: it contains both")
    print("     converged and un-converged markets, so it does not encode outcome.")
    print("  3. If NO price-independent field separates them, the venue does not")
    print("     publish settlement. Then 0b's denominator must come from the")
    print("     on-chain conditionId payouts, not from this API.")
    print("=" * 78)
    print("wrote %s" % os.path.abspath(args.out))
    return 0


if __name__ == "__main__":
    sys.exit(main())
