# PM-2 0a 開火指令包(2026-08-28)

**章程:**`PM2_charter_v1.1_FROZEN_rev3.md`
**sha256:**`f328708703b49772c5745f6643dca759d91bde1bc47593ac2794e56b8ad253b9`(30,020 bytes)
**驗收:**誤放率 **2.6%**(線 6.4%)｜ +2% 偵測力 **91.0%**(線 70%)→ **兩項通過,視同蓋章**

---

## 一、上傳到 GitHub `Robot/PM2/`

| 檔案 | 用途 |
|---|---|
| `analysis/sample_markets.py` | 抽樣(100,000,種子 20260827) |
| `analysis/fetch_checkpoints.py` | **抓價格(主體,~15 小時)** |
| `analysis/pm2_pipeline.py` | 分析出判決 |
| `analysis/measure_t30_cohort.py` | T=30 全世代精確缺席率(並行) |
| `PM2_charter_v1.1_FROZEN_rev3.md` | 凍結章程 |

---

## 二、SSH 進東京機,貼這段(抽樣)

```bash
cd ~/pm2 && mkdir -p 0a && cd 0a
python3 sample_markets.py ~/pm_recorder/probe_state/harvest_stream.ndjson \
        --out sample_100k.ndjson --audit sample_audit.json 2>&1 | tee sample.log
```

**看三個數再往下走:**

1. `strict-payout eligible` 必須 **= 313,023**(章程 §2.0.1)。不符就**停**,回報。
2. `FINAL eligible` = 313,023 − 終局爭議重疊(裁決 O-1(a),此數為執行產物)
3. `sample id-set sha256` —— 抄下來,那是這次抽樣的指紋

---

## 三、開火:掛機抓價(~15 小時)

```bash
cd ~/pm2/0a
setsid nohup python3 fetch_checkpoints.py sample_100k.ndjson \
       --out observations.ndjson --rate 3.0 > fetch.log 2>&1 &
echo "PID $!"
```

**`setsid` 不能省** —— v7 那次無聲死亡是 SSH 連坐,不是 OOM。

看進度(**不要看終端機,看心跳檔**):

```bash
cat ~/pm2/0a/fetch_heartbeat.json
wc -l ~/pm2/0a/observations.ndjson
```

**斷線、重開機、手滑 Ctrl-C 都不用怕**:重跑同一行指令會自動跳過已完成的
(market, window),不會重抓也不會重複寫。

---

## 四、並行:T=30 全世代精確測量(章程 §3.3.1)

另開一個 session,同時跑:

```bash
cd ~/pm2/0a
setsid nohup python3 measure_t30_cohort.py \
       ~/pm_recorder/probe_state/harvest_stream.ndjson \
       --out t30_absence.json --rate 2.0 > t30.log 2>&1 &
```

約 2 萬次查詢,數小時。**這是 §3.3.1 的凍結義務:T=30 缺席率以全世代精確計算,
不以抽樣估計;精確值 > 30% → 降級標註自動生效,無裁量。**

---

## 五、兩者落地後出判決

```bash
cd ~/pm2/0a
python3 pm2_pipeline.py observations.ndjson \
        --cohort-sizes "$(python3 -c "
import json;d=json.load(open('t30_absence.json'))
print(json.dumps({'1':d['cohort_sizes']['1'],'7':d['cohort_sizes']['7'],'30':d['cohort_sizes']['30']}))")" \
        --out pm2_result.json --report pm2_report.md
```

產出 `pm2_report.md`:30 格三態矩陣 + 排除原因分解表 + 判決。

---

## 六、判讀(三態,章程 §5.0)

| 狀態 | 意義 | 後續 |
|---|---|---|
| **存活** | 六關全過 | 進 0b |
| **證據死** | 偵測力 ≥50% 且未存活 | 有能力看見而沒看見 → 永久閉庭 |
| **無偵測力** | 偵測力 <50% | **不判死**,歷史數據增長後可重審 |

**若無任一格存活且無任何格達證據死 → 全案判「無偵測力」,不是「死亡」。**

預期 (T=30, 90-95¢) 會判「無偵測力」—— 該格腿數上限約 495,偵測力約 9%,
即使全量普查亦然。這是宇宙的形狀,不是缺陷。

---

## 七、順便(與 0a 無關,但仍未做)

錄影機 R-01~R-03 升級包**還沒部署**,重複列 bug 每 6 小時繼續產生髒資料 ——
那是 0b 的分母。指令在 `docs/PM2_本週待辦_20260827.md`,含去重腳本。
另 `analyze_settlement.py` 從沒跑過,那是章程 §2.2 幣安側唯一待填格。
