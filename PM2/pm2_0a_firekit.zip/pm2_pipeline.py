#!/usr/bin/env python3
"""
PM-2 0a analysis pipeline - the 30-cell calibration matrix and the verdict.

Implements charter v1.1 exactly:
  3.4  ten price buckets x three windows = 30 cells
  3.5  implied probability, actual frequency, deviation, both tradable directions
  3.6  CLUSTER bootstrap, 10,000 draws, resampling EVENT CLUSTERS not legs
  3.6  FDR (Benjamini-Hochberg, q=0.05) over cells that actually qualify
  3.7  stratified cuts: category / year (four layers) / liquidity
  3.3  per-window absence rate with the 30% and 60% downgrade rules
  5    survival criteria 1-4 and the death verdict

Stdlib only. Input is one JSON object per market-window observation:

    {"market_id":..., "cluster_id":..., "window":1|7|30, "price":0.62,
     "outcome":1|0, "category":"crypto", "year":"2025", "liquidity":12345.0}

`cluster_id` is the resampling unit (charter 3.6): the event, not the leg.
Absent observations are simply not present; supply `--cohort-sizes` so absence
rates are computed against the cohort denominator (charter 3.0), not against
whatever happened to be fetched.
"""

import argparse
import json
import math
import random
import sys
from collections import Counter, defaultdict

BUCKETS = [(1, 5), (5, 10), (10, 20), (20, 35), (35, 50),
           (50, 65), (65, 80), (80, 90), (90, 95), (95, 99)]
WINDOWS = [1, 7, 30]
BOOTSTRAP_DRAWS = 10000
FDR_Q = 0.05
MIN_LEGS = 100            # charter 5 criterion 1
MIN_CLUSTERS = 30         # charter 3.6 "cluster count insufficient" flag
COST_ROUNDTRIP = 0.01     # charter 4 placeholder, frozen
ABSENCE_DOWNGRADE = 0.30  # charter 3.3
ABSENCE_REJECT = 0.60     # charter 3.3

# ---- three-state verdict (rev3, ruling 2 of 2026-08-28) --------------------
# A cell that could never have detected the effect must not be reported as
# evidence of absence. Every cell now carries its own measured detection power
# against a reference effect; cells below the floor are returned UNDERPOWERED,
# not DEAD. Death is reserved for cells that had the power to see something and
# did not. Without this, "all 30 cells died" conflates "no signal" with
# "no spectacles" - which is its own kind of false statement.
POWER_REFERENCE_EFFECT = 0.02   # the +2% the power simulation is priced against
POWER_FLOOR = 0.50              # below this the cell is UNDERPOWERED, not dead


def bucket_of(price_cents):
    for lo, hi in BUCKETS:
        if lo <= price_cents < hi:
            return "%d-%d" % (lo, hi)
    if price_cents == 99:
        return "95-99"
    return None


def label(lo_hi):
    return lo_hi


# --------------------------------------------------------------- statistics

try:
    import numpy as _np
except ImportError:                       # VPS runs stdlib-only; that path still works
    _np = None


def _cluster_sums(observations):
    """
    Collapse each cluster to (sum_outcome, sum_price, n_legs).

    A bootstrap draw only ever needs these three numbers per cluster, because
    the statistic is a ratio of sums. Resampling clusters and then re-summing
    their legs one at a time computes the identical quantity the slow way.
    """
    acc = {}
    for obs in observations:
        rec = acc.get(obs["cluster_id"])
        if rec is None:
            acc[obs["cluster_id"]] = [obs["outcome"], obs["price"], 1]
        else:
            rec[0] += obs["outcome"]
            rec[1] += obs["price"]
            rec[2] += 1
    return list(acc.values())


LARGE_CLUSTERS = 4000     # above this the bootstrap is replaced by its own limit


def cluster_robust_se(clusters, point):
    """
    The cluster bootstrap's large-sample limit, in closed form.

    With u_c = (sum_outcome_c - sum_price_c) - dev * legs_c, the resampling
    variance of dev is sum(u_c^2) / M^2 where M is the total leg count. This is
    the standard cluster-robust (sandwich) standard error, and it is exactly
    what the percentile bootstrap converges to as the number of clusters grows.

    Used for two things: a fast path for very large cells (the sensitivity study
    reaches 100k-market samples, where a 10,000-draw resample is neither
    affordable nor more accurate), and the standard error the per-cell power
    calculation needs.
    """
    legs = sum(c[2] for c in clusters)
    if legs == 0:
        return 0.0
    acc = 0.0
    for out_s, pri_s, cnt in clusters:
        u = (out_s - pri_s) - point * cnt
        acc += u * u
    return (acc ** 0.5) / legs


def bootstrap_cell(observations, draws, rng):
    """
    One resample set -> both the CI and the p-value (charter 3.6).

    Previously the CI and the p-value were computed from two INDEPENDENT
    bootstrap runs. Deriving both from the same set of draws is cheaper and
    also more coherent: the reported interval and the reported p-value now
    describe the same resample distribution rather than two different ones.

    Uses numpy when present. The numpy and stdlib paths implement the same
    estimator and are checked against each other in the test suite; they differ
    only in which RNG draws the cluster indices.
    """
    clusters = _cluster_sums(observations)
    n = len(clusters)
    if n == 0:
        return None, None, 1.0

    legs = sum(c[2] for c in clusters)
    point = (sum(c[0] for c in clusters) / legs) - (sum(c[1] for c in clusters) / legs)

    # ---- variance floor (added 2026-08-28 after the power simulation) -------
    # The empirical bootstrap resamples the OBSERVED outcomes. In a cell where
    # every observed outcome is identical - all losers in the 1-5c bucket, all
    # winners in 95-99c - every resample returns the same mean, the variance
    # collapses to zero, and the interval certifies a deviation it cannot
    # actually distinguish from chance. Measured example: 139 markets at 2c
    # with zero winners (a 6%-probability, entirely ordinary draw) produced
    # CI [-0.0209, -0.0195] and p = 0.00005.
    #
    # That failure fires hardest in the two extreme buckets, which are exactly
    # where charter 7's prior expects any real effect to live, so it manufactures
    # false positives in the most consequential place.
    #
    # Floor: under the null each leg is Bernoulli(price), so the deviation has
    # sd = sqrt(sum p_i(1-p_i)) / n_legs even before any clustering inflates it.
    # The sample cannot be more certain than the model. When the bootstrap comes
    # back tighter than this, fall back to the model-based interval and say so.
    var_floor = sum(o["price"] * (1.0 - o["price"]) for o in observations)
    sd_floor = (var_floor ** 0.5) / legs if legs else 0.0

    if n > LARGE_CLUSTERS:
        # Large cell: use the bootstrap's closed-form limit. Verified against
        # the resampling path in the test suite at the crossover size.
        se = max(cluster_robust_se(clusters, point), sd_floor)
        lo = point - 1.959964 * se
        hi = point + 1.959964 * se
        pv = math.erfc(abs(point) / se / math.sqrt(2.0)) if se > 0 else 1.0
        return lo, hi, min(1.0, max(1.0 / draws, pv))

    if _np is not None:
        arr = _np.asarray(clusters, dtype=_np.float64)
        out_s, pri_s, cnt_s = arr[:, 0], arr[:, 1], arr[:, 2]
        seed = rng.randrange(2 ** 31)
        gen = _np.random.RandomState(seed)
        stats = _np.empty(draws, dtype=_np.float64)
        step = max(1, min(draws, int(4_000_000 // max(1, n))))
        done = 0
        while done < draws:
            block = min(step, draws - done)
            idx = gen.randint(0, n, size=(block, n))
            tot_out = out_s[idx].sum(axis=1)
            tot_pri = pri_s[idx].sum(axis=1)
            tot_cnt = cnt_s[idx].sum(axis=1)
            stats[done:done + block] = (tot_out - tot_pri) / tot_cnt
            done += block
        stats.sort()
        lo = float(stats[int(0.025 * draws)])
        hi = float(stats[min(draws - 1, int(0.975 * draws))])
        crossed = int((stats <= 0).sum() if point >= 0 else (stats >= 0).sum())
        sd_boot = float(stats.std())
    else:
        stats = []
        crossed = 0
        for _ in range(draws):
            t_out = t_pri = t_cnt = 0.0
            for _ in range(n):
                c = clusters[rng.randrange(n)]
                t_out += c[0]
                t_pri += c[1]
                t_cnt += c[2]
            dev = (t_out - t_pri) / t_cnt
            stats.append(dev)
            if (point >= 0 and dev <= 0) or (point < 0 and dev >= 0):
                crossed += 1
        stats.sort()
        lo = stats[int(0.025 * draws)]
        hi = stats[min(draws - 1, int(0.975 * draws))]
        mean = sum(stats) / len(stats)
        sd_boot = (sum((x - mean) ** 2 for x in stats) / len(stats)) ** 0.5

    p = min(1.0, max(1.0 / draws, 2.0 * crossed / draws))

    if sd_floor > 0.0 and sd_boot < sd_floor:
        # Degenerate resample distribution: use the model-based interval.
        lo = point - 1.959964 * sd_floor
        hi = point + 1.959964 * sd_floor
        z = abs(point) / sd_floor
        p = math.erfc(z / math.sqrt(2.0))          # two-sided normal tail
        p = min(1.0, max(1.0 / draws, p))
    return lo, hi, p


def cluster_bootstrap(observations, draws, rng):
    """
    Charter 3.6: resample CLUSTERS with replacement, take every leg of a drawn
    cluster. Resampling legs instead would treat the mutually-exclusive legs of
    one event as independent, shrinking the CI and inflating significance - in
    the direction that favours this study, which is why it is pre-empted.
    """
    by_cluster = defaultdict(list)
    for obs in observations:
        by_cluster[obs["cluster_id"]].append(obs)
    clusters = list(by_cluster.values())
    if not clusters:
        return None, None
    n = len(clusters)
    stats = []
    for _ in range(draws):
        legs = []
        for _ in range(n):
            legs.extend(clusters[rng.randrange(n)])
        if not legs:
            continue
        freq = sum(o["outcome"] for o in legs) / len(legs)
        implied = sum(o["price"] for o in legs) / len(legs)
        stats.append(freq - implied)
    if not stats:
        return None, None
    stats.sort()
    lo = stats[int(0.025 * len(stats))]
    hi = stats[min(len(stats) - 1, int(0.975 * len(stats)))]
    return lo, hi


def two_sided_p_from_bootstrap(observations, point, draws, rng):
    """
    Bootstrap p-value: proportion of resamples whose deviation sits on the
    opposite side of zero from the point estimate, doubled. Cheap, distribution
    free, and consistent with the CI actually reported.
    """
    by_cluster = defaultdict(list)
    for obs in observations:
        by_cluster[obs["cluster_id"]].append(obs)
    clusters = list(by_cluster.values())
    n = len(clusters)
    if n == 0:
        return 1.0
    crossed = 0
    for _ in range(draws):
        legs = []
        for _ in range(n):
            legs.extend(clusters[rng.randrange(n)])
        freq = sum(o["outcome"] for o in legs) / len(legs)
        implied = sum(o["price"] for o in legs) / len(legs)
        dev = freq - implied
        if (point >= 0 and dev <= 0) or (point < 0 and dev >= 0):
            crossed += 1
    p = 2.0 * crossed / draws
    return min(1.0, max(1.0 / draws, p))


def _norm_cdf(z):
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


def _norm_ppf(p):
    """Acklam inverse normal CDF; plenty accurate for a power threshold."""
    a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
         1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00]
    b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
         6.680131188771972e+01, -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
         -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00]
    d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
         3.754408661907416e+00]
    pl, ph = 0.02425, 1 - 0.02425
    if p < pl:
        q = math.sqrt(-2 * math.log(p))
        return (((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) /                ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)
    if p > ph:
        q = math.sqrt(-2 * math.log(1 - p))
        return -(((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) /                 ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)
    q = p - 0.5
    r = q * q
    return (((((a[0]*r+a[1])*r+a[2])*r+a[3])*r+a[4])*r+a[5])*q /            (((((b[0]*r+b[1])*r+b[2])*r+b[3])*r+b[4])*r+1)


def cell_power(se, n_tests, delta=POWER_REFERENCE_EFFECT, q=FDR_Q):
    """
    The cell's probability of detecting a deviation of size `delta`.

    Evaluated at the most conservative BH threshold (alpha = q / n_tests, the
    rank-1 cutoff), so the number is a lower bound on what the cell can see and
    cannot be gamed by a lucky ranking. Purely a function of the standard error
    and the number of tests - no data-dependent choices.
    """
    if not se or se <= 0 or n_tests <= 0:
        return 0.0
    z_crit = _norm_ppf(1.0 - (q / n_tests) / 2.0)
    shift = delta / se
    return (1.0 - _norm_cdf(z_crit - shift)) + _norm_cdf(-z_crit - shift)


def benjamini_hochberg(pvalues, q):
    """
    Charter 3.6: the denominator is the number of cells that ACTUALLY qualify,
    not a nominal 30. Returns the set of indices declared significant.
    """
    m = len(pvalues)
    if m == 0:
        return set(), None
    order = sorted(range(m), key=lambda i: pvalues[i])
    threshold_rank = 0
    for rank, idx in enumerate(order, start=1):
        if pvalues[idx] <= q * rank / m:
            threshold_rank = rank
    if threshold_rank == 0:
        return set(), None
    crit = q * threshold_rank / m
    return set(order[:threshold_rank]), crit


# --------------------------------------------------------------- cell build

def build_cells(observations, draws, rng):
    grouped = defaultdict(list)
    for obs in observations:
        # The fetcher emits a row for every attempted (market, window) pair,
        # including the absent ones, so the absence rate is auditable from the
        # same file. Those rows carry price=None and must not enter a cell -
        # charter 3.1: absent is counted, never interpolated.
        if obs.get("price") is None or obs.get("outcome") is None:
            continue
        cents = obs["price"] * 100.0
        buck = bucket_of(cents)
        if buck is None:
            continue
        grouped[(obs["window"], buck)].append(obs)

    cells = []
    for window in WINDOWS:
        for lo, hi in BUCKETS:
            buck = "%d-%d" % (lo, hi)
            obs = grouped.get((window, buck), [])
            legs = len(obs)
            clusters = len({o["cluster_id"] for o in obs})
            cell = {
                "window": window, "bucket": buck,
                "legs": legs, "clusters": clusters,
                "implied": None, "actual": None, "deviation": None,
                "ci_low": None, "ci_high": None, "p_value": None,
                "qualifies": legs >= MIN_LEGS,
                "cluster_insufficient": clusters < MIN_CLUSTERS,
            }
            if legs:
                cell["implied"] = sum(o["price"] for o in obs) / legs
                cell["actual"] = sum(o["outcome"] for o in obs) / legs
                cell["deviation"] = cell["actual"] - cell["implied"]
                # Standard error for EVERY populated cell, including those that
                # fail the leg gate - the three-state rule needs to know what a
                # cell could have seen even when it is not formally judged.
                cell["se"] = cluster_robust_se(_cluster_sums(obs),
                                               cell["deviation"])
            if cell["qualifies"] and legs:
                lo_ci, hi_ci, pval = bootstrap_cell(obs, draws, rng)
                cell["ci_low"], cell["ci_high"] = lo_ci, hi_ci
                cell["p_value"] = pval
                # Charter 3.5: both tradable directions, net of the frozen cost.
                dev = cell["deviation"]
                cell["net_edge"] = abs(dev) - COST_ROUNDTRIP
                cell["direction"] = ("buy_yes" if dev > 0 else "buy_no")
            cells.append(cell)
    return cells


def absence_rates(observations, cohort_sizes):
    """Charter 3.3 / 3.0: absence measured inside the cohort."""
    seen = defaultdict(set)
    for obs in observations:
        if obs.get("price") is None:
            continue          # attempted but absent - not a present observation
        seen[obs["window"]].add(obs["market_id"])
    out = {}
    for window in WINDOWS:
        cohort = (cohort_sizes or {}).get(str(window))
        present = len(seen[window])
        if not cohort:
            out[window] = {"present": present, "cohort": None,
                           "absence_rate": None, "status": "cohort size not supplied"}
            continue
        rate = 1.0 - present / cohort
        status = ("REJECT (>60%)" if rate > ABSENCE_REJECT else
                  "DOWNGRADE (>30%)" if rate > ABSENCE_DOWNGRADE else "pass")
        out[window] = {"present": present, "cohort": cohort,
                       "absence_rate": round(rate, 4), "status": status}
    return out


def stratify(observations, key, draws, rng):
    """Charter 3.7: separate tables, never affecting the main verdict."""
    tables = {}
    usable = [o for o in observations if o.get("price") is not None]
    values = sorted({str(o.get(key)) for o in usable if o.get(key) is not None})
    for value in values:
        subset = [o for o in usable if str(o.get(key)) == value]
        rows = []
        for window in WINDOWS:
            for lo, hi in BUCKETS:
                buck = "%d-%d" % (lo, hi)
                obs = [o for o in subset
                       if o["window"] == window and bucket_of(o["price"] * 100.0) == buck]
                if not obs:
                    continue
                implied = sum(o["price"] for o in obs) / len(obs)
                actual = sum(o["outcome"] for o in obs) / len(obs)
                rows.append({"window": window, "bucket": buck,
                             "legs": len(obs),
                             "clusters": len({o["cluster_id"] for o in obs}),
                             "implied": round(implied, 4),
                             "actual": round(actual, 4),
                             "deviation": round(actual - implied, 4)})
        tables[value] = rows
    return tables


def year_sign_agreement(strata_year, window, bucket, deviation_sign):
    """Charter 5 criterion 4: same sign in at least two year layers."""
    agree = 0
    for _, rows in strata_year.items():
        for row in rows:
            if row["window"] == window and row["bucket"] == bucket:
                if row["deviation"] != 0 and (row["deviation"] > 0) == deviation_sign:
                    agree += 1
    return agree


# --------------------------------------------------------------- verdict

def verdict(cells, strata_year):
    qualifying = [c for c in cells if c["qualifies"] and c["p_value"] is not None]
    pvals = [c["p_value"] for c in qualifying]
    sig_idx, crit = benjamini_hochberg(pvals, FDR_Q)

    # Three-state pre-pass (rev3): measure what each cell could have detected
    # before asking what it did detect.
    n_tests = max(1, len(qualifying))
    for cell in cells:
        cell["power_vs_reference"] = cell_power(cell.get("se"), n_tests)
        cell["underpowered"] = cell["power_vs_reference"] < POWER_FLOOR

    survivors = []
    for i, cell in enumerate(qualifying):
        cell["fdr_significant"] = i in sig_idx
        ci_excludes_zero = (cell["ci_low"] is not None
                            and (cell["ci_low"] > 0 or cell["ci_high"] < 0))
        cell["ci_excludes_zero"] = ci_excludes_zero
        cell["net_positive"] = cell.get("net_edge", -1) > 0
        cell["year_layers_agreeing"] = year_sign_agreement(
            strata_year, cell["window"], cell["bucket"], cell["deviation"] > 0)
        cell["year_agreement_ok"] = cell["year_layers_agreeing"] >= 2
        cell["survives"] = bool(cell["fdr_significant"] and ci_excludes_zero
                                and cell["net_positive"]
                                and cell["year_agreement_ok"])
        if cell["survives"]:
            survivors.append(cell)

    # Cell-level three-state verdict.
    for cell in cells:
        if cell.get("survives"):
            cell["state"] = "SURVIVES"
        elif cell["legs"] == 0:
            cell["state"] = "NO DATA"
        elif cell.get("underpowered", True):
            cell["state"] = "UNDERPOWERED"      # not evidence of absence
        else:
            cell["state"] = "DEATH"             # had the power, saw nothing

    powered = [c for c in cells if c.get("state") == "DEATH"]
    underpowered = [c for c in cells if c.get("state") == "UNDERPOWERED"]
    if survivors:
        case_verdict = "SURVIVES -> proceed to stage 2 / 0b"
    elif not powered:
        case_verdict = ("NO POWER -> this universe cannot try these cells. "
                        "NOT a death verdict; re-triable only once the "
                        "historical record grows (mechanical condition)")
    else:
        case_verdict = ("EVIDENCE DEATH on %d powered cell(s); %d cell(s) "
                        "UNDERPOWERED and left unjudged"
                        % (len(powered), len(underpowered)))

    return {
        "fdr_denominator": len(qualifying),
        "fdr_critical_value": crit,
        "cells_survived": len(survivors),
        "cells_evidence_death": len(powered),
        "cells_underpowered": len(underpowered),
        "cells_no_data": sum(1 for c in cells if c.get("state") == "NO DATA"),
        "power_reference_effect": POWER_REFERENCE_EFFECT,
        "power_floor": POWER_FLOOR,
        "median_power_of_judged_cells": (
            sorted(c["power_vs_reference"] for c in cells if c["legs"] > 0)
            [max(0, sum(1 for c in cells if c["legs"] > 0) // 2)]
            if any(c["legs"] > 0 for c in cells) else 0.0),
        "excluded_cells": [{"window": c["window"], "bucket": c["bucket"],
                            "legs": c["legs"], "reason": "legs < %d" % MIN_LEGS}
                           for c in cells if not c["qualifies"]],
        "survivors": [{"window": c["window"], "bucket": c["bucket"],
                       "deviation": round(c["deviation"], 4),
                       "ci": [round(c["ci_low"], 4), round(c["ci_high"], 4)],
                       "direction": c["direction"],
                       "net_edge": round(c["net_edge"], 4),
                       "year_layers": c["year_layers_agreeing"]}
                      for c in survivors],
        "verdict": case_verdict,
        "death_wording_if_evidence_death": (
            "prediction market prices are well calibrated to the point of "
            "retail non-extractability (within the >=$10K tradable world)"),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("observations", help="NDJSON of market-window observations")
    ap.add_argument("--out", default="pm2_result.json")
    ap.add_argument("--report", default="pm2_report.md")
    ap.add_argument("--draws", type=int, default=BOOTSTRAP_DRAWS)
    ap.add_argument("--seed", type=int, default=20260827)
    ap.add_argument("--cohort-sizes", help='JSON like {"1":313023,"7":75330,"30":20248}')
    args = ap.parse_args()

    observations = []
    with open(args.observations, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                observations.append(json.loads(line))

    cohort_sizes = json.loads(args.cohort_sizes) if args.cohort_sizes else None
    rng = random.Random(args.seed)

    cells = build_cells(observations, args.draws, rng)
    strata = {
        "category": stratify(observations, "category", args.draws, rng),
        "year": stratify(observations, "year", args.draws, rng),
    }
    liq = [o["liquidity"] for o in observations
           if o.get("liquidity") is not None and o.get("price") is not None]
    if liq:
        median = sorted(liq)[len(liq) // 2]
        for obs in observations:
            if obs.get("liquidity") is not None:
                obs["liquidity_band"] = ("above" if obs["liquidity"] >= median
                                         else "below")
        strata["liquidity"] = stratify(observations, "liquidity_band",
                                       args.draws, rng)

    result = {
        "observations": len(observations),
        "observations_absent": sum(1 for o in observations
                                   if o.get("price") is None),
        "distinct_markets": len({o["market_id"] for o in observations
                                 if o.get("price") is not None}),
        "distinct_clusters": len({o["cluster_id"] for o in observations
                                  if o.get("price") is not None}),
        "bootstrap_draws": args.draws,
        "seed": args.seed,
        "absence": absence_rates(observations, cohort_sizes),
        "cells": cells,
        "strata": strata,
    }
    result.update(verdict(cells, strata["year"]))

    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(result, fh, indent=2, ensure_ascii=False)
    write_report(result, args.report)

    print("observations %d | markets %d | clusters %d"
          % (result["observations"], result["distinct_markets"],
             result["distinct_clusters"]))
    print("FDR denominator (qualifying cells): %d" % result["fdr_denominator"])
    print("survivors: %d" % len(result["survivors"]))
    print("VERDICT: %s" % result["verdict"])
    return 0


def write_report(result, path):
    lines = ["# PM-2 0a report", "",
             "Observations %d | markets %d | clusters %d | bootstrap %d draws"
             % (result["observations"], result["distinct_markets"],
                result["distinct_clusters"], result["bootstrap_draws"]),
             "", "## Absence by window (cohort-internal, charter 3.3)", "",
             "| window | present | cohort | absence | status |", "|---|---|---|---|---|"]
    for window, rec in sorted(result["absence"].items()):
        lines.append("| T=%s | %s | %s | %s | %s |"
                     % (window, rec["present"], rec["cohort"],
                        rec["absence_rate"], rec["status"]))

    lines += ["", "## 30-cell matrix", "",
              "| T | bucket | legs | clusters | implied | actual | dev | CI | p | FDR | survives |",
              "|---|---|---|---|---|---|---|---|---|---|---|"]
    for cell in result["cells"]:
        ci = ("[%.4f, %.4f]" % (cell["ci_low"], cell["ci_high"])
              if cell["ci_low"] is not None else "-")
        lines.append("| %d | %s | %d | %d | %s | %s | %s | %s | %s | %s | %s |"
                     % (cell["window"], cell["bucket"], cell["legs"],
                        cell["clusters"],
                        "%.4f" % cell["implied"] if cell["implied"] is not None else "-",
                        "%.4f" % cell["actual"] if cell["actual"] is not None else "-",
                        "%+.4f" % cell["deviation"] if cell["deviation"] is not None else "-",
                        ci,
                        "%.4f" % cell["p_value"] if cell["p_value"] is not None else "-",
                        cell.get("fdr_significant", "-"),
                        cell.get("survives", "-")))

    lines += ["", "## Verdict", "",
              "FDR denominator: **%d** qualifying cells (charter 3.6 - not a nominal 30)"
              % result["fdr_denominator"],
              "", "Cells excluded for legs < %d: %d"
              % (MIN_LEGS, len(result["excluded_cells"])),
              "", "**%s**" % result["verdict"], ""]
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))


if __name__ == "__main__":
    sys.exit(main())
