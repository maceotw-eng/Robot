#!/usr/bin/env python3
"""
PM-2 0a sampler - draws the frozen 100,000-market sample.

Charter v1.1 rev3 3.8 (frozen):
  - 100,000 markets, uniform over the whole eligible population, no replacement
  - seed 20260827, frozen; changing it invalidates the pre-registration
  - stratification is NOT applied here; the stratified cuts happen at analysis time

Eligibility is re-tested here from the raw stream rather than trusted from an
upstream count, because every eligibility number in this project that was
inherited rather than measured has been wrong at least once:
  - the binary test (label-based) produced a 22,639 artifact
  - the void test read a field absent from the stream and reported 0

So this script MEASURES, on every row:
  binary        len(clobTokenIds) == 2          (charter 2.0.1, the new criterion)
  settled       outcomePrices exactly one 1, rest 0  (charter 2.1.1, strict)
  mappable      clobTokenIds present and usable
  disputed      umaResolutionStatuses history  (PLURAL - the singular form is
                                                not in the stream at all)
and reports a full reconciliation that must land on the frozen 313,023.

    python3 sample_markets.py probe_state/harvest_stream.ndjson
    python3 sample_markets.py <stream> --out sample_100k.ndjson --audit audit.json
"""

import argparse
import json
import os
import random
import sys
from collections import Counter

SEED = 20260827          # charter 3.8 - FROZEN
SAMPLE_SIZE = 100000     # charter 3.8 rev3 - FROZEN
# Raised from 8,000 by ruling 1 of 2026-08-28. The 8,000 two-stage design was
# retired after the power simulation measured its detection power against a +2%
# effect at 1.4%: it would have returned a death verdict whether or not the
# market held a signal. 100,000 uniform buys ~85% power for ~14.8 hours of
# unattended fetching. See docs/PM2_rev3_amendments_Code.md.

# Charter 2.0.1 freezes the STRICT-PAYOUT count as a checkable constant.
EXPECTED_STRICT_PAYOUT = 313023

# The FINAL eligible count is deliberately NOT a constant. Ruling O-1(a),
# 2026-08-28: final eligible = strict 1/0 payout INTERSECT non-terminally-
# disputed. The overlap between the 226 terminally-disputed markets and the
# 313,023 strict-payout markets was never measured, so the charter freezes the
# PREDICATE and this script produces the NUMBER. Writing an estimate into the
# charter would be the same mistake as the 22,639 artifact: a figure that was
# inferred rather than counted.


def jload(value):
    """Gamma returns several array fields as JSON-encoded strings."""
    if isinstance(value, list):
        return value
    if isinstance(value, str) and value.strip():
        try:
            parsed = json.loads(value)
            return parsed if isinstance(parsed, list) else None
        except json.JSONDecodeError:
            return None
    return None


def token_ids(market):
    return jload(market.get("clobTokenIds"))


def is_binary(market):
    """Charter 2.0.1: binary IFF exactly two clob token ids."""
    toks = token_ids(market)
    return bool(toks) and len(toks) == 2


def mappable(market):
    toks = token_ids(market)
    if not toks:
        return False, "missing"
    flat = [str(t) for t in toks if t not in (None, "")]
    if len(flat) != len(toks):
        return False, "blank_token"
    if not all(t.isdigit() for t in flat):
        return False, "non_numeric"
    if len(flat[0]) < 30:
        return False, "legacy_short_id"
    return True, "ok"


def settlement(market):
    """Charter 2.1.1: strict payout. Exactly one 1.0, the rest 0.0."""
    raw = jload(market.get("outcomePrices"))
    if raw is None:
        return None, "missing"
    vals = []
    for v in raw:
        try:
            vals.append(float(v))
        except (TypeError, ValueError):
            return None, "non_numeric"
    if not vals:
        return None, "empty"
    if all(v == 0.0 for v in vals):
        return None, "all_zero"
    if all(v == 1.0 for v in vals):
        return None, "all_one"
    if vals == [0.5] * len(vals):
        return None, "refund_half"          # the void / refund signature
    winners = [i for i, v in enumerate(vals) if v == 1.0]
    zeros = [v for v in vals if v == 0.0]
    if len(winners) == 1 and len(zeros) == len(vals) - 1:
        return winners[0], "settled_payout"
    return None, "float_tail_or_unsettled"


def dispute_state(market):
    """
    PLURAL field only. umaResolutionStatus (singular) is NOT in the stream -
    reading it is what produced the false voided_count: 0.
    """
    hist = jload(market.get("umaResolutionStatuses"))
    if not hist:
        return "no_history"
    lowered = [str(h).lower() for h in hist]
    if "disputed" not in lowered:
        return "clean"
    return "terminal_disputed" if lowered[-1] == "disputed" else "disputed_then_resolved"


def year_of(market):
    end = market.get("endDate")
    return str(end)[:4] if end else "unknown"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("stream", help="harvest_stream.ndjson")
    ap.add_argument("--out", default="sample_100k.ndjson")
    ap.add_argument("--audit", default="sample_audit.json")
    ap.add_argument("--size", type=int, default=SAMPLE_SIZE)
    ap.add_argument("--seed", type=int, default=SEED)
    ap.add_argument("--include-terminal-disputed", action="store_true",
                    help="DIAGNOSTIC ONLY. Ruling O-1 excludes terminally "
                         "disputed markets; this flag disables that and the run "
                         "is then NOT the pre-registered sample.")
    args = ap.parse_args()
    exclude_terminal = not args.include_terminal_disputed

    if args.seed != SEED or args.size != SAMPLE_SIZE:
        print("!! WARNING: seed/size differ from the frozen charter values "
              "(%d / %d). This run is NOT the pre-registered sample."
              % (SEED, SAMPLE_SIZE), file=sys.stderr)

    eligible = []
    rows = 0
    binary_c, map_c, settle_c, disp_c = Counter(), Counter(), Counter(), Counter()
    by_year = Counter()
    # Charter 6 exclusion breakdown - six named classes, reported separately
    # (ruling O-3). "unsettled" was previously a bucket that quietly contained
    # already-settled refunds; it no longer is.
    excl = Counter()
    strict_payout_count = 0
    terminal_disputed_total = 0
    terminal_disputed_overlap = 0   # the number ruling O-1(a) says to measure

    with open(args.stream, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                market = json.loads(line)
            except json.JSONDecodeError:
                binary_c["unparseable_line"] += 1
                continue
            rows += 1

            binary = is_binary(market)
            binary_c["binary" if binary else "not_binary"] += 1

            ok_map, why_map = mappable(market)
            map_c[why_map] += 1

            winner, why_settle = settlement(market)
            settle_c[why_settle] += 1

            state = dispute_state(market)
            disp_c[state] += 1

            if state == "terminal_disputed":
                terminal_disputed_total += 1

            strict = binary and ok_map and why_settle == "settled_payout"
            if strict:
                strict_payout_count += 1
                if state == "terminal_disputed":
                    # This intersection is exactly what O-1(a) left unmeasured.
                    terminal_disputed_overlap += 1

            # Exclusion accounting, charter 6 (six classes)
            if not binary:
                excl["not_binary"] += 1
            elif not ok_map:
                excl["mapping_failed_" + why_map] += 1
            elif why_settle == "refund_half":
                excl["refund_settled_half"] += 1        # SETTLED refund, not unsettled
            elif why_settle == "all_one":
                excl["both_win_anomaly"] += 1
            elif why_settle == "all_zero":
                excl["zero_payout"] += 1
            elif why_settle == "float_tail_or_unsettled":
                excl["float_tail_or_unsettled"] += 1
            elif strict and exclude_terminal and state == "terminal_disputed":
                excl["terminal_disputed"] += 1

            keep = strict
            if keep and exclude_terminal and state == "terminal_disputed":
                keep = False
            if keep:
                market["_pm2_winner_index"] = winner
                market["_pm2_dispute_state"] = state
                eligible.append(market)
                by_year[year_of(market)] += 1

    audit = {
        "stream": os.path.abspath(args.stream),
        "rows_read": rows,
        "binary_census": dict(binary_c),
        "mapping_census": dict(map_c),
        "settlement_census": dict(settle_c),
        "dispute_census": dict(disp_c),
        "exclusion_breakdown": dict(excl),
        "strict_payout_eligible": strict_payout_count,
        "charter_expected_strict_payout": EXPECTED_STRICT_PAYOUT,
        "matches_charter": strict_payout_count == EXPECTED_STRICT_PAYOUT,
        "terminal_disputed_total": terminal_disputed_total,
        "terminal_disputed_overlap_with_strict": terminal_disputed_overlap,
        "final_eligible": len(eligible),
        "eligible_by_year": dict(sorted(by_year.items())),
        "seed": args.seed,
        "sample_size": args.size,
        "exclude_terminal_disputed": exclude_terminal,
    }

    print("=" * 68)
    print("PM-2 0a first-stage sampler")
    print("=" * 68)
    print("rows read            : %d" % rows)
    print("binary (len(tok)==2) : %s" % dict(binary_c))
    print("mapping              : %s" % dict(map_c))
    print("settlement           : %s" % dict(settle_c))
    print("dispute (PLURAL fld) : %s" % dict(disp_c))
    print("\nexclusion breakdown (charter 6, six classes):")
    for reason, count in sorted(excl.items(), key=lambda kv: -kv[1]):
        print("   %-34s %8d" % (reason, count))

    print("\nstrict-payout eligible : %d  (charter 2.0.1 says %d) %s"
          % (strict_payout_count, EXPECTED_STRICT_PAYOUT,
             "MATCH" if audit["matches_charter"] else "*** MISMATCH ***"))
    print("terminal-disputed      : %d total, %d of them inside strict-payout"
          % (terminal_disputed_total, terminal_disputed_overlap))
    print("FINAL eligible         : %d   <- ruling O-1(a): measured here, "
          "never estimated" % len(eligible))
    print("by year                : %s" % audit["eligible_by_year"])

    if not audit["matches_charter"]:
        print("\n!! Strict-payout count does not match the frozen charter figure.")
        print("   Do NOT proceed to analysis. Reconcile first - a silent")
        print("   population change is exactly the failure mode this project")
        print("   has hit three times.")

    if len(eligible) < args.size:
        print("\n!! Population smaller than the requested sample; aborting.")
        audit["error"] = "population < sample size"
        with open(args.audit, "w", encoding="utf-8") as fh:
            json.dump(audit, fh, indent=2, ensure_ascii=False)
        return 1

    rng = random.Random(args.seed)
    sample = rng.sample(eligible, args.size)
    sample.sort(key=lambda m: str(m.get("id")))

    with open(args.out, "w", encoding="utf-8") as fh:
        for market in sample:
            fh.write(json.dumps(market, ensure_ascii=False) + "\n")

    sample_years = Counter(year_of(m) for m in sample)
    audit["sample_by_year"] = dict(sorted(sample_years.items()))
    audit["sample_ids_sha256"] = __import__("hashlib").sha256(
        "\n".join(str(m.get("id")) for m in sample).encode()).hexdigest()

    with open(args.audit, "w", encoding="utf-8") as fh:
        json.dump(audit, fh, indent=2, ensure_ascii=False)

    print("\nsample drawn         : %d (seed %d)" % (len(sample), args.seed))
    print("sample by year       : %s" % audit["sample_by_year"])
    print("sample id-set sha256 : %s" % audit["sample_ids_sha256"])
    print("wrote %s  and  %s" % (args.out, args.audit))
    print("\nThe id-set sha256 pins this draw. Re-running with the frozen seed")
    print("must reproduce it exactly; if it does not, the population changed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
