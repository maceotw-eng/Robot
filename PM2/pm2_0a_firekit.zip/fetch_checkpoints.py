#!/usr/bin/env python3
"""
PM-2 0a checkpoint fetcher - turns the sampled markets into observations.

This is the ~15-hour unattended job. It reads the frozen sample, fetches each
market's price history around the T = 1 / 7 / 30 checkpoints, extracts the
checkpoint price exactly as charter 3.1 defines it, and appends one observation
per (market, window) to an NDJSON file the analysis pipeline consumes.

Charter compliance
  3.0    cohort membership: a market enters window T only if it lived >= T+1
         days (startDate <= endDate - T days). Markets outside the cohort are
         not fetched and are NOT counted as absent.
  3.1    T=1  : the LAST available point inside the 24h before endDate, and the
                actual gap from the checkpoint is recorded per market.
         T=7  : a point inside [endDate - 7d, endDate - 6d)
         T=30 : a point inside [endDate - 30d, endDate - 29d)
         Absent = counted, never interpolated.
  3.1.1  query plan: T=1 fidelity 1 / 2-day window; T=7 fidelity 60 / 14-day;
         T=30 fidelity 1440 / 35-day. Windowed request first, interval=max as
         fallback, then slice locally (the time-range wall countermeasure).
  2.1    prices come from CLOB keyed on clobTokenIds[0] (the YES leg).

Built to survive a 15-hour unattended run:
  - append-only output; restart skips whatever is already on disk
  - a previous probe generation died silently to an SSH hangup, so run under
    setsid and check the heartbeat file rather than the terminal
  - token-bucket rate limiting, 429/5xx backoff, per-market error capture

    setsid nohup python3 fetch_checkpoints.py sample_100k.ndjson \\
           --out observations.ndjson > fetch.log 2>&1 &
"""

import argparse
import json
import os
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from datetime import datetime, timezone

CLOB = "https://clob.polymarket.com"
DAY_MS = 86400000
UA = {"User-Agent": "pm2-fetch/1.0", "Accept": "application/json"}

# Charter 3.1.1 - frozen query plan
PLAN = {
    1:  {"fidelity": 1,    "window_days": 2},
    7:  {"fidelity": 60,   "window_days": 14},
    30: {"fidelity": 1440, "window_days": 35},
}


class Limiter:
    def __init__(self, per_sec):
        self.interval = 1.0 / per_sec if per_sec > 0 else 0.0
        self.next_at = 0.0

    def wait(self):
        now = time.monotonic()
        if now < self.next_at:
            time.sleep(self.next_at - now)
        self.next_at = max(now, self.next_at) + self.interval


def parse_dt(value):
    if not value:
        return None
    txt = str(value).replace("Z", "+00:00")
    try:
        return int(datetime.fromisoformat(txt).timestamp() * 1000)
    except ValueError:
        return None


def jload(value):
    if isinstance(value, list):
        return value
    if isinstance(value, str) and value.strip():
        try:
            out = json.loads(value)
            return out if isinstance(out, list) else None
        except json.JSONDecodeError:
            return None
    return None


def get(url, params, limiter, retries=5, timeout=40):
    full = url + "?" + urllib.parse.urlencode(params)
    last = None
    for attempt in range(retries):
        limiter.wait()
        try:
            req = urllib.request.Request(full, headers=UA)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8")), None
        except urllib.error.HTTPError as exc:
            if exc.code in (429, 500, 502, 503, 504):
                time.sleep(min(60, 2 ** attempt))
                last = "HTTP %d" % exc.code
                continue
            return None, "HTTP %d" % exc.code
        except (urllib.error.URLError, ssl.SSLError, OSError, TimeoutError) as exc:
            time.sleep(min(30, 1.5 * (attempt + 1)))
            last = type(exc).__name__
    return None, last or "exhausted"


def history(token, start_ms, end_ms, fidelity, limiter):
    """Windowed request first; interval=max fallback; slice locally either way."""
    data, err = get(CLOB + "/prices-history",
                    {"market": token, "startTs": int(start_ms / 1000),
                     "endTs": int(end_ms / 1000), "fidelity": fidelity}, limiter)
    pts = (data or {}).get("history") or []
    source = "windowed"
    if not pts:
        data, err2 = get(CLOB + "/prices-history",
                         {"market": token, "interval": "max",
                          "fidelity": fidelity}, limiter)
        pts = (data or {}).get("history") or []
        source = "interval_max"
        err = err or err2
    out = []
    for p in pts:
        ts = p.get("t")
        if ts is None:
            continue
        ts = ts * 1000 if ts < 1e11 else ts
        if start_ms <= ts <= end_ms:
            try:
                out.append((int(ts), float(p.get("p"))))
            except (TypeError, ValueError):
                continue
    out.sort()
    return out, source, err


def checkpoint(points, end_ms, window):
    """
    Charter 3.1 extraction. Returns (price, gap_hours, status).

    T=1  : last point inside the final 24h.
    T=7/30: a point inside the one-day slot starting T days before settlement -
            the same definition the cohort absence rates were measured under, so
            the numbers in charter 3.3 stay comparable.
    """
    if not points:
        return None, None, "no_history"
    if window == 1:
        lo, hi = end_ms - DAY_MS, end_ms
        inside = [(t, p) for t, p in points if lo <= t <= hi]
        if not inside:
            return None, None, "no_point_in_window"
        t, p = inside[-1]
        return p, (end_ms - t) / 3600000.0, "ok"
    target = end_ms - window * DAY_MS
    inside = [(t, p) for t, p in points if target <= t < target + DAY_MS]
    if not inside:
        return None, None, "no_point_in_window"
    t, p = inside[-1]
    return p, (t - target) / 3600000.0, "ok"


def load_done(path):
    """Restart support: whatever already landed on disk is not re-fetched."""
    done = set()
    if not os.path.exists(path):
        return done
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
                done.add((str(rec.get("market_id")), int(rec.get("window"))))
            except (json.JSONDecodeError, TypeError, ValueError):
                continue
    return done


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("sample", help="sample NDJSON from sample_markets.py")
    ap.add_argument("--out", default="observations.ndjson")
    ap.add_argument("--rate", type=float, default=3.0, help="requests/sec")
    ap.add_argument("--heartbeat", default="fetch_heartbeat.json")
    ap.add_argument("--windows", default="1,7,30")
    ap.add_argument("--limit", type=int, default=0, help="stop after N markets")
    args = ap.parse_args()

    windows = [int(w) for w in args.windows.split(",")]
    limiter = Limiter(args.rate)
    done = load_done(args.out)
    if done:
        print("resuming: %d (market, window) pairs already on disk" % len(done))

    markets = []
    with open(args.sample, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                markets.append(json.loads(line))
    if args.limit:
        markets = markets[:args.limit]
    print("sample: %d markets" % len(markets))

    stats = Counter()
    t0 = time.time()
    out = open(args.out, "a", encoding="utf-8")
    try:
        for i, m in enumerate(markets, 1):
            mid = str(m.get("id"))
            end_ms = parse_dt(m.get("endDate"))
            start_ms = parse_dt(m.get("startDate")) or parse_dt(m.get("createdAt"))
            toks = jload(m.get("clobTokenIds")) or []
            if not end_ms or not toks:
                stats["skip_no_end_or_token"] += 1
                continue
            token = str(toks[0])
            winner = m.get("_pm2_winner_index")
            outcome = 1 if winner == 0 else 0

            for w in windows:
                if (mid, w) in done:
                    stats["already_done"] += 1
                    continue
                # Charter 3.0 cohort: lifetime must cover the checkpoint.
                if start_ms is not None and start_ms > end_ms - w * DAY_MS:
                    stats["out_of_cohort_w%d" % w] += 1
                    continue

                plan = PLAN[w]
                lo = end_ms - plan["window_days"] * DAY_MS
                pts, source, err = history(token, lo, end_ms,
                                           plan["fidelity"], limiter)
                price, gap, status = checkpoint(pts, end_ms, w)
                stats["w%d_%s" % (w, status)] += 1
                rec = {
                    "market_id": mid,
                    "cluster_id": m.get("conditionId") or mid,
                    "window": w,
                    "price": price,
                    "outcome": outcome,
                    "checkpoint_gap_hours": None if gap is None else round(gap, 3),
                    "status": status,
                    "source": source,
                    "points_in_window": len(pts),
                    "endDate": m.get("endDate"),
                    "year": str(m.get("endDate"))[:4],
                    "category": m.get("category") or m.get("_pm2_category"),
                    "liquidity": m.get("liquidityNum") or m.get("liquidity"),
                    "volume": m.get("volumeNum") or m.get("volume"),
                    "fetch_error": err,
                }
                out.write(json.dumps(rec, ensure_ascii=False) + "\n")
                out.flush()

            if i % 250 == 0:
                el = time.time() - t0
                rate = i / el if el else 0
                eta = (len(markets) - i) / rate if rate else 0
                hb = {"markets_done": i, "of": len(markets),
                      "elapsed_sec": round(el), "eta_sec": round(eta),
                      "eta_hours": round(eta / 3600.0, 2),
                      "stats": dict(stats),
                      "updated": datetime.now(timezone.utc).isoformat()}
                with open(args.heartbeat, "w", encoding="utf-8") as hf:
                    json.dump(hb, hf, indent=1)
                print("  %d/%d  %.1f mkt/s  eta %.1f h  %s"
                      % (i, len(markets), rate, eta / 3600.0,
                         dict(list(stats.items())[:5])), flush=True)
    finally:
        out.close()

    print("\ndone in %.1f h" % ((time.time() - t0) / 3600.0))
    print(json.dumps(dict(stats), indent=1))
    print("\nAbsence is computed by the pipeline against the cohort denominator;")
    print("'no_point_in_window' and 'no_history' are the absent cases, counted")
    print("and never interpolated (charter 3.1).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
