#!/usr/bin/env python3
"""
Charter 3.3.1: the T=30 absence rate, computed EXACTLY over the whole cohort.

Why this is a separate job rather than a sample statistic
--------------------------------------------------------
The pilot measured 28 absent out of 100, whose 95% CI is [20.1%, 37.5%] - the
30% downgrade threshold sits inside it. Worse, the point estimate is only two
points from the threshold, so no feasible sample can settle it: even n=1,600
leaves the interval touching 30%. The charter therefore freezes the rule that
this window's absence rate is computed over the ENTIRE cohort (~20,248 markets),
and that a value above 30% triggers the downgrade automatically, with no
discretion.

This also emits the cohort denominators for all three windows, which the
analysis pipeline needs so absence is measured against the cohort rather than
against whatever happened to be fetched.

    setsid nohup python3 measure_t30_cohort.py harvest_stream.ndjson \\
           --out t30_absence.json --rate 2.0 > t30.log 2>&1 &
"""

import argparse
import json
import os
import sys
import time
from collections import Counter
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fetch_checkpoints as F  # noqa: E402
import sample_markets as S  # noqa: E402

DAY_MS = F.DAY_MS


def eligible(market):
    """Charter 2.0.2 predicate, same as the sampler - measured, not assumed."""
    if not S.is_binary(market):
        return False
    ok, _ = S.mappable(market)
    if not ok:
        return False
    _, why = S.settlement(market)
    if why != "settled_payout":
        return False
    return S.dispute_state(market) != "terminal_disputed"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("stream")
    ap.add_argument("--out", default="t30_absence.json")
    ap.add_argument("--rate", type=float, default=2.0)
    ap.add_argument("--window", type=int, default=30)
    ap.add_argument("--progress", default="t30_progress.ndjson")
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    limiter = F.Limiter(args.rate)
    cohort_sizes = Counter()
    cohort = []
    total_eligible = 0

    with open(args.stream, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                m = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not eligible(m):
                continue
            total_eligible += 1
            end = F.parse_dt(m.get("endDate"))
            start = F.parse_dt(m.get("startDate")) or F.parse_dt(m.get("createdAt"))
            if not end:
                continue
            for w in (1, 7, 30):
                if start is None or start <= end - w * DAY_MS:
                    cohort_sizes[w] += 1
            if start is not None and start <= end - args.window * DAY_MS:
                cohort.append(m)

    print("eligible markets      : %d" % total_eligible)
    print("cohort sizes          : %s" % dict(sorted(cohort_sizes.items())))
    print("T=%d cohort to measure : %d" % (args.window, len(cohort)))
    if args.limit:
        cohort = cohort[:args.limit]

    # Resume support: this is a multi-hour job on a box that has dropped SSH before.
    done = {}
    if os.path.exists(args.progress):
        with open(args.progress, "r", encoding="utf-8") as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                    done[str(r["market_id"])] = r["status"]
                except (json.JSONDecodeError, KeyError):
                    continue
        print("resuming: %d already measured" % len(done))

    stats = Counter(done.values())
    gaps = []
    t0 = time.time()
    prog = open(args.progress, "a", encoding="utf-8")
    try:
        for i, m in enumerate(cohort, 1):
            mid = str(m.get("id"))
            if mid in done:
                continue
            end = F.parse_dt(m.get("endDate"))
            toks = S.token_ids(m) or []
            if not toks:
                stats["no_token"] += 1
                continue
            plan = F.PLAN[args.window]
            lo = end - plan["window_days"] * DAY_MS
            pts, source, err = F.history(str(toks[0]), lo, end,
                                         plan["fidelity"], limiter)
            price, gap, status = F.checkpoint(pts, end, args.window)
            stats[status] += 1
            if gap is not None:
                gaps.append(abs(gap))
            prog.write(json.dumps({"market_id": mid, "status": status,
                                   "price": price, "gap_hours": gap,
                                   "source": source, "error": err}) + "\n")
            prog.flush()

            if i % 200 == 0:
                el = time.time() - t0
                seen = sum(stats.values())
                absent = stats["no_history"] + stats["no_point_in_window"]
                print("  %d/%d  absent so far %.1f%%  eta %.1f h"
                      % (i, len(cohort), 100.0 * absent / max(1, seen),
                         (len(cohort) - i) / (i / el) / 3600.0 if el else 0),
                      flush=True)
    finally:
        prog.close()

    measured = stats["ok"] + stats["no_history"] + stats["no_point_in_window"]
    absent = stats["no_history"] + stats["no_point_in_window"]
    rate = absent / measured if measured else None
    gaps.sort()

    result = {
        "measured_at": datetime.now(timezone.utc).isoformat(),
        "window": args.window,
        "eligible_markets": total_eligible,
        "cohort_sizes": {str(k): v for k, v in sorted(cohort_sizes.items())},
        "cohort_measured": measured,
        "present": stats["ok"],
        "absent": absent,
        "absence_rate_exact": None if rate is None else round(rate, 5),
        "status_breakdown": dict(stats),
        "median_gap_hours": gaps[len(gaps) // 2] if gaps else None,
        "exceeds_30pct": None if rate is None else rate > 0.30,
        "charter_rule": ("3.3.1 - exact over the full cohort, no sampling; "
                         ">30% triggers the downgrade automatically, no discretion"),
    }
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(result, fh, indent=2, ensure_ascii=False)

    print("\n" + "=" * 66)
    print("T=%d EXACT absence over the full cohort" % args.window)
    print("  cohort measured : %d" % measured)
    print("  absent          : %d" % absent)
    print("  absence rate    : %s" % ("n/a" if rate is None else "%.3f%%" % (100 * rate)))
    print("  > 30%%           : %s" % result["exceeds_30pct"])
    if result["exceeds_30pct"]:
        print("\n  => charter 3.3 DOWNGRADE applies to the T=%d window,"
              % args.window)
        print("     automatically and without discretion.")
    else:
        print("\n  => T=%d window passes; no downgrade." % args.window)
    print("=" * 66)
    print("wrote %s" % args.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
