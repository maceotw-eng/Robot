#!/usr/bin/env python3
"""
Offline self-test for the PM-2 recorder.

Validates signing, the rate limiter, universe filtering and the full capture
pipeline against a mock transport - no credentials and no network needed.
Run this before shipping to the VPS.

    python selftest.py            # run checks
    python selftest.py --sample   # also emit a schema-accurate mock snapshot
"""

import argparse
import hashlib
import hmac
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import recorder  # noqa: E402

FAILURES = []


def check(name, condition, detail=""):
    if condition:
        print("  PASS  %s" % name)
    else:
        print("  FAIL  %s %s" % (name, detail))
        FAILURES.append(name)


def load_cfg():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


# ---------------------------------------------------------------- 1. signing

def test_signing():
    print("\n[1] HMAC-SHA256 signing")
    # Official Binance documentation test vector.
    secret = "NhqPtmdSJYdKjVHjA7PZj4Mge3R5YNiP1e3UZjInClVN65XAbvqqM6A7H5fATj0j"
    query = ("symbol=LTCBTC&side=BUY&type=LIMIT&timeInForce=GTC&quantity=1"
             "&price=0.1&recvWindow=5000&timestamp=1499827319559")
    expected = "c8db56825ae71d6d79447849e617115f4a920fa2acdcab2b053c4b2838bd6b71"
    got = hmac.new(secret.encode(), query.encode(), hashlib.sha256).hexdigest()
    check("Binance doc test vector reproduces", got == expected,
          "\n        expected %s\n        got      %s" % (expected, got))

    cfg = load_cfg()
    client = recorder.PredictionClient(cfg, "KEY", secret)
    signed = client._sign({
        "symbol": "LTCBTC", "side": "BUY", "type": "LIMIT", "timeInForce": "GTC",
        "quantity": 1, "price": "0.1", "recvWindow": 5000,
        "timestamp": 1499827319559,
    })
    check("client._sign matches the same vector",
          signed == query + "&signature=" + expected, "\n        got %s" % signed)
    check("signature is appended last, not signed over itself",
          signed.count("signature=") == 1 and signed.endswith(expected))

    # tokenId values are long decimal strings; make sure nothing mangles them.
    long_token = "7141926894764" * 5
    out = client._sign({"vendor": "predict_fun", "marketId": 8859231,
                        "tokenId": long_token, "timestamp": 1})
    check("long tokenId survives urlencode intact", long_token in out)


# ---------------------------------------------------------------- 2. limiter

def test_limiter():
    print("\n[2] Rate limiter (12000/min, weight 200, safety 0.75 -> 45 calls/min)")
    lim = recorder.EndpointLimiter(12000, 0.75)
    budget_calls = int((12000 * 0.75) // 200)
    check("budget computes to 45 calls/min", budget_calls == 45,
          "got %d" % budget_calls)

    t0 = time.monotonic()
    for _ in range(budget_calls):
        lim.acquire(200)
    elapsed = time.monotonic() - t0
    check("first %d calls pass without blocking" % budget_calls, elapsed < 1.0,
          "took %.2fs" % elapsed)
    check("used weight tracked correctly", lim.used == budget_calls * 200,
          "used=%s" % lim.used)

    # The 46th must block, so verify against a tiny budget rather than waiting 60s.
    small = recorder.EndpointLimiter(400, 1.0)
    small.acquire(200)
    small.acquire(200)
    check("limiter refuses to exceed budget without waiting",
          small.used == 400)

    small.events[0] = (time.monotonic() - 61.0, 200)
    small.events[1] = (time.monotonic() - 61.0, 200)
    t0 = time.monotonic()
    small.acquire(200)
    check("expired events are evicted so the window slides",
          time.monotonic() - t0 < 0.5)

    lim2 = recorder.EndpointLimiter(12000, 0.75)
    lim2.acquire(200)
    lim2.note_server_usage(5000.0)
    check("server-reported weight reconciles upward", lim2.used == 5000.0,
          "used=%s" % lim2.used)


# ---------------------------------------------------------------- 3. filters

def mock_topic(tid, status="ACTIVE", vol="50000", end_offset_days=3, outcomes=True):
    now_ms = int(time.time() * 1000)
    topic = {
        "marketTopicId": tid,
        "vendor": "predict_fun",
        "chainId": "8453",
        "slug": "topic-%d" % tid,
        "title": "Mock topic %d" % tid,
        "question": "Will mock event %d happen?" % tid,
        "status": status,
        "tradeVolume": vol,
        "liquidity": "12345.67",
        "participantCount": 88,
        "collateral": "USDT",
        "feeRateBps": 100,
        "slippageBps": 50,
        "isYieldBearing": False,
        "topicType": "BINARY",
        "symbol": None,
        "publishedAt": now_ms - 86400000,
        "startDate": now_ms - 86400000,
        "endDate": now_ms + end_offset_days * 86400000,
    }
    if outcomes:
        topic["markets"] = [{
            "marketId": 900000 + tid,
            "externalId": "ext-%d" % tid,
            "conditionId": "0xcond%d" % tid,
            "title": "Mock market %d" % tid,
            "question": "Will mock event %d happen?" % tid,
            "status": "OPEN",
            "tradingStatus": "TRADING",
            "tradeVolume": vol,
            "liquidity": "12345.67",
            "decimalPrecision": 6,
            "outcomes": [
                {"name": "Yes", "price": "0.62", "chance": "62",
                 "index": 0, "tokenId": "71419268947640000%d" % tid},
                {"name": "No", "price": "0.38", "chance": "38",
                 "index": 1, "tokenId": "71419268947641111%d" % tid},
            ],
        }]
    else:
        topic["markets"] = [{"marketId": 900000 + tid}]  # no tokenId -> needs detail
    return topic


def test_filters():
    print("\n[3] Universe filtering and selection")
    sel = {"strategy": "ending_soonest", "max_topics": 2,
           "include_status": ["ACTIVE"], "min_trade_volume": 10000,
           "max_days_to_resolution": None}
    topics = [
        mock_topic(1, end_offset_days=9),
        mock_topic(2, status="RESOLVED"),
        mock_topic(3, vol="500"),
        mock_topic(4, end_offset_days=1),
        mock_topic(5, end_offset_days=5),
    ]
    capped, raw, dropped, kept = recorder.filter_universe(topics, sel)
    check("raw count preserved", raw == 5)
    check("RESOLVED dropped by status", dropped["status"] == 1)
    check("low volume dropped", dropped["volume"] == 1)
    check("3 topics pass filters", kept == 3, "kept=%d" % kept)
    check("cap applied", len(capped) == 2)
    check("ending_soonest ordering", [t["marketTopicId"] for t in capped] == [4, 5],
          "got %s" % [t["marketTopicId"] for t in capped])

    sel2 = dict(sel, max_days_to_resolution=2, max_topics=10)
    _, _, dropped2, kept2 = recorder.filter_universe(topics, sel2)
    check("horizon filter drops far-dated", dropped2["horizon"] == 2 and kept2 == 1,
          "dropped=%s kept=%d" % (dropped2, kept2))

    sel3 = dict(sel, strategy="top_volume", max_topics=10, min_trade_volume=0,
                include_status=[])
    capped3, _, _, _ = recorder.filter_universe(
        [mock_topic(1, vol="100"), mock_topic(2, vol="9000"),
         mock_topic(3, vol="500")], sel3)
    check("top_volume ordering",
          [t["marketTopicId"] for t in capped3] == [2, 3, 1],
          "got %s" % [t["marketTopicId"] for t in capped3])

    check("extract_markets finds outcomes with tokenId",
          len(recorder.extract_markets(mock_topic(1))) == 1)
    check("extract_markets skips markets lacking tokenId",
          recorder.extract_markets(mock_topic(1, outcomes=False)) == [])


# ---------------------------------------------------------------- 4. capture

class MockClient:
    """Stands in for PredictionClient; records the call sequence."""

    def __init__(self, cfg, n_topics=3, embed_outcomes=True):
        self.cfg = cfg
        self.n_topics = n_topics
        self.embed_outcomes = embed_outcomes
        self.calls = []
        self.call_count = 0
        self.raw_records = []

    def call(self, endpoint, params=None, context=None):
        self.calls.append(endpoint)
        self.call_count += 1
        params = params or {}

        if endpoint == "market_list":
            return {
                "marketTopics": [mock_topic(i, outcomes=self.embed_outcomes)
                                 for i in range(1, self.n_topics + 1)],
                "total": self.n_topics, "offset": 0,
                "limit": 100, "hasMore": False,
            }
        if endpoint == "market_detail":
            return mock_topic(params["marketTopicId"], outcomes=True)
        if endpoint == "order_book":
            return {
                "outcome": "Yes",
                "tokenId": params["tokenId"],
                "timestamp": int(time.time() * 1000),
                "bids": [{"price": "0.61", "size": "1500"},
                         {"price": "0.60", "size": "3200"},
                         {"price": "0.58", "size": "5000"},
                         {"price": "0.55", "size": "8000"},
                         {"price": "0.50", "size": "12000"}],
                "asks": [{"price": "0.63", "size": "1400"},
                         {"price": "0.64", "size": "2900"},
                         {"price": "0.66", "size": "4800"},
                         {"price": "0.70", "size": "7700"},
                         {"price": "0.75", "size": "11000"}],
            }
        if endpoint == "last_trade_price":
            return {"marketId": params["marketId"], "lastTradePrice": "0.62"}
        return {}


def test_capture(emit_sample=False):
    print("\n[4] Capture pipeline (mock transport)")
    cfg = load_cfg()
    cfg["selection"]["min_trade_volume"] = 0
    cfg["selection"]["max_topics"] = 3

    client = MockClient(cfg, n_topics=3, embed_outcomes=True)
    records, stats, errors = recorder.capture(client, cfg, "TEST", 1700000000000)

    check("one record per topic (Yes leg only)", len(records) == 3,
          "got %d" % len(records))
    check("no market/detail calls when list embeds tokenId",
          "market_detail" not in client.calls)
    check("no errors", not errors, str(errors))
    rec = records[0]
    check("mid_price computed", abs(rec["mid_price"] - 0.62) < 1e-9,
          "got %s" % rec["mid_price"])
    check("spread computed", abs(rec["spread"] - 0.02) < 1e-9,
          "got %s" % rec["spread"])
    check("5 levels each side captured",
          rec["bid_levels"] == 5 and rec["ask_levels"] == 5)
    check("feeRateBps carried through for 0b", rec["feeRateBps"] == 100)
    check("conditionId carried through for ID mapping",
          rec["conditionId"] == "0xcond1")
    check("lastTradePrice populated", rec["lastTradePrice"] == "0.62")
    check("stats orderbook_ok correct", stats["orderbook_ok"] == 3)

    # Fallback path: list has no tokenId, so market/detail must be called.
    client2 = MockClient(cfg, n_topics=3, embed_outcomes=False)
    records2, stats2, _ = recorder.capture(client2, cfg, "TEST2", 1700000000000)
    check("market/detail called when list lacks tokenId",
          client2.calls.count("market_detail") == 3,
          "got %d" % client2.calls.count("market_detail"))
    check("fallback still produces records", len(records2) == 3)
    check("stats records detail_calls", stats2["detail_calls"] == 3)

    # Both outcomes.
    cfg2 = load_cfg()
    cfg2["selection"].update({"min_trade_volume": 0, "max_topics": 3,
                              "fetch_all_outcomes": True})
    client3 = MockClient(cfg2, n_topics=3, embed_outcomes=True)
    records3, _, _ = recorder.capture(client3, cfg2, "TEST3", 1700000000000)
    check("fetch_all_outcomes=true doubles the record count",
          len(records3) == 6, "got %d" % len(records3))

    if emit_sample:
        out = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "sample_snapshot.json")
        header = {
            "_type": "snapshot_meta",
            "_WARNING": "SYNTHETIC MOCK DATA - field names and types match the "
                        "Binance OpenAPI 3.1.1 spec, values are fabricated. "
                        "Replace with a real VPS capture before relying on values.",
            "snapshot_id": "TEST", "recorder_version": "1.0",
            "source": "binance_w3w_prediction", "stats": stats,
        }
        with open(out, "w", encoding="utf-8") as fh:
            json.dump({"meta": header, "records": records[:2]}, fh,
                      ensure_ascii=False, indent=2)
        print("\n  wrote schema sample -> %s" % out)


# ------------------------------------------------- 5. registry + resolutions

def settled_detail(winner="Yes", status="RESOLVED", void=False):
    return {
        "marketTopicId": 1,
        "status": "VOIDED" if void else status,
        "markets": [{
            "marketId": 900001,
            "conditionId": "0xcond1",
            "externalId": "ext-1",
            "question": "Will mock event 1 happen?",
            "status": "VOIDED" if void else status,
            "tradingStatus": "CLOSED",
            "outcomes": [
                {"name": "Yes", "price": "1" if winner == "Yes" else "0", "index": 0},
                {"name": "No", "price": "1" if winner == "No" else "0", "index": 1},
            ],
        }],
    }


def test_resolution():
    print("\n[5] Registry and resolution capture")
    cfg = load_cfg()
    check("config selects by volume, not date",
          cfg["selection"]["strategy"] == "top_volume",
          "got %s" % cfg["selection"]["strategy"])
    check("resolution tracking enabled",
          cfg.get("resolution_tracking", {}).get("enabled") is True)

    # -- extractor --------------------------------------------------------
    yes = recorder.extract_resolution(settled_detail("Yes"))[0]
    check("YES win read from price convergence",
          yes["verdict"] == "resolved" and yes["winner"] == "Yes"
          and yes["basis"] == "price_convergence",
          "got %s" % yes)
    no = recorder.extract_resolution(settled_detail("No"))[0]
    check("NO win read correctly",
          no["verdict"] == "resolved" and no["winner"] == "No")
    voided = recorder.extract_resolution(settled_detail(void=True))[0]
    check("voided detected from status", voided["verdict"] == "voided",
          "got %s" % voided["verdict"])

    live = recorder.extract_resolution({
        "status": "ACTIVE",
        "markets": [{"marketId": 1, "status": "OPEN", "tradingStatus": "TRADING",
                     "outcomes": [{"name": "Yes", "price": "0.62", "index": 0},
                                  {"name": "No", "price": "0.38", "index": 1}]}],
    })[0]
    check("un-converged prices stay unresolved",
          live["verdict"] == "ended_unresolved" and live["winner"] is None)

    ambiguous = recorder.extract_resolution({
        "status": "RESOLVED",
        "markets": [{"marketId": 1, "status": "RESOLVED", "tradingStatus": "CLOSED",
                     "outcomes": [{"name": "Yes", "price": "0.5", "index": 0},
                                  {"name": "No", "price": "0.5", "index": 1}]}],
    })[0]
    check("status says resolved but no winner is flagged, not guessed",
          ambiguous["verdict"] == "ended_unresolved"
          and ambiguous["basis"] == "status_says_resolved_no_winner",
          "got %s" % ambiguous)

    # -- registry ---------------------------------------------------------
    now_ms = int(time.time() * 1000)
    records = [{
        "marketTopicId": 7, "marketId": 900007, "vendor": "predict_fun",
        "slug": "s7", "title": "t7", "question": "q7",
        "endDate": now_ms - 10 * 3600000, "topic_status": "ACTIVE",
        "conditionId": "0xc7", "externalId": "e7", "mid_price": 0.62,
        "market_tradeVolume": "50000", "market_question": "q7",
    }]
    registry = {}
    added = recorder.register_snapshot(registry, records, now_ms)
    check("new market registered", added == 1 and "7" in registry)
    again = recorder.register_snapshot(registry, records, now_ms + 1000)
    check("re-seeing a market updates, does not duplicate",
          again == 0 and len(registry) == 1)
    check("market leg recorded under the topic",
          "900007" in registry["7"]["markets"])
    check("conditionId kept for cross-venue mapping",
          registry["7"]["markets"]["900007"]["conditionId"] == "0xc7")

    tmp_reg = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "_selftest_registry.json")
    recorder.save_registry(tmp_reg, registry)
    check("registry round-trips through disk",
          recorder.load_registry(tmp_reg) == registry)

    # -- sweep ------------------------------------------------------------
    class SweepClient:
        def __init__(self):
            self.calls = 0

        def call(self, endpoint, params=None, context=None):
            self.calls += 1
            return settled_detail("Yes")

    cfg["resolution_tracking"]["grace_period_hours"] = 1
    sweeper = SweepClient()
    stats, rows = recorder.resolution_sweep(sweeper, cfg, registry)
    check("ended market is swept", stats["checked"] == 1 and sweeper.calls == 1,
          "stats=%s calls=%d" % (stats, sweeper.calls))
    check("resolution row emitted", len(rows) == 1)
    check("row carries the winner", rows[0]["winner"] == "Yes")
    check("registry marked resolved",
          registry["7"]["resolution_state"] == "resolved")

    stats2, rows2 = recorder.resolution_sweep(sweeper, cfg, registry)
    check("resolved market is not re-polled",
          stats2["checked"] == 0 and not rows2)

    # A market still in its grace window must not be touched yet.
    fresh = {"9": {"marketTopicId": 9, "endDate": now_ms - 60000,
                   "resolution_state": "live", "attempts": 0,
                   "last_attempt_ms": None, "markets": {}}}
    stats3, _ = recorder.resolution_sweep(SweepClient(), cfg, fresh)
    check("grace period respected", stats3["checked"] == 0,
          "checked=%d" % stats3["checked"])

    # -- csv --------------------------------------------------------------
    tmp_csv = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "_selftest_resolutions.csv")
    if os.path.exists(tmp_csv):
        os.remove(tmp_csv)
    recorder.append_resolutions(tmp_csv, rows)
    recorder.append_resolutions(tmp_csv, rows)
    with open(tmp_csv, encoding="utf-8") as fh:
        lines = [ln for ln in fh.read().splitlines() if ln.strip()]
    check("csv writes one header plus one row per append",
          len(lines) == 3 and lines[0].startswith("captured_at"),
          "got %d lines" % len(lines))

    for path in (tmp_reg, tmp_csv):
        if os.path.exists(path):
            os.remove(path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sample", action="store_true",
                    help="also write sample_snapshot.json")
    args = ap.parse_args()

    import logging
    logging.getLogger("pm2rec").addHandler(logging.NullHandler())
    logging.getLogger("pm2rec").setLevel(logging.CRITICAL)

    print("=" * 62)
    print("PM-2 recorder self-test (offline, no credentials required)")
    print("=" * 62)
    test_signing()
    test_limiter()
    test_filters()
    test_capture(emit_sample=args.sample)
    test_resolution()

    print("\n" + "=" * 62)
    if FAILURES:
        print("FAILED: %d check(s) -> %s" % (len(FAILURES), ", ".join(FAILURES)))
        return 1
    print("ALL CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
