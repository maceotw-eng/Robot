#!/usr/bin/env bash
# Cron entrypoint. Keeps cron's bare environment from breaking the run.
set -euo pipefail
cd "$(dirname "$0")"
exec /usr/bin/env python3 recorder.py --env ./.env >> logs/cron.out 2>&1
