# pm_recorder — PM-2 A 線錄影機

每 20 分鐘對幣安預測市場拍一張快照(市場元資料 + 完整訂單簿深度 + 最新成交價),
落地成 NDJSON,供 PM-2 Phase 0b 回放使用。

僅用 Python 標準庫,**VPS 不需要 pip install 任何東西**。Python 3.8+。

端點與簽名規格取自幣安 OpenAPI 3.1.1 spec(2026-08-24 查證),
完整考證見 `../docs/binance_prediction_api_findings.md`。

---

## 快速部署(VPS)

```bash
unzip pm_recorder.zip && cd pm_recorder
cp .env.example .env && chmod 600 .env
vi .env                      # 填入 BINANCE_API_KEY / BINANCE_API_SECRET
python3 selftest.py          # 離線自檢,不需憑證(應 49 項全 PASS)
python3 recorder.py --dry-run            # ① 驗憑證 + 簽名 + IP 白名單
python3 recorder.py --probe-resolution   # ② 驗結算結果抓不抓得到 ← 必跑
python3 recorder.py --max-topics 5       # ③ 小規模實抓一輪
python3 recorder.py                      # ④ 完整一輪
crontab -e                               # 掛上排程(見下)
```

**第 ② 步不能跳。** 它回答的是 0b 分母能不能成立的問題,見下節。
輸出末尾有「READ THIS OFF THE OUTPUT ABOVE」三條判讀規則,照著讀就知道結果是好是壞。

Cron(每小時 3、23、43 分):

```
3,23,43 * * * * /opt/pm_recorder/run_snapshot.sh
```

`run_snapshot.sh` 會自己 `cd` 到腳本目錄並把輸出附加到 `logs/cron.out`,
不依賴 cron 的環境變數。

---

## ⚠️ 部署前必讀的兩個硬約束

**1. 市場數據端點需要簽名,不是公開端點。**
六支 market-data 端點在 spec 上全標 `x-signed: true`。沒有有效憑證 → 抓不到任何行情。
API key 需開通 Web3 Wallet / Prediction 權限,且 **VPS 對外 IP 要在該 key 的白名單上**。
本機通常會被擋 → 直接在 VPS 上測。

**2. 每次呼叫 IP weight = 200,很重。**
文件:「Each endpoint with IP limits has an **independent** 12000 per minute limit.」
→ 每支端點各自 12000 ÷ 200 = **60 次/分鐘**。本程式取 `safety_factor 0.75` → 45 次/分鐘。

| 市場數 | order-book 呼叫 | 約需時間 |
|---|---|---|
| 50  | 50  | ~1.1 分 |
| 150 | 150 | ~3.3 分 |
| 400 | 400 | ~8.9 分 |
| 900 | 900 | ~20 分 ← **會撞上下一次 cron** |

預設 `max_topics: 150`。上調前先確認單輪跑完時間 < 20 分鐘。
超時也不會疊爆:`.recorder.lock` 會讓下一輪直接退出(並在 log 留下記錄)。

---

## 結算結果捕捉(0b 的分母)

錄影機錄的是**活市場**。但 0b 要算「實際發生頻率」,需要的是**已結算市場最後開出什麼** ——
而市場一結算就不再是活市場(WS 文件明寫「resolved / closed markets are not pushed」),
且這 36 支端點**沒有任何歷史類端點**可以事後回頭問。

於是:**看見的當下沒寫下來,就永久遺失。** 錄一年也拼不出 0b 的分母。

機制:

```
每輪快照結束
   │
   ├─ 註冊:所有看過的市場寫進 state/registry.json
   │        (marketTopicId / marketId / conditionId / endDate / 最後價格)
   │
   └─ 掃描:registry 中 endDate 已過 + 超過 grace_period 的,打 market/detail
            ├─ 讀到結算 → 寫入 state/resolutions.csv,標記 resolved/voided,不再輪詢
            ├─ 還沒結算 → 等 recheck_interval_hours 後再試
            └─ 試滿 max_attempts(預設 40 次 × 6h ≈ 10 天)→ 標 unresolvable
```

掃描用的是 `market/detail`,它有**自己獨立的 12000/min 預算**,不與訂單簿爭配額。
掃描失敗**不會影響已完成的快照**(包在獨立的 try 裡)。

`resolutions.csv` 欄位:
`captured_at, marketTopicId, marketId, conditionId, externalId, slug, question,
endDate, verdict, winner, basis, topic_status, market_status, trading_status,
outcome_prices, attempts`

**`basis` 欄位是刻意留的。** 結算欄位的實際語義尚未經實測驗證,所以萃取器
**記錄它靠哪個訊號判定**,而不是悄悄斷言一個結果:

| `basis` | 意思 |
|---|---|
| `price_convergence` | 某個 outcome 價格 ≥0.99 且另一個 ≤0.01 → 可信 |
| `status_field` | 狀態欄位出現 VOID/INVALID/CANCEL → 判為 voided |
| `status_says_resolved_no_winner` | 狀態說結算了但價格看不出贏家 → **不猜**,標 unresolved 繼續輪詢 |
| `detail_error:<code>` | 已結束市場查不到了 → 需縮短 grace_period |

`--probe-resolution` 就是用來提前把這件事驗清楚的,**第一輪 VPS 實跑就要跑**。
若輸出顯示每一筆都是 `ended_unresolved`,代表狀態欄位不編碼贏家,萃取規則要重寫 —— 回報即可。

## 抓取流程

```
market/list  (分頁, limit=100, sortBy=VOLUME DESC)
      │  篩選 status / tradeVolume / 距結算天數 → 依 max_topics 截斷
      ▼
[若 list 已含 outcomes[].tokenId → 直接用,省下一半呼叫]
[否則] market/detail (每個 topic 一次) → 取 outcomes[].tokenId
      ▼
order-book        (每個 outcome token 一次) ← 主要成本
last-trade-price  (每個 marketId 一次, 有快取)
      ▼
data/YYYY-MM-DD/snap_<UTC>.ndjson.gz
raw /YYYY-MM-DD/raw_<UTC>.ndjson.gz   ← 原始回應封存(章程 §2「原始數據落地封存」)
state/registry.json                   ← 曾見過的所有市場(結算追蹤名單)
state/resolutions.csv                 ← 結算結果(0b 的分母)
```

`tokenId` 只有 `market/detail` 保證提供,而 `order-book` 必須用 `tokenId` 查。
spec 中 `market/list` 的 `markets[]` 是未展開的泛型 object,實跑時若含 tokenId
本程式會自動沿用(`always_fetch_detail: false`),省掉整層 detail 呼叫。
第一輪實抓後看 log 的 `outcomes: N topics resolved from list payload` 就知道走哪條路。

---

## 輸出格式

NDJSON,gzip。**第一行是 `_type: "snapshot_meta"` 的表頭**(含統計與錯誤),
其後每行 = 一個市場結果(outcome)。

讀取:

```bash
zcat data/2026-08-24/snap_*.ndjson.gz | head -1 | python3 -m json.tool   # 表頭
zcat data/2026-08-24/snap_*.ndjson.gz | tail -n +2 | head -1 | python3 -m json.tool
```

每筆記錄的關鍵欄位:

| 欄位 | 用途 |
|---|---|
| `snapshot_id` / `captured_at_ms` | 快照時點 |
| `marketTopicId` / `marketId` / `tokenId` | 幣安側三層 ID |
| `conditionId` / `externalId` | **跨場對映用**(見下) |
| `endDate` | 結算時點 → 算「結算前 T 日」 |
| `feeRateBps` / `slippageBps` | **§4 說 0b 要用的實際費率,API 直供** |
| `orderbook.bids[]` / `.asks[]` | 完整深度(上游通常 ≤ 50 檔) |
| `best_bid` / `best_ask` / `mid_price` / `spread` | 預算好的便利欄位 |
| `lastTradePrice` | 最新成交價 |
| `topic_tradeVolume` / `topic_liquidity` | 流動性門檻篩選 |
| `orderbook_error` | 該筆抓取失敗原因(不靜默吞) |

`sample_snapshot.json` 是 **schema 正確但數值虛構** 的樣本(由 selftest 產生),
真實樣本要等 VPS 首輪跑完。

---

## 設定檔重點(`config.json`)

| 鍵 | 預設 | 說明 |
|---|---|---|
| `selection.max_topics` | 150 | 單輪市場數上限。**主要的時間旋鈕** |
| `selection.strategy` | `top_volume` | **裁決 2026-08-24:取流動性前 N**,不是隨機或依日期。0b 只關心打得進去的市場。也可 `ending_soonest` / `all` |
| `selection.fetch_all_outcomes` | `false` | `false` 只抓 Yes 腳,呼叫數減半 |
| `selection.always_fetch_detail` | `false` | `true` 強制每個 topic 都打 detail |
| `selection.min_trade_volume` | 0 | 章程 §2 用 $10,000,那是 0a 樣本門檻; 錄影機先廣收,篩選留給分析階段 |
| `selection.max_days_to_resolution` | `null` | 設數字可只錄近期到期市場 |
| `rate_limit.safety_factor` | 0.75 | 調高會逼近 429 |
| `output.archive_raw_responses` | `true` | 章程 §2 要求原始封存 |
| `resolution_tracking.enabled` | `true` | 關掉就沒有 0b 分母,別關 |
| `resolution_tracking.grace_period_hours` | 2 | endDate 後多久開始輪詢結算 |
| `resolution_tracking.max_checks_per_run` | 120 | 單輪結算輪詢上限(≈2.7 分) |
| `resolution_tracking.recheck_interval_hours` | 6 | 未結算者的重試間隔 |
| `resolution_tracking.max_attempts` | 40 | 40 × 6h ≈ 10 天後放棄 |

---

## 疑難排解

| 症狀 | 意義 | 處置 |
|---|---|---|
| `code=-2015` / HTTP 401 | key 無效、權限不足,或 **IP 不在白名單** | 在 VPS 上跑;把 VPS 出口 IP 加進 key 白名單 |
| `code=-1022` | 簽名不符 | 檢查 secret 有無多餘空白/換行 |
| `code=-1021` | timestamp 超出 recvWindow | 校時:`timedatectl set-ntp true` |
| HTTP 429 | 撞速率限制 | 自動退避;持續發生就調低 `safety_factor` 或 `max_topics` |
| HTTP 418 | IP 已被 ban | 自動睡 120s;先停 cron 再排查 |
| `another run is in progress` | 上一輪還沒跑完 | 正常保護。若常出現,調低 `max_topics` |
| `resolution backlog: N due but max_checks_per_run=M` | 結算輪詢積壓 | 調高 `max_checks_per_run`。積壓本身不丟資料(registry 記著),但會延後 |
| `registry unreadable ... OLD ENTRIES ARE LOST` | registry.json 損毀 | **嚴重**。從最近的備份還原,否則該批市場的結算永久遺失 |
| `TRUNCATED: N topics passed filters` | 有市場被 `max_topics` 砍掉沒錄到 | 這行**一定要看**,否則會誤以為錄全了 |

---

## 尚未做、留給下一步的

- **不做歷史回補。** 這 36 支端點裡沒有任何 price history 端點,幣安側歷史只能靠
  本錄影機從今天起自己累積。0a 的歷史仍然只能來自 Polymarket。
  同理,**掛機之前就已結算的市場,其結算結果拿不到** —— registry 只涵蓋上線後看過的市場。
- **不下單。** 只讀行情。(順帶:文件自陳 `trade/batch-cancel` 的
  `cancelInfoList[0].orderId` 中括號參數與主流 HTTP 函式庫的自動百分比編碼衝突,
  簽名會對不上 —— C 軌真要下單時會踩到。)
- **未走 WebSocket。** 20 分鐘粒度用 REST 足夠。若 0b 之後需要 tick 級深度,
  聚合 topic `web3_prediction_orderbook_data` 一條連線可涵蓋所有市場,
  且完全繞開 60 次/分的天花板 —— 屆時再補。

---

## 備份(建議)

`state/registry.json` 是不可重建的資產 —— 它記錄的市場一旦結算並消失,沒有任何端點
能還原。建議加一條 cron:

```
17 4 * * * cd /opt/pm_recorder && cp state/registry.json state/registry.$(date +\%Y\%m\%d).json && find state -name 'registry.2*.json' -mtime +14 -delete
```
