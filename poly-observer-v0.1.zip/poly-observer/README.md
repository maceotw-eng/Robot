# Polymarket 觀察站 v0.1（純觀察模式）

不下單、不需錢包、不需 API key。兩個模組：

## 1. 套利掃描器（src/index.js，pm2 常駐）
每 60 秒掃描活躍二元市場的掛單簿：
- 「買YES最低價 + 買NO最低價 < $1」→ 無風險組合套利機會
- 記錄機會的價差、可吃深度、持續時間 → data/arb_log.csv
一週後看 report 統計「肉夠不夠吃」。

## 2. 熱門低估偏差回測（src/backtest.js，跑一次即可）
抓歷史已結算市場，取結算前的價格分桶：
市場價 85–95¢ 的「熱門」，真實勝率是否 > 定價隱含機率？
若長期為正 → favorite bias 在 Polymarket 成立，值得做成策略。

## 部署（與 memebot 同一台 VPS）
```bash
cd ~
wget -O poly.zip "<你上傳GitHub後的zip連結>"
unzip poly.zip && cd poly-observer
pm2 start src/index.js --name polyscan
pm2 save
node src/backtest.js          # 回測跑一次，約5-10分鐘
```
記憶體註記：memebot + polyscan 兩個程序約需 250MB，0.5GB RAM + 1GB swap 可承受。

## 日常
```bash
node src/report.js                          # 套利機會統計
pm2 logs polyscan --lines 20 --nostream     # 看日誌
```
