// 套利機會統計：node src/report.js
import fs from "fs";
const CSV = "data/arb_log.csv";
if (!fs.existsSync(CSV)) { console.log("尚無套利紀錄（讓 polyscan 先跑一陣子）"); process.exit(0); }
const rows = fs.readFileSync(CSV, "utf8").trim().split("\n").slice(1).map(l => l.split(","));
if (!rows.length) { console.log("尚無套利紀錄"); process.exit(0); }
const edges = rows.map(r => parseFloat(r[5])).filter(isFinite);
const depths = rows.map(r => parseFloat(r[6])).filter(isFinite);
const hours = (Date.parse(rows[rows.length-1][0]) - Date.parse(rows[0][0])) / 36e5 || 1;
const avg = a => a.reduce((x,y)=>x+y,0)/a.length;
const sorted = [...edges].sort((a,b)=>a-b);
console.log("═══ 套利機會統計 ═══");
console.log("觀察時長:", hours.toFixed(1), "小時 | 機會筆數:", rows.length, "| 頻率:", (rows.length/hours).toFixed(1), "筆/小時");
console.log("價差 edge: 平均", avg(edges).toFixed(2)+"%", "| 中位", sorted[Math.floor(sorted.length/2)].toFixed(2)+"%", "| 最大", Math.max(...edges).toFixed(2)+"%");
console.log("可吃深度: 平均 $"+avg(depths).toFixed(0), "| 最大 $"+Math.max(...depths).toFixed(0));
const daily = avg(edges)/100 * avg(depths) * (rows.length/hours) * 24;
console.log("粗估理論日收益（吃滿所有機會，未扣gas/滑點）: $"+daily.toFixed(2));
console.log("注意：實際可捕獲率遠低於100%（速度競爭），此數字是天花板不是預期。");
