// ═══════════════════════════════════════════════
// Polymarket 觀察站 — 套利機會掃描器（純觀察）
// 原理：二元市場「買YES最低賣價 + 買NO最低賣價」理論值 = $1
//       低於 $1 → 兩邊都買進即鎖定無風險價差（不含手續費/gas）
// 本程式只記錄機會，不下單。
// ═══════════════════════════════════════════════
import fs from "fs";

const GAMMA = "https://gamma-api.polymarket.com";
const CLOB = "https://clob.polymarket.com";
const SCAN_SEC = 60;
const MIN_EDGE = 0.005;      // 價差 ≥ 0.5¢ 才記錄
const TOP_MARKETS = 150;     // 只掃成交量前 N 的活躍市場
const CSV = "data/arb_log.csv";

fs.mkdirSync("data", { recursive: true });
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);

async function jget(url) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 15000);
  try {
    const r = await fetch(url, { headers: { Accept: "application/json" }, signal: ctrl.signal });
    if (!r.ok) throw new Error("HTTP " + r.status);
    return await r.json();
  } finally { clearTimeout(t); }
}

// 取活躍二元市場（含 CLOB token ids）
async function activeMarkets() {
  const out = [];
  // Gamma markets API：active、依成交量排序
  const d = await jget(GAMMA + "/markets?active=true&closed=false&order=volumeNum&ascending=false&limit=" + TOP_MARKETS);
  const arr = Array.isArray(d) ? d : [];
  for (const m of arr) {
    let toks = m.clobTokenIds;
    if (typeof toks === "string") { try { toks = JSON.parse(toks); } catch (e) { toks = null; } }
    if (Array.isArray(toks) && toks.length === 2) {
      out.push({ q: (m.question || "").slice(0, 80), yes: toks[0], no: toks[1], vol: m.volumeNum || 0 });
    }
  }
  return out;
}

// 取單一 token 的最佳賣價與該價位深度
async function bestAsk(tokenId) {
  const d = await jget(CLOB + "/book?token_id=" + tokenId);
  const asks = (d && d.asks) || [];
  if (!asks.length) return null;
  // CLOB book: asks 依價格排序，取最低賣價
  let best = null;
  for (const a of asks) {
    const p = parseFloat(a.price), s = parseFloat(a.size);
    if (!isFinite(p) || !isFinite(s)) continue;
    if (!best || p < best.p) best = { p, s };
  }
  return best;
}

function appendCsv(row) {
  if (!fs.existsSync(CSV)) fs.writeFileSync(CSV, "time,question,yesAsk,noAsk,sum,edgePct,depthUsd\n");
  fs.appendFileSync(CSV, row.map(v => String(v).replace(/,/g, ";")).join(",") + "\n");
}

let markets = [], lastMktRefresh = 0;
let scanning = false;

async function tick() {
  if (scanning) return;
  scanning = true;
  try {
    if (Date.now() - lastMktRefresh > 15 * 60e3 || !markets.length) {
      markets = await activeMarkets();
      lastMktRefresh = Date.now();
      log(`市場清單更新：${markets.length} 個活躍二元市場`);
    }
    let found = 0, checked = 0;
    for (const m of markets) {
      // 順序輪詢 + 輕度限流，避免打爆公開API
      const [ya, na] = [await bestAsk(m.yes), await bestAsk(m.no)];
      checked++;
      if (checked % 10 === 0) await new Promise(r => setTimeout(r, 500));
      if (!ya || !na) continue;
      const sum = ya.p + na.p;
      const edge = 1 - sum;
      if (edge >= MIN_EDGE) {
        const depth = Math.min(ya.s * ya.p, na.s * na.p); // 可同時吃到的美元深度
        found++;
        appendCsv([new Date().toISOString(), m.q, ya.p.toFixed(3), na.p.toFixed(3), sum.toFixed(3), (edge * 100).toFixed(2), depth.toFixed(0)]);
        log(`💰 套利機會 edge=${(edge * 100).toFixed(2)}% depth=$${depth.toFixed(0)} | ${m.q}`);
      }
    }
    log(`掃描完成 ${checked} 個市場 | 本輪機會 ${found} 筆`);
  } catch (e) { log("tick 錯誤:", e.message); }
  scanning = false;
}

log(`Polymarket 套利掃描器啟動（純觀察）| 每 ${SCAN_SEC}s | 門檻 edge≥${MIN_EDGE * 100}% | 掃前 ${TOP_MARKETS} 大市場`);
tick();
setInterval(tick, SCAN_SEC * 1000);
