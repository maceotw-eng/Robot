// ═══════════════════════════════════════════════
// backtest.js — 熱門低估偏差（favorite-longshot bias）回測
// 方法：抓已結算市場 → 取結算前48h的YES價格 → 依價格分桶
//       比較「市場隱含機率」vs「真實勝率」
// 若 85–95¢ 桶的真實勝率 > 隱含機率 → 熱門被低估，偏差成立
// 用法：node src/backtest.js [樣本數上限,預設300]
// ═══════════════════════════════════════════════
import fs from "fs";

const GAMMA = "https://gamma-api.polymarket.com";
const CLOB = "https://clob.polymarket.com";
const MAX_N = parseInt(process.argv[2]) || 300;
const CACHE = "data/backtest_cache.json";
fs.mkdirSync("data", { recursive: true });

async function jget(url) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 20000);
  try {
    const r = await fetch(url, { headers: { Accept: "application/json" }, signal: ctrl.signal });
    if (!r.ok) throw new Error("HTTP " + r.status);
    return await r.json();
  } finally { clearTimeout(t); }
}

// 1) 抓已結算的二元市場（分頁）
async function resolvedMarkets(n) {
  const out = [];
  let offset = 0;
  while (out.length < n) {
    const d = await jget(GAMMA + `/markets?closed=true&order=volumeNum&ascending=false&limit=100&offset=${offset}`);
    const arr = Array.isArray(d) ? d : [];
    if (!arr.length) break;
    for (const m of arr) {
      let toks = m.clobTokenIds;
      if (typeof toks === "string") { try { toks = JSON.parse(toks); } catch (e) { toks = null; } }
      // 需要：兩個token、明確結算價（outcomePrices 如 ["1","0"]）、結束時間
      let op = m.outcomePrices;
      if (typeof op === "string") { try { op = JSON.parse(op); } catch (e) { op = null; } }
      if (Array.isArray(toks) && toks.length === 2 && Array.isArray(op) && op.length === 2 && m.endDate) {
        const yesWon = parseFloat(op[0]) > 0.5 ? 1 : (parseFloat(op[1]) > 0.5 ? 0 : null);
        if (yesWon === null) continue; // 非 0/1 結算（取消/分割）跳過
        out.push({ q: (m.question || "").slice(0, 60), yesTok: toks[0], end: Date.parse(m.endDate), yesWon, vol: m.volumeNum || 0 });
      }
      if (out.length >= n) break;
    }
    offset += 100;
    await new Promise(r => setTimeout(r, 400));
  }
  return out;
}

// 2) 取該市場 YES token 在「結算前48h」附近的價格
async function priceBefore(tokenId, endMs) {
  try {
    const startTs = Math.floor((endMs - 72 * 36e5) / 1000);
    const endTs = Math.floor((endMs - 24 * 36e5) / 1000);
    const d = await jget(CLOB + `/prices-history?market=${tokenId}&startTs=${startTs}&endTs=${endTs}&fidelity=60`);
    const h = (d && d.history) || [];
    if (!h.length) return null;
    // 取窗口中間的價格（避免結算前最後時刻已收斂）
    const mid = h[Math.floor(h.length / 2)];
    const p = parseFloat(mid && mid.p);
    return isFinite(p) && p > 0 && p < 1 ? p : null;
  } catch (e) { return null; }
}

const cache = fs.existsSync(CACHE) ? JSON.parse(fs.readFileSync(CACHE, "utf8")) : {};

console.log(`抓取已結算市場（目標 ${MAX_N} 個）…`);
const mkts = await resolvedMarkets(MAX_N);
console.log(`取得 ${mkts.length} 個，開始回取結算前48h價格…`);

const samples = [];
let i = 0;
for (const m of mkts) {
  process.stdout.write(`\r${++i}/${mkts.length}`);
  const key = m.yesTok + ":" + m.end;
  let p = cache[key];
  if (p === undefined) {
    p = await priceBefore(m.yesTok, m.end);
    cache[key] = p;
    if (i % 5 === 0) { fs.writeFileSync(CACHE, JSON.stringify(cache)); await new Promise(r => setTimeout(r, 600)); }
  }
  if (p != null) samples.push({ p, won: m.yesWon });
}
fs.writeFileSync(CACHE, JSON.stringify(cache));
console.log(`\n有效樣本 ${samples.length} 個\n`);

// 3) 分桶：隱含機率 vs 真實勝率
const buckets = [[0.02, 0.15], [0.15, 0.35], [0.35, 0.65], [0.65, 0.85], [0.85, 0.98]];
console.log("═══ 熱門低估偏差回測（結算前~48h價格）═══");
console.log("價格桶      | 樣本 | 隱含勝率 | 真實勝率 | 偏差 | 買YES期望值");
for (const [lo, hi] of buckets) {
  const g = samples.filter(s => s.p >= lo && s.p < hi);
  if (g.length < 5) { console.log(`${lo.toFixed(2)}–${hi.toFixed(2)} | 樣本不足(${g.length})`); continue; }
  const implied = g.reduce((a, s) => a + s.p, 0) / g.length;
  const real = g.filter(s => s.won).length / g.length;
  const bias = real - implied;
  // 期望值：買YES花 implied，贏拿 $1 → EV = real - implied（每$1成本的淨報酬率再除implied）
  const evPct = (real - implied) / implied * 100;
  console.log(`${lo.toFixed(2)}–${hi.toFixed(2)} | ${String(g.length).padStart(4)} | ${(implied * 100).toFixed(1)}%   | ${(real * 100).toFixed(1)}%   | ${bias >= 0 ? "+" : ""}${(bias * 100).toFixed(1)}pp | ${evPct >= 0 ? "+" : ""}${evPct.toFixed(1)}%`);
}
console.log("\n判讀：");
console.log("· 0.85–0.98 桶偏差為正 → 熱門被低估成立，系統性買熱門有邊際");
console.log("· 0.02–0.15 桶偏差為負 → 冷門被高估成立（彩票溢價），避開低價彩票");
console.log("· 兩者都不顯著 → Polymarket 定價有效率，此策略無肉，轉攻套利掃描的數據");
