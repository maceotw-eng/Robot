# -*- coding: utf-8 -*-
"""策略 D 影子監測器（影子模擬期 90 天，規格照 D_preregistration.md §4）
用法：
  python shadow_D.py update    # 從期交所抓最新日資料（免費、永續）並更新資料倉
  python shadow_D.py signal    # 產生今晚訊號（13:40 前跑）：進場/停做＋推播文字，寫入 shadow_log
  python shadow_D.py record 2026-07-28 --entry 42650 --exit 42710 [--note "..."]
                               # 回填實際成交，自動算滑價與損益（微台 NT$10/點）
資料源：TAIFEX futDataDown（免費）；FinMind 到期不影響。"""
import urllib.request, urllib.parse, json, os, sys, io, csv, datetime, math
import statistics as st

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
BASE = os.path.dirname(os.path.abspath(__file__))
TXD = os.path.join(BASE, "data", "tx_daily.json")
LOG = os.path.join(BASE, "results", "shadow_log.csv")
POINT_NTD = 10  # 微台每點

def push(msg):
    """Telegram 推播（設環境變數 TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID 即啟用；未設則僅印出）"""
    tok = os.environ.get("TELEGRAM_BOT_TOKEN"); chat = os.environ.get("TELEGRAM_CHAT_ID")
    if not tok or not chat: return
    try:
        url = "https://api.telegram.org/bot%s/sendMessage" % tok
        data = urllib.parse.urlencode(dict(chat_id=chat, text=msg)).encode()
        urllib.request.urlopen(urllib.request.Request(url, data=data), timeout=30)
    except Exception as e:
        print("push failed:", e)

def taifex_fetch(d0, d1):
    url = "https://www.taifex.com.tw/cht/3/futDataDown"
    data = urllib.parse.urlencode(dict(down_type=1, commodity_id="TX",
        queryStartDate=d0.strftime("%Y/%m/%d"), queryEndDate=d1.strftime("%Y/%m/%d"))).encode()
    req = urllib.request.Request(url, data=data, headers={"User-Agent": "Mozilla/5.0"})
    txt = urllib.request.urlopen(req, timeout=60).read().decode("big5", "replace")
    out = []
    for ln in txt.strip().splitlines()[1:]:
        p = [x.strip() for x in ln.split(",")]
        if len(p) < 18 or p[1] != "TX": continue
        cd = p[2].replace(" ", "")
        if "/" in cd: continue
        def num(x):
            try: return float(x)
            except Exception: return None
        sess = "position" if p[17] == "一般" else "after_market"
        d = p[0].replace("/", "-")
        out.append([d, cd, num(p[3]), num(p[4]), num(p[5]), num(p[6]),
                    int(float(p[9])) if num(p[9]) is not None else 0,
                    num(p[10]), int(float(p[11])) if num(p[11]) is not None else None, sess])
    return out

def cmd_update():
    rows = json.load(open(TXD))
    have = {(r[0], r[1], r[9]) for r in rows}
    today = datetime.date.today()
    new = [r for r in taifex_fetch(today - datetime.timedelta(days=14), today)
           if (r[0], r[1], r[9]) not in have]
    rows += new
    rows.sort(key=lambda r: (r[0], r[1]))
    json.dump(rows, open(TXD, "w"))
    print("更新完成：新增 %d 列，資料至 %s" % (len(new), max(r[0] for r in rows)))

def build_state():
    import engine_D as D
    nights, cont_ret, levels, dates = D.build_nights()
    ma_ok, vol_ok, fomc = D.build_filters(cont_ret, levels, dates)
    return dates, levels, ma_ok, vol_ok

HDR = ["date", "data_date", "signal", "ma_pass", "vol_pass", "front",
       "prev_close", "ref_entry", "ref_exit", "fill_entry", "fill_exit",
       "slip_entry_pts", "slip_exit_pts", "pnl_pts", "pnl_ntd", "note"]
# 欄位語義（務必與判定方向一致，勿再命名為 filter_*）：
#   date       進場日＝執行本指令的當日（13:44 下單）
#   data_date  濾網所用日盤資料的最後一日。cron 在 13:40 執行，當日 13:45 才收盤，
#              期交所日盤檔更晚才發布 → 實盤必然只有「前一交易日」可用。
#              ⚠ 回測用「進場日收盤」評濾網，與此差一天；實測決策不一致 3.48%，
#                驗證段年化 20.7%→19.2%、t 4.19→3.82、MDD −12.18%→−15.44%。
#                data_date 欄位存在的目的就是讓這個落差可稽核。
#   ma_pass    True＝收在 200DMA 之上＝濾網通過＝可做
#   vol_pass   True＝20 日已實現波動 ≤ 自身 252 日 80 分位＝濾網通過＝可做
#              任一為 False 或 None（算不出來）→ SKIP（fail-closed）
#   prev_close data_date 當日的前月收盤（下單前唯一已知的參考價）
#   ref_entry  進場日的實際收盤（隔日資料發布後由 record 回填，才是滑價的正確基準）
STALE_DAYS = 4


def _d(s): return datetime.date(*map(int, s.split("-")))


def cmd_signal():
    rows = json.load(open(TXD))
    dates, levels, ma_ok, vol_ok = build_state()
    d_data = dates[-1]
    d_entry = datetime.date.today().isoformat()
    # ① 資料斷線防護（不是「必須等於今日」——13:40 本來就拿不到今日日盤）
    age = (_d(d_entry) - _d(d_data)).days
    if age > STALE_DAYS:
        msg = "⛔ D 無法發訊號：日盤資料已 %d 天未更新（最後 %s）。請檢查 update 是否失敗。" % (age, d_data)
        print(msg); push(msg); return
    # ② 冪等：同一進場日不重複寫入
    if os.path.exists(LOG):
        for r in list(csv.reader(open(LOG, encoding="utf-8-sig")))[1:]:
            if r and r[0] == d_entry:
                print("⚠ %s 已有紀錄（%s），不重複寫入。" % (d_entry, r[2] if len(r) > 2 else "?")); return
    byc = {r[1]: r for r in rows if r[0] == d_data and r[9] == "position"}
    front = max(byc, key=lambda k: byc[k][6])
    prev_close = byc[front][5]
    ok_a = ma_ok.get(d_data); ok_b = vol_ok.get(d_data)
    # ③ fail-closed：只有兩個濾網都明確通過才進場
    go = (ok_a is True) and (ok_b is True)
    if go:
        msg = ("🟢 D 訊號【進場】%s：13:44 市價買 微台 %s 一口｜明日 08:46 市價平倉\n"
               "   濾網依據 %s 收盤 %s（實盤時點，與回測差一天）" % (d_entry, front, d_data, prev_close))
    else:
        why = []
        if ok_a is False: why.append("200DMA 下")
        elif ok_a is None: why.append("200DMA 算不出（資料不足）")
        if ok_b is False: why.append("波動>80分位")
        elif ok_b is None: why.append("波動分位算不出（資料不足）")
        msg = "⚪ D 訊號【停做】%s：%s（依據 %s）" % (d_entry, "＋".join(why), d_data)
    print(msg)
    push(msg)
    exists = os.path.exists(LOG)
    with open(LOG, "a", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        if not exists: w.writerow(HDR)
        w.writerow([d_entry, d_data, "GO" if go else "SKIP", ok_a, ok_b, front,
                    prev_close, "", "", "", "", "", "", "", "", ""])
    print("已寫入 shadow_log.csv（進場日 %s，濾網依據 %s）" % (d_entry, d_data))

def cmd_record(argv):
    d = argv[0]
    kv = dict(zip(argv[1::2], argv[2::2]))
    entry = float(kv.get("--entry")); exitp = float(kv.get("--exit"))
    note = kv.get("--note", "")
    rows = list(csv.reader(open(LOG, encoding="utf-8-sig")))
    hdr, body = rows[0], [r for r in rows[1:] if r]
    tx = json.load(open(TXD))
    hit = False
    for r in body:
        if r[0] != d or r[2] != "GO": continue
        hit = True
        front = r[5]
        # 滑價基準：進場日「當日」收盤（13:45），須待期交所發布後才有 → 由此回填。
        # 舊版誤用前一日收盤當基準，會把一整夜的價格變動算成滑價。
        ref_e = ""
        for x in tx:
            if x[0] == d and x[1] == front and x[9] == "position": ref_e = x[5]
        nxt = sorted({x[0] for x in tx if x[0] > d and x[9] == "position"})
        ref_x = ""
        if nxt:
            for x in tx:
                if x[0] == nxt[0] and x[1] == front and x[9] == "position": ref_x = x[2]
        se = (entry - float(ref_e)) if ref_e != "" else ""
        sx = (float(ref_x) - exitp) if ref_x != "" else ""
        pnl = exitp - entry
        r[7], r[8] = ref_e, ref_x
        r[9], r[10] = entry, exitp
        r[11] = ("%.1f" % se) if se != "" else ""
        r[12] = ("%.1f" % sx) if sx != "" else ""
        r[13], r[14], r[15] = "%.1f" % pnl, "%.0f" % (pnl * POINT_NTD), note
        print("已記錄 %s：進場滑價 %s 點／出場滑價 %s 點，損益 %+.1f 點（NT$%+.0f）" % (
            d, r[11] or "無基準", r[12] or "無基準", pnl, pnl * POINT_NTD))
    if not hit:
        print("⚠ 找不到 %s 的 GO 紀錄，未寫入。" % d); return
    with open(LOG, "w", newline="", encoding="utf-8-sig") as f:
        csv.writer(f).writerows([hdr] + body)

def cmd_report():
    body = [r for r in list(csv.reader(open(LOG, encoding="utf-8-sig")))[1:] if r]
    slips = [float(r[11]) for r in body if len(r) > 11 and r[11] not in ("", None)]
    if slips:
        print("影子期進場滑價：n=%d 中位=%.1f點 平均=%.1f點（G 解凍參考線=1 tick=1點）" % (
            len(slips), sorted(slips)[len(slips)//2], st.mean(slips)))
    pnls = [float(r[13]) for r in body if len(r) > 13 and r[13] not in ("", None)]
    if pnls:
        print("已結案 %d 筆：合計 %+.1f 點（NT$%+.0f）｜最差 %+.1f 點｜勝率 %.0f%%" % (
            len(pnls), sum(pnls), sum(pnls) * POINT_NTD, min(pnls),
            100.0 * sum(1 for x in pnls if x > 0) / len(pnls)))
    gos = sum(1 for r in body if len(r) > 2 and r[2] == "GO")
    print("GO %d / SKIP %d" % (gos, len(body) - gos))
    lag = {r[1] for r in body if len(r) > 1 and r[1] and r[1] != r[0]}
    if lag: print("提醒：所有訊號之濾網皆依前一交易日資料（實盤時點），與回測差一天。")

def cmd_morning():
    """早盤提醒：若最近一筆 GO 尚未回填成交 → 推播 08:46 平倉提醒"""
    if not os.path.exists(LOG): return
    body = [r for r in list(csv.reader(open(LOG, encoding="utf-8-sig")))[1:] if r]
    if not body: return
    last = body[-1]
    if len(last) < 10 or last[2] != "GO" or last[9]:
        print("今晨無持倉"); return
    # 過期防護：GO 距今超過 STALE_DAYS 仍未回填 → 提醒補登，而非提醒平倉。
    # 否則一筆陳舊的 GO 會每天提醒平倉一個早已不存在的部位。
    age = (datetime.date.today() - _d(last[0])).days
    if age > STALE_DAYS:
        msg = "⚠ D 未結案警示：%s 的 GO 已 %d 天未回填成交，請用 record 補登或標註未成交。" % (last[0], age)
        print(msg); push(msg); return
    msg = "⏰ D 平倉提醒：%s 進場的微台 %s，今日 08:46 市價平倉，成交後回填 record" % (
        last[0], last[5])
    print(msg); push(msg)

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "signal"
    if cmd == "update": cmd_update()
    elif cmd == "signal": cmd_signal()
    elif cmd == "record": cmd_record(sys.argv[2:])
    elif cmd == "report": cmd_report()
    elif cmd == "morning": cmd_morning()
    else: print(__doc__)
