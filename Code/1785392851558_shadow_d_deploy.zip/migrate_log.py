# -*- coding: utf-8 -*-
"""shadow_log.csv 舊→新結構遷移
舊：date,signal,(filter|ma)_ma,(filter|vol)_vol,front,ref_entry,ref_exit,fill_entry,
    fill_exit,slip_entry,slip_exit,pnl_pts,pnl_ntd,note                    (14 欄)
新：date,data_date,signal,ma_pass,vol_pass,front,prev_close,ref_entry,ref_exit,
    fill_entry,fill_exit,slip_entry,slip_exit,pnl_pts,pnl_ntd,note         (16 欄)

⚠ 語義變更（無法自動判定，需人工確認）：
   舊版 date 欄寫的是 dates[-1]（濾網所用資料的最後一日），不是實際進場日。
   新版 date = 進場日、data_date = 濾網資料日。
   本腳本預設把舊 date 同時填入兩欄，並在 note 標註「進場日待確認」，
   不擅自改動日期。請對照推播訊息與實際下單日自行修正 date 欄。
"""
import csv, sys, os, shutil
LOG = sys.argv[1] if len(sys.argv) > 1 else os.path.join("results", "shadow_log.csv")
NEW = ["date","data_date","signal","ma_pass","vol_pass","front","prev_close",
       "ref_entry","ref_exit","fill_entry","fill_exit","slip_entry_pts",
       "slip_exit_pts","pnl_pts","pnl_ntd","note"]
rows = [r for r in csv.reader(open(LOG, encoding="utf-8-sig")) if r]
hdr, body = rows[0], rows[1:]
if hdr == NEW:
    print("已是新結構，不需遷移。"); raise SystemExit
if len(hdr) != 14:
    print("表頭欄數 %d，非預期的舊結構（14），請人工檢視。" % len(hdr)); raise SystemExit(1)
shutil.copy(LOG, LOG + ".bak")
out = []
for r in body:
    r = (r + [""] * 14)[:14]
    tag = "遷移自舊結構；進場日待確認（舊 date 欄實為濾網資料日）"
    out.append([r[0], r[0], r[1], r[2], r[3], r[4], r[5],
                "", r[6], r[7], r[8], r[9], r[10], r[11], r[12],
                (r[13] + "｜" if r[13] else "") + tag])
with open(LOG, "w", newline="", encoding="utf-8-sig") as f:
    csv.writer(f).writerows([NEW] + out)
print("遷移完成：%d 筆。備份 %s.bak" % (len(out), LOG))
print("⚠ 請人工核對 date 欄（實際下單日）與 data_date 欄（濾網資料日）。")
