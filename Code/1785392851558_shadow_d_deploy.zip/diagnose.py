# -*- coding: utf-8 -*-
"""VPS 現況診斷（唯讀，不修改任何檔案）。輸出貼回給我即可。"""
import os, csv, json, sys, datetime, subprocess
try: sys.stdout.reconfigure(encoding="utf-8")
except Exception: pass
B = os.path.dirname(os.path.abspath(__file__))
print("=== 主機時間 ===")
print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "  TZ:", os.environ.get("TZ", "(未設)"))
try: print(subprocess.run(["date"], capture_output=True, text=True).stdout.strip())
except Exception: pass
print("\n=== crontab ===")
try: print(subprocess.run(["crontab", "-l"], capture_output=True, text=True).stdout or "(空)")
except Exception as e: print("讀不到:", e)
print("=== 檔案版本 ===")
for f in ("shadow_D.py", "engine_D.py"):
    p = os.path.join(B, f)
    if os.path.exists(p):
        s = open(p, encoding="utf-8").read()
        print("  %-14s %6d bytes  mtime %s  含data_date=%s  fail-closed=%s" % (
            f, len(s), datetime.datetime.fromtimestamp(os.path.getmtime(p)).strftime("%Y-%m-%d %H:%M"),
            "data_date" in s, "is not True" in s or "is True) and" in s))
print("\n=== 資料倉 ===")
p = os.path.join(B, "data", "tx_daily.json")
if os.path.exists(p):
    r = json.load(open(p))
    ds = sorted({x[0] for x in r if x[9] == "position"})
    print("  tx_daily.json  %d 列  日盤最後日 %s  mtime %s" % (
        len(r), ds[-1], datetime.datetime.fromtimestamp(os.path.getmtime(p)).strftime("%Y-%m-%d %H:%M")))
print("\n=== shadow_log.csv 全文 ===")
p = os.path.join(B, "results", "shadow_log.csv")
if not os.path.exists(p): print("  (不存在)")
else:
    print("  mtime", datetime.datetime.fromtimestamp(os.path.getmtime(p)).strftime("%Y-%m-%d %H:%M"))
    for i, ln in enumerate(open(p, encoding="utf-8-sig")):
        print("  %2d| %s" % (i, ln.rstrip()))
