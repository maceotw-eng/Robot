# D 影子監測器部署包（策略 D：台指隔夜偏移，濾網版凍結規格）

自足包，四個檔案跑天下，**純 Python 標準庫、零 pip 依賴**（Python 3.6+）：
```
shadow_D.py          # 主程式（update/signal/record/report/morning 五指令）
engine_D.py          # 連續合約與濾網計算（被 shadow_D 引用）
data/tx_daily.json   # TX 日資料倉 1998~今（update 會自動增量）
data/fomc_dates.json # FOMC 日期（engine 引用）
results/             # shadow_log.csv 會生在這
```
資料源＝期交所免費端點（futDataDown），無 API key、無訂閱依賴。

## VPS 部署三步

**1. 上 git（在你的電腦）**
```bash
cd Robot   # 你的 repo
mkdir shadow-d && cp -r <此資料夾>/* shadow-d/
git add shadow-d && git commit -m "D shadow monitor" && git push
```

**2. VPS 拉下來＋設 Telegram 推播**
```bash
git clone <你的repo> && cd Robot/shadow-d
# Telegram：跟 BotFather 建 bot 拿 token，跟 bot 說句話後
# 用 https://api.telegram.org/bot<TOKEN>/getUpdates 查你的 chat_id
```

**3. crontab -e（時區務必指定台北）**
```cron
CRON_TZ=Asia/Taipei
TELEGRAM_BOT_TOKEN=xxxx
TELEGRAM_CHAT_ID=yyyy
# 平日 13:40 更新資料＋產生今晚訊號（GO/SKIP 推播）
40 13 * * 1-5 cd /path/Robot/shadow-d && python3 shadow_D.py update && python3 shadow_D.py signal
# 平日 08:40 若有持倉推平倉提醒
40 8 * * 1-5 cd /path/Robot/shadow-d && python3 shadow_D.py morning
```
（舊版 cron 無 CRON_TZ 就把時間自己換算成 VPS 時區，或 `TZ=Asia/Taipei` 放最上面。）

## ⚠ 已知落差：濾網時點（2026-07-30 修正時記錄）

cron 在 **13:40** 執行，當日日盤 **13:45** 才收盤，期交所日盤檔更晚才發布。
**實盤必然只能用「前一交易日」收盤評濾網**，而回測用的是「進場日收盤」。

實測差異（配置 ab、基準成本）：

| 段 | 濾網時點 | 年化 | t | MDD |
|---|---|---:|---:|---:|
| 驗證段 | 回測（進場日收盤） | 20.7% | 4.19 | −12.18% |
| 驗證段 | **實盤（前一日收盤）** | **19.2%** | **3.82** | **−15.44%** |
| 開發段 | 回測 | 8.5% | 3.02 | −19.25% |
| 開發段 | **實盤** | **7.4%** | **2.57** | **−20.05%** |

決策不一致 **3.48%**（218/6273 夜）。放行門檻 1–3 仍過（19.2%≥6%、3.82≥2、−4.31%≤5%），
**門檻 4「風險對齊後不劣於稀釋 B&H」原本即未過，實盤時點只會更差。**

日誌新增 `data_date` 欄即為稽核此落差而設。**這是待辦第 2 項「濾網即時盤後一致率」的答案，
不是新發現的 bug，但實盤數字應以 19.2% 版本為準，不是 20.7%。**

## 日常
- 🟢 GO 推播 → 13:44 下單微台一口 → 次晨 08:46 平倉 → SSH 回填：
  `python3 shadow_D.py record 2026-07-28 --entry 42650 --exit 42710`
  （`date` 填**實際下單日**。滑價基準 `ref_entry` 為該日收盤，須待期交所發布後才有，
  由 record 自動查填；舊版誤用前一日收盤當基準，會把整夜價格變動算成滑價。）
- ⚪ SKIP → 休息
- **週五照凍結版執行（該 GO 就 GO）**——變體考場需要凍結版的週五實測，提前跳過會污染數據（紅隊裁定 2026-07-26）
- 隨時 `python3 shadow_D.py report` 看滑價中位統計
- 90 天後開庭三案並審：滑價 vs 2tick 壓力假設／濾網即時盤後一致率／週五變體（同族 ×1.1）

## 規格出處
凍結文件：D_preregistration.md（sha256:bc41986e）｜驗證報告：D_validation_report.md
規則一句話：每日 13:44 買微台前月、次晨 08:46 平；指數 < 200DMA 或 20日波動 > 自身252日80分位 → 當夜停做。
