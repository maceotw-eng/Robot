# -*- coding: utf-8 -*-
"""策略 D 消融引擎 — 依 D_preregistration.md 凍結文件
輸出開發段 8 組（base/a/b/c/ab/ac/bc/abc）× 2 成本版的
年化/t/P1/ES99/最差夜/停做夜數，與「交換比」表。"""
import json, os, math, sys, io
from collections import defaultdict
import statistics as st

BASE = os.path.dirname(os.path.abspath(__file__))
DEV = ("2001-01-01", "2018-12-31")
VAL = ("2019-01-01", "2026-06-30")
UNLOCK_VALIDATION = False

def build_nights():
    rows = json.load(open(os.path.join(BASE, "data", "tx_daily.json")))
    byd = {}
    for d, cd, o, h, l, c, v, sp, oi, sess in rows:
        if sess != "position" or "/" in str(cd) or not o or not c: continue
        byd.setdefault(d, {})[str(cd)] = (o, c, v or 0)
    dates = sorted(byd)
    nights = []          # (entry_date, overnight_ret_gross)
    cont_ret = []        # 連續日報酬(收收) 供濾網
    prev_close = {}; prev_vol = {}
    lvl = 100.0; levels = {}; d_prev = None
    for d in dates:
        cmap = byd[d]
        # 接續合約＝「昨日與今日都有交易」者之中，昨日成交量最大的一口。
        # 完全由昨日資料決定 → 無前視；且換月日（舊前月到期消失）會自動接到
        # 新前月，不再像舊版那樣整天跳過 —— 舊版在 124 個結算日產生 cont_ret
        # 缺口，使 vol_ok 沒有該日 key，配合 `is False` 判定形成 fail-open。
        cands = [k for k in cmap if k in prev_close and k in prev_vol]
        use = max(cands, key=lambda k: prev_vol[k]) if cands else None
        if use and d_prev:
            o, c, _ = cmap[use]
            pc = prev_close[use]
            nights.append([d_prev, o / pc - 1])          # 進場日=前一日
            r_cc = c / pc - 1
            cont_ret.append((d, r_cc)); lvl *= (1 + r_cc)
        levels[d] = lvl
        prev_close = {k: v[1] for k, v in cmap.items()}
        prev_vol = {k: v[2] for k, v in cmap.items()}
        d_prev = d
    return nights, cont_ret, levels, dates

def build_filters(cont_ret, levels, dates):
    # (a) 200DMA
    lv = [levels[d] for d in dates]
    ma_ok = {}
    for i, d in enumerate(dates):
        if i >= 200:
            ma = sum(lv[i - 199:i + 1]) / 200
            ma_ok[d] = lv[i] >= ma
    # (b) 20日已實現波動 > 自身252日80分位
    rd = [r for _, r in cont_ret]; rdd = [d for d, _ in cont_ret]
    vol20 = {}
    vals = []
    vol_ok = {}
    for i in range(len(rd)):
        if i >= 20:
            v = st.pstdev(rd[i - 19:i + 1])
            vol20[rdd[i]] = v; vals.append(v)
            if len(vals) > 252:
                hist = sorted(vals[-253:-1])
                thr = hist[int(0.8 * len(hist))]
                vol_ok[rdd[i]] = v <= thr
    fomc = set(json.load(open(os.path.join(BASE, "data", "fomc_dates.json"))))
    return ma_ok, vol_ok, fomc

def run(seg, cost, config, data):
    nights, ma_ok, vol_ok, fomc = data
    lo, hi = seg
    if hi > DEV[1] and not UNLOCK_VALIDATION:
        raise SystemExit("段別鎖：驗證段未解鎖。")
    taken, skipped = [], 0
    for d, r in nights:
        if not (lo <= d <= hi): continue
        # fail-closed：濾網算不出來（None）時一律停做，不得預設通過。
        if "a" in config and ma_ok.get(d) is not True: skipped += 1; continue
        if "b" in config and vol_ok.get(d) is not True: skipped += 1; continue
        if "c" in config and d in fomc: skipped += 1; continue
        taken.append(r - cost)
    return taken, skipped

def stats(rs):
    n = len(rs)
    if not n: return {}
    m = st.mean(rs); s = st.pstdev(rs)
    srt = sorted(rs)
    es99 = st.mean(srt[:max(1, int(0.01 * n))])
    return dict(n=n, ann=m * 240, t=m / (s / math.sqrt(n)) if s else 0,
                p1=srt[int(0.01 * n)], es99=es99, worst=srt[0],
                win=sum(1 for x in rs if x > 0) / n)

if __name__ == "__main__":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    nights, cont_ret, levels, dates = build_nights()
    ma_ok, vol_ok, fomc = build_filters(cont_ret, levels, dates)
    data = (nights, ma_ok, vol_ok, fomc)
    for cost, tag in ((0.00012, "基準0.012%"), (0.00024, "壓力0.024%")):
        print("\n==== 成本 %s ｜開發段 2001-2018 ====" % tag)
        base_s = None
        print("%-6s %6s %7s %6s %8s %8s %8s %7s %s" % ("組", "n", "年化", "t", "P1", "ES99", "最差夜", "停做", "交換比(棄年化pp/ES99改善pp)"))
        for cfg in ("", "a", "b", "c", "ab", "ac", "bc", "abc"):
            rs, sk = run(DEV, cost, cfg, data)
            s = stats(rs)
            if cfg == "": base_s = s
            tr = ""
            if cfg and base_s:
                give = (base_s["ann"] - s["ann"]) * 100
                gain = (s["es99"] - base_s["es99"]) * 100
                tr = "%.2f / %.2f" % (give, gain)
            print("%-6s %6d %6.1f%% %6.2f %7.2f%% %7.2f%% %7.2f%% %7d %s" % (
                cfg or "base", s["n"], 100 * s["ann"], s["t"],
                100 * s["p1"], 100 * s["es99"], 100 * s["worst"], sk, tr))
