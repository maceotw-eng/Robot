# -*- coding: utf-8 -*-
"""dashboard.py — 產出單檔靜態儀表板 dashboard.html(內嵌資料,零後端)
可 scp 回本機看、丟 GitHub Pages、或 VPS 上 python -m http.server 供瀏覽。
"""
from __future__ import annotations

import json
import os
from datetime import datetime

import pandas as pd

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "dashboard.html")

TPL = """<!DOCTYPE html><html lang="zh-Hant"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>TXO 雷達儀表板</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.4/chart.umd.min.js"></script>
<style>
:root{--paper:#EDF0F2;--ink:#182430;--soft:#5A6B7A;--card:#FAFBFC;--line:#C9D2D9;
--up:#C0392B;--dn:#1E8060;--mono:ui-monospace,Consolas,monospace}
*{box-sizing:border-box;margin:0}body{font-family:"Noto Sans TC",system-ui,sans-serif;
background:var(--paper);color:var(--ink);padding:20px 14px 60px}
.wrap{max-width:900px;margin:0 auto}h1{font-size:22px;border-bottom:3px solid var(--ink);
padding-bottom:10px;margin-bottom:6px}.sub{color:var(--soft);font-size:12px;
font-family:var(--mono);margin-bottom:18px}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:18px}
.card{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:12px}
.card .k{font-size:11px;color:var(--soft)}.card .v{font-family:var(--mono);font-size:19px;font-weight:700;margin-top:4px}
.v.up{color:var(--up)}.v.dn{color:var(--dn)}
section{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:16px;margin-bottom:16px}
section h2{font-size:13px;letter-spacing:.12em;color:var(--soft);margin-bottom:10px}
table{width:100%;border-collapse:collapse;font-size:12.5px}
th{font-size:10.5px;color:var(--soft);text-align:right;border-bottom:2px solid var(--ink);padding:5px 6px}
th:first-child,td:first-child{text-align:left}
td{font-family:var(--mono);text-align:right;padding:5px 6px;border-bottom:1px solid #E3E8EC}
td.up{color:var(--up);font-weight:700}td.dn{color:var(--dn);font-weight:700}
.note{font-size:11.5px;color:var(--soft);line-height:1.8;margin-top:8px}
</style></head><body><div class="wrap">
<h1>TXO 四策略雷達 — 紙上實測儀表板</h1>
<div class="sub">最後更新 __UPDATED__ ・ 成交假設=收盤價 ・ 紅=獲利 綠=虧損(台股語義)</div>
<div class="cards">__CARDS__</div>
<section><h2>淨值曲線(已實現+未實現,元)</h2><canvas id="nav" height="80"></canvas></section>
<section><h2>目前持倉</h2><table>__OPEN__</table></section>
<section><h2>各策略統計(已平倉)</h2><table>__STATS__</table></section>
<section><h2>最近平倉紀錄</h2><table>__TRADES__</table>
<div class="note">reason 標記:expiry_SP_approx=以到期日結算價近似 SP;stop50_approx=當日最低觸及
即以停損價計(實際成交可能更差)。本頁為<b>紙上追蹤</b>,不含真實滑價;實單成交價請回填 signals_log.csv。</div>
</section>
<script>
const NAV=__NAVJSON__;
new Chart(document.getElementById('nav'),{type:'line',data:{labels:NAV.d,
datasets:[{data:NAV.v,borderColor:'#182430',borderWidth:1.6,pointRadius:0,fill:false}]},
options:{plugins:{legend:{display:false}},scales:{x:{ticks:{maxTicksLimit:10,font:{size:10}}},
y:{ticks:{font:{size:10}}}}}});
</script></div></body></html>"""


def _card(k, v, cls=""):
    return f'<div class="card"><div class="k">{k}</div><div class="v {cls}">{v}</div></div>'


def _cls(x):
    return "up" if x > 0 else ("dn" if x < 0 else "")


def generate() -> str:
    nav = pd.read_csv(os.path.join(BASE, "nav.csv")) if os.path.exists(
        os.path.join(BASE, "nav.csv")) else pd.DataFrame(
        columns=["date", "realized_cum", "unrealized", "nav", "open_positions"])
    trades = pd.read_csv(os.path.join(BASE, "trades.csv")) if os.path.exists(
        os.path.join(BASE, "trades.csv")) else pd.DataFrame(
        columns=["entry_date", "exit_date", "strategy", "cp", "contract", "strike",
                 "entry_px", "exit_px", "pnl_twd", "reason"])
    book = {}
    lp = os.path.join(BASE, "ledger.json")
    if os.path.exists(lp):
        book = json.load(open(lp, encoding="utf-8"))

    cur_nav = float(nav["nav"].iloc[-1]) if len(nav) else 0.0
    realized = float(trades["pnl_twd"].sum()) if len(trades) else 0.0
    n_tr = len(trades)
    hit = (trades["pnl_twd"] > 0).mean() * 100 if n_tr else 0
    dd = 0.0
    if len(nav):
        eq = nav["nav"]
        dd = float((eq - eq.cummax()).min())
    cards = (_card("紙上淨值(元)", f"{cur_nav:+,.0f}", _cls(cur_nav))
             + _card("已實現(元)", f"{realized:+,.0f}", _cls(realized))
             + _card("已平倉筆數", n_tr)
             + _card("勝率", f"{hit:.0f}%")
             + _card("最大回撤(元)", f"{dd:,.0f}", "dn" if dd < 0 else "")
             + _card("持倉數", len(book)))

    open_rows = "<tr><th>策略</th><th>CP</th><th>契約</th><th>履約價</th><th>成本</th><th>現值</th><th>浮動(元)</th></tr>"
    for s, p in book.items():
        fl = (p["last_px"] - p["entry_px"]) * 50
        open_rows += (f"<tr><td>{s}</td><td>{p['cp']}</td><td>{p['contract_date']}</td>"
                      f"<td>{p['strike']:.0f}</td><td>{p['entry_px']:.1f}</td>"
                      f"<td>{p['last_px']:.1f}</td><td class='{_cls(fl)}'>{fl:+,.0f}</td></tr>")
    if not book:
        open_rows += "<tr><td colspan=7>空手</td></tr>"

    stat_rows = "<tr><th>策略</th><th>筆數</th><th>勝率</th><th>平均(元)</th><th>合計(元)</th></tr>"
    if n_tr:
        for s, g in trades.groupby("strategy"):
            tot = g["pnl_twd"].sum()
            stat_rows += (f"<tr><td>{s}</td><td>{len(g)}</td>"
                          f"<td>{(g['pnl_twd']>0).mean()*100:.0f}%</td>"
                          f"<td class='{_cls(g['pnl_twd'].mean())}'>{g['pnl_twd'].mean():+,.0f}</td>"
                          f"<td class='{_cls(tot)}'>{tot:+,.0f}</td></tr>")
    else:
        stat_rows += "<tr><td colspan=5>尚無平倉紀錄</td></tr>"

    tr_rows = "<tr><th>進場</th><th>出場</th><th>策略</th><th>契約</th><th>K</th><th>進</th><th>出</th><th>損益</th><th>原因</th></tr>"
    for _, r in trades.tail(15).iloc[::-1].iterrows():
        tr_rows += (f"<tr><td>{r['entry_date']}</td><td>{r['exit_date']}</td><td>{r['strategy']}</td>"
                    f"<td>{r['contract']}</td><td>{r['strike']:.0f}</td><td>{r['entry_px']:.1f}</td>"
                    f"<td>{r['exit_px']:.1f}</td><td class='{_cls(r['pnl_twd'])}'>{r['pnl_twd']:+,.0f}</td>"
                    f"<td>{r['reason']}</td></tr>")
    if not n_tr:
        tr_rows += "<tr><td colspan=9>—</td></tr>"

    navjson = json.dumps({"d": nav["date"].tolist(), "v": nav["nav"].tolist()})
    html = (TPL.replace("__UPDATED__", datetime.now().strftime("%Y-%m-%d %H:%M"))
            .replace("__CARDS__", cards).replace("__OPEN__", open_rows)
            .replace("__STATS__", stat_rows).replace("__TRADES__", tr_rows)
            .replace("__NAVJSON__", navjson))
    with open(OUT, "w", encoding="utf-8") as f:
        f.write(html)
    return OUT
