# -*- coding: utf-8 -*-
"""ledger.py — 全自動紙上帳本:依凍結規格自動開倉/出場/逐日結算

出場規則(凍結版):
  S1: 抱到期,以到期日該契約 settlement/close 結算(SP 近似,已標記)
  S2: 滿 10 日曆天以當日收盤平倉,或先到期
  S3: 滿 7 日曆天平倉 / 到期 / 盤中 −50%(用當日最低價近似,成交按 −50% 計,標記 approx)
  S4: 滿 18 日曆天平倉 / 到期 / 盤中 −50%(同上)

檔案: ledger.json(持倉) trades.csv(已平倉) nav.csv(每日淨值)
成交假設: 進出場一律用當日收盤價(紙上);SP 用到期日 settlement_price 近似。
"""
from __future__ import annotations

import json
import os
from datetime import date, datetime

import pandas as pd

BASE = os.path.dirname(os.path.abspath(__file__))
LEDGER = os.path.join(BASE, "ledger.json")
TRADES = os.path.join(BASE, "trades.csv")
NAV = os.path.join(BASE, "nav.csv")
PT_VALUE = 50  # TXO 每點 50 元
HOLD_DAYS = {"S2": 10, "S3": 7, "S4": 18}
STOP_PCT = {"S3": 0.5, "S4": 0.5}


def _load() -> dict:
    if os.path.exists(LEDGER):
        with open(LEDGER, encoding="utf-8") as f:
            return json.load(f)
    return {}


def _save(d: dict):
    with open(LEDGER, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)


def _append_csv(path: str, row: dict, cols: list[str]):
    df = pd.DataFrame([row], columns=cols)
    df.to_csv(path, mode="a", header=not os.path.exists(path),
              index=False, encoding="utf-8-sig")


def _row_for(chain: pd.DataFrame, cd: str, strike: float, cp: str):
    df = chain.copy()
    m = ((df["contract_date"].astype(str) == cd)
         & (pd.to_numeric(df["strike_price"], errors="coerce") == strike)
         & (df["call_put"].astype(str).str.upper().str[0] == cp[0]))
    r = df[m]
    return None if r.empty else r.iloc[0]


def open_position(strategy: str, cp: str, contract: dict, today: date):
    book = _load()
    if strategy in book:
        return False
    book[strategy] = {"cp": cp, "contract_date": contract["contract_date"],
                      "strike": contract["strike"], "expiry": contract["expiry"],
                      "entry_px": contract["close"], "entry_date": today.isoformat(),
                      "last_px": contract["close"]}
    _save(book)
    return True


def daily_settle(chain: pd.DataFrame, today: date) -> list[str]:
    """逐日結算:更新市值、檢查出場條件、記已平倉單、寫 NAV。回傳訊息列。"""
    book, msgs, realized_today = _load(), [], 0.0
    for strat in list(book.keys()):
        p = book[strat]
        row = _row_for(chain, p["contract_date"], p["strike"], p["cp"])
        close_px = float(pd.to_numeric(row["close"], errors="coerce")) if row is not None else p["last_px"]
        low_px = float(pd.to_numeric(row.get("min"), errors="coerce")) if row is not None and "min" in row else close_px
        settle_px = float(pd.to_numeric(row.get("settlement_price"), errors="coerce")) \
            if row is not None and "settlement_price" in row else close_px
        held = (today - date.fromisoformat(p["entry_date"])).days
        expiry = date.fromisoformat(p["expiry"])
        exit_px, reason = None, ""
        # 1) −50% 盤中停損(近似:當日最低觸及即以停損價成交)
        if strat in STOP_PCT and low_px <= p["entry_px"] * STOP_PCT[strat]:
            exit_px, reason = p["entry_px"] * STOP_PCT[strat], "stop50_approx"
        # 2) 到期 SP 結算
        elif today >= expiry:
            exit_px, reason = settle_px, "expiry_SP_approx"
        # 3) 滿 N 日曆天
        elif strat in HOLD_DAYS and held >= HOLD_DAYS[strat]:
            exit_px, reason = close_px, f"hold{HOLD_DAYS[strat]}d"
        if exit_px is not None:
            pnl = (exit_px - p["entry_px"]) * PT_VALUE
            realized_today += pnl
            _append_csv(TRADES, {
                "entry_date": p["entry_date"], "exit_date": today.isoformat(),
                "strategy": strat, "cp": p["cp"], "contract": p["contract_date"],
                "strike": p["strike"], "entry_px": p["entry_px"], "exit_px": round(exit_px, 1),
                "pnl_twd": round(pnl), "reason": reason},
                ["entry_date", "exit_date", "strategy", "cp", "contract", "strike",
                 "entry_px", "exit_px", "pnl_twd", "reason"])
            msgs.append(f"平倉 {strat} {p['cp']} K{p['strike']:.0f} "
                        f"{p['entry_px']:.1f}→{exit_px:.1f} = {pnl:+,.0f} 元({reason})")
            del book[strat]
        else:
            p["last_px"] = close_px
            msgs.append(f"持有 {strat} {p['cp']} K{p['strike']:.0f} "
                        f"現值 {close_px:.1f}(成本 {p['entry_px']:.1f},第 {held} 天)")
    _save(book)
    # NAV = 累計已實現 + 未實現
    prev_realized = 0.0
    if os.path.exists(TRADES):
        prev_realized = pd.read_csv(TRADES)["pnl_twd"].sum()
    unreal = sum((p["last_px"] - p["entry_px"]) * PT_VALUE for p in book.values())
    _append_csv(NAV, {"date": today.isoformat(), "realized_cum": round(prev_realized),
                      "unrealized": round(unreal), "nav": round(prev_realized + unreal),
                      "open_positions": len(book)},
                ["date", "realized_cum", "unrealized", "nav", "open_positions"])
    return msgs
