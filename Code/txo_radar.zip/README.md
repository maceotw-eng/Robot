# TXO 四策略雷達(階段二:訊號自動化+人工執行)

用 FinMind 每日資料自動計算凍結版四策略訊號,早晚推播 Telegram,
盤後產出「理論價 vs 實際成交價」日誌 —— 即第三輪審查的卷宗。

## 部署(VPS,與 meme bot 隔離)

```bash
mkdir -p ~/txo_radar && cd ~/txo_radar        # 專案自己一個目錄
# 放入 finmind.py / strategies.py / radar.py
apt install -y python3-venv                    # 若尚未安裝
python3 -m venv venv && source venv/bin/activate
pip install pandas requests

# 環境變數(寫進 ~/.profile 或 systemd 環境檔)
export FINMIND_TOKEN="你的token"
export TG_BOT_TOKEN="你的bot token"            # 可沿用 Jimgold 的 bot
export TG_CHAT_ID="你的chat id"

# 手動測試
python radar.py morning
python radar.py evening
```

## 排程(crontab -e)

```
# 盤前簡報 08:20(台灣時間;VPS 若為 UTC 請自行 -8)
20 8 * * 1-5  cd /root/txo_radar && ./venv/bin/python radar.py morning
# 盤後稽核 20:30(等 FinMind 更新當日資料;若常撲空改 21:30 或加重試)
30 20 * * 1-5 cd /root/txo_radar && ./venv/bin/python radar.py evening
```

## 每日人工動作(這就是階段二的「手動執行」)

1. 早上看簡報:今天 13:25 該做什麼(S1/S3/S4 盤前已定;S2 看警戒線)。
2. 13:25 依單執行(或前兩個月純紙上:只記「當時看到的市場價」不下單)。
3. 晚上稽核推播後,打開 signals_log.csv 回填 actual_px(實際/紙上成交價),
   slippage_pts = actual − theory。
4. 持倉異動時同步維護 positions.json:
   `{"S1": {"cp":"CALL","strike":24000,"contract_date":"202607W4","entry_px":180,"entry_date":"2026-07-20"}}`
   平倉後把該鍵刪除。

## 誠實限制(讀完再上線)

- FinMind 是**盤後資料**:evening 的 theory_px 用選擇權**收盤價**當理論成交價,
  它與你 13:25 實際看到的價會有差 —— 這個差正是我們要量的東西之一,
  但**真正的五檔滑價要等 Shioaji(階段 2b)**。本平台先完成 80%。
- S2(大跌反彈)需今日收盤判斷:morning 只能給警戒線(跌逾3%列警戒、
  觸發線價位直接算給你),13:25 由你人工確認是否觸線。
- FinMind 期貨/選擇權資料的當日更新時間不保證,evening 撲空會推播提示,
  改天補跑即可;訊號計算全部用「昨日以前」資料,不受影響。
- 出場管理(抱到期/滿N天/50%停損)目前由 positions.json+你人工執行;
  morning 會提示持有中,但**天數到期與停損觸發的自動提醒是下一版功能**。
- 契約代碼(週別 W 的到期週三對應)按台灣期交所慣例實作;
  上線第一週請人工核對雷達挑的契約與券商畫面一致,不一致回報修正。

## 檔案

- `finmind.py` FinMind v4 客戶端(台指期近月收盤序列、TXO 每日鏈)
- `strategies.py` 凍結版訊號引擎+ATM契約挑選(規格修改須先過紅隊,禁止即興調參)
- `radar.py` 早晚班執行器+Telegram推播+日誌
- `signals_log.csv` 卷宗(自動生成):date, run, strategy, action, contract,
  strike, expiry, underlying, theory_px, **actual_px(人工回填)**, slippage_pts, note

## 🆕 全自動模式(v2)

evening 現在會**全自動**:訊號→紙上進場(收盤價)→逐日出場檢查(到期SP/滿N天/−50%停損)
→trades.csv/nav.csv→重新產出 dashboard.html。你唯一要做的是「看」。

查看儀表板的三種方式(擇一):
1. 手機/電腦直接開 Telegram 看每日摘要(已內建)。
2. VPS 上 `cd ~/txo_radar && python3 -m http.server 8877` → 瀏覽器開 http://VPS_IP:8877/dashboard.html
   (看完關掉;或用 nginx+basic auth 常駐)。
3. 推上 GitHub Pages:建一個 repo,cron 每晚 `git add dashboard.html && git commit -m auto && git push`,
   手機隨時開網頁看(注意:公開 repo 等於公開你的紙上損益)。

紙上成交假設(誠實標記):進出場=當日收盤價;SP=到期日結算價近似;
−50% 停損=當日最低觸及即以停損價計(實際可能更差)。
這些近似讓它是「活體樣本外追蹤」而非「真實損益」;真實滑價仍靠你實單時回填 signals_log.csv。
