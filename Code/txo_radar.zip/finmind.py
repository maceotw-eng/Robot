# -*- coding: utf-8 -*-
"""finmind.py — FinMind v4 API 極簡客戶端(只取本平台需要的三個資料集)
需要環境變數 FINMIND_TOKEN。免費方案有速率限制,本平台每日僅呼叫個位數次,綽綽有餘。
"""
import os
import time

import pandas as pd
import requests

API = "https://api.finmindtrade.com/api/v4/data"
TOKEN = os.environ.get("FINMIND_TOKEN", "")


def _get(dataset: str, **params) -> pd.DataFrame:
    q = {"dataset": dataset, "token": TOKEN, **params}
    for attempt in range(3):
        r = requests.get(API, params=q, timeout=30)
        if r.status_code == 200:
            js = r.json()
            if js.get("status") == 200 or js.get("msg") == "success":
                return pd.DataFrame(js["data"])
            raise RuntimeError(f"FinMind 回應異常: {js.get('msg')}")
        time.sleep(2 * (attempt + 1))
    raise RuntimeError(f"FinMind HTTP {r.status_code}: {r.text[:200]}")


def tx_futures_daily(start: str, end: str | None = None) -> pd.DataFrame:
    """台指期每日行情(全部契約月份)。回傳含 date, contract_date, close, settlement_price 等。"""
    df = _get("TaiwanFuturesDaily", data_id="TX", start_date=start,
              **({"end_date": end} if end else {}))
    if df.empty:
        return df
    # 近月 = 當日所有非價差契約中,contract_date 最小者
    df = df[~df["contract_date"].astype(str).str.contains("/")]
    return df


def tx_near_close_series(start: str, end: str | None = None) -> pd.Series:
    """近月台指期收盤價時間序列(索引=date)。訊號計算的標的價。"""
    df = tx_futures_daily(start, end)
    if df.empty:
        raise RuntimeError("台指期資料為空,檢查 token 或日期範圍")
    near = df.sort_values(["date", "contract_date"]).groupby("date").first()
    s = pd.to_numeric(near["close"], errors="coerce").dropna()
    s.index = pd.to_datetime(s.index)
    return s.sort_index()


def txo_daily(date: str) -> pd.DataFrame:
    """某日 TXO 全履約價行情。欄位含 contract_date(如 202607/202607W2)、
    strike_price、call_put、close、settlement_price 等。"""
    return _get("TaiwanOptionDaily", data_id="TXO", start_date=date, end_date=date)
