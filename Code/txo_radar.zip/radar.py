# -*- coding: utf-8 -*-
"""radar.py — TXO 四策略雷達(階段二:訊號自動化+人工執行)

兩種模式:
  python radar.py morning   盤前簡報:今天收盤該做的動作(S1/S3/S4 盤前可定,S2 給警戒線)
  python radar.py evening   盤後稽核:抓當日資料,確認訊號、記錄理論成交價(選擇權收盤價),
                            寫入 signals_log.csv,並提示你回填實際成交價

環境變數: FINMIND_TOKEN(必要), TG_BOT_TOKEN / TG_CHAT_ID(推播,可選)
狀態檔:  positions.json(目前持倉,人工維護或由 evening 半自動更新)
日誌:    signals_log.csv — 階段二的審查卷宗,欄位見 LOG_COLS
"""
from __future__ import annotations

import json
import os
import sys
from datetime import date, timedelta

import pandas as pd
import requests

import finmind as fm
import ledger as lg
import dashboard as db
from strategies import Signal, compute_signals, pick_contract

BASE = os.path.dirname(os.path.abspath(__file__))
POS_FILE = os.path.join(BASE, "positions.json")
LOG_FILE = os.path.join(BASE, "signals_log.csv")
LOG_COLS = ["date", "run", "strategy", "action", "contract", "strike", "expiry",
            "underlying", "theory_px", "actual_px", "slippage_pts", "note"]


# ---------- 基礎設施 ----------
def tg_push(text: str):
    tok, chat = os.environ.get("TG_BOT_TOKEN"), os.environ.get("TG_CHAT_ID")
    if not (tok and chat):
        print("[tg] 未設定,僅列印:\n" + text)
        return
    try:
        requests.post(f"https://api.telegram.org/bot{tok}/sendMessage",
                      json={"chat_id": chat, "text": text}, timeout=15)
    except Exception as e:
        print(f"[tg] 推播失敗: {e}")


def load_positions() -> dict:
    if os.path.exists(POS_FILE):
        with open(POS_FILE, encoding="utf-8") as f:
            return json.load(f)
    return {}


def append_log(rows: list[dict]):
    df = pd.DataFrame(rows, columns=LOG_COLS)
    header = not os.path.exists(LOG_FILE)
    df.to_csv(LOG_FILE, mode="a", header=header, index=False, encoding="utf-8-sig")


# ---------- 早班:盤前簡報 ----------
def run_morning():
    today = date.today()
    px = fm.tx_near_close_series((today - timedelta(days=200)).isoformat())
    sigs = compute_signals(px, today)
    pos = lg._load()
    lines = [f"📋 TXO 雷達|盤前簡報 {today}"]
    for s in sigs:
        held = pos.get(s.strategy)
        if held:
            lines.append(f"・{s.strategy}: 持有中 {held.get('cp','')} "
                         f"{held.get('strike','')} ({held.get('contract_date','')}) — 依規格續抱")
            continue
        if s.action in ("BUY_CALL", "BUY_PUT"):
            lines.append(f"・{s.strategy}: 🆕 今日收盤前(13:25) {s.action} "
                         f"[{s.contract},剩餘≥{s.min_days}天] — {s.note}")
        elif s.action == "WATCH":
            lines.append(f"・{s.strategy}: ⚠️ 警戒 — {s.note}(若今收觸線→收盤前買 CALL)")
        else:
            lines.append(f"・{s.strategy}: 空手 — {s.note}")
    lines.append("執行後請於 evening 稽核時回填實際成交價。")
    tg_push("\n".join(lines))


# ---------- 晚班:盤後稽核 ----------
def run_evening():
    today = date.today()
    px = fm.tx_near_close_series((today - timedelta(days=200)).isoformat())
    have_today = len(px) and px.index.date[-1] == today
    if not have_today:
        tg_push(f"⏳ {today} FinMind 尚未更新今日期貨資料,稍後再跑 evening。")
        return
    underlying = float(px.iloc[-1])
    sigs = compute_signals(px, today)                 # 函式內部會切到昨日→無未來函數
    # S2 用今日收盤補判
    if len(px) >= 6:
        r5 = px.iloc[-1] / px.iloc[-6] - 1
        for s in sigs:
            if s.strategy == "S2":
                if r5 <= -0.05:
                    s.action, s.note = "BUY_CALL", f"今收5日報酬 {r5*100:.1f}% ≤ −5% 觸發"
                else:
                    s.action = "NONE" if s.action != "WATCH" else "NONE"
                    s.note += f" | 今收5日報酬 {r5*100:.1f}% 未觸發"
    chain = fm.txo_daily(today.isoformat())
    book = lg._load()
    rows, lines = [], [f"🧾 TXO 雷達|盤後稽核 {today}(標的={underlying:.0f})"]
    for s in sigs:
        if book.get(s.strategy) or s.action not in ("BUY_CALL", "BUY_PUT"):
            continue
        cp = "CALL" if s.action == "BUY_CALL" else "PUT"
        c = pick_contract(chain, today, s.contract, s.min_days, cp, underlying)
        if c is None:
            lines.append(f"・{s.strategy}: 應{ s.action } 但契約挑選失敗(檢查鏈資料)")
            continue
        lg.open_position(s.strategy, cp, c, today)          # 紙上自動進場(收盤價)
        lines.append(f"・{s.strategy}: 📥 紙上進場 {s.action} {c['contract_date']} "
                     f"K={c['strike']:.0f} @ {c['close']:.1f}(收盤價,DTE{c['dte']})")
        rows.append({"date": today.isoformat(), "run": "evening", "strategy": s.strategy,
                     "action": s.action, "contract": c["contract_date"],
                     "strike": c["strike"], "expiry": c["expiry"],
                     "underlying": underlying, "theory_px": c["close"],
                     "actual_px": "", "slippage_pts": "", "note": s.note})
    # 逐日結算:市值更新+出場檢查+NAV
    for m in lg.daily_settle(chain, today):
        lines.append("・" + m)
    if rows:
        append_log(rows)
        lines.append(f"日誌 +{len(rows)} 筆(實單者請回填 actual_px)。")
    path = db.generate()
    lines.append("📊 儀表板已更新 dashboard.html")
    tg_push("\n".join(lines))


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "morning"
    {"morning": run_morning, "evening": run_evening}.get(mode, run_morning)()
