# -*- coding: utf-8 -*-
"""strategies.py — 凍結版規格的訊號引擎(v2026-07-19 凍結,對應紅隊二輪後規格)
只做「訊號計算」,不碰下單。任何規格修改必須先過紅隊審查,不得在此檔即興調整。

凍結規格摘要:
  S1 趨勢切換: 昨收 > MA60(不含今日) → 買價平 CALL(週選,剩餘≥5日曆天);
               昨收 ≤ MA60 → 買價平 PUT。抱到期 SP 結算(25% 停損已刪除)。
  S2 大跌反彈: 今收/5日前收 −1 ≤ −5% → 買價平 CALL(月選,剩餘≥10天),抱10日曆天,無停損。
               ⚠ 唯一需盤中確認的策略。
  S3 月底效應: 距月底 ≤5 個交易日 → 買價平 CALL(月選,剩餘≥8天),抱7日曆天,−50%停損。
  S4 季節效應: 月份∈{2,4,5,7,11,12} → 買價平 CALL(月選,剩餘≥12天),抱18日曆天,−50%停損。
               (性質=多頭beta,已明示)
"""
from __future__ import annotations

import calendar
from dataclasses import dataclass
from datetime import date, timedelta

import pandas as pd

SEASONAL_MONTHS = {2, 4, 5, 7, 11, 12}


@dataclass
class Signal:
    strategy: str          # S1..S4
    action: str            # BUY_CALL / BUY_PUT / HOLD / NONE / WATCH
    contract: str          # weekly / monthly
    min_days: int          # 契約剩餘日曆天下限
    note: str = ""


def third_wednesday(y: int, m: int) -> date:
    c = calendar.Calendar()
    weds = [d for d in c.itermonthdates(y, m) if d.month == m and d.weekday() == 2]
    return weds[2]


def trading_days_to_month_end(d: date, holidays: set[date] | None = None) -> int:
    """今日(含)到月底剩餘的交易日數(週一~五,扣國定假日集合)。"""
    holidays = holidays or set()
    n, cur = 0, d
    last = date(d.year, d.month, calendar.monthrange(d.year, d.month)[1])
    while cur <= last:
        if cur.weekday() < 5 and cur not in holidays:
            n += 1
        cur += timedelta(days=1)
    return n


def compute_signals(px: pd.Series, today: date,
                    holidays: set[date] | None = None) -> list[Signal]:
    """px = 近月台指期收盤序列(至昨日或含今日皆可;函式自行切齊避免未來函數)。"""
    px = px[px.index.date < today] if (len(px) and px.index.date[-1] >= today) else px
    out: list[Signal] = []

    # --- S1 趨勢切換(可於盤前決定) ---
    if len(px) >= 61:
        # 規格: M = 過去60個交易日(不含訊號日)之均值;訊號用「昨日收盤」
        ma60 = px.iloc[-60:].mean()          # px 已切到昨日,故最後60筆=不含今日
        ystd = px.iloc[-1]
        if ystd > ma60:
            out.append(Signal("S1", "BUY_CALL", "weekly", 5,
                              f"昨收 {ystd:.0f} > MA60 {ma60:.0f}(多)"))
        else:
            out.append(Signal("S1", "BUY_PUT", "weekly", 5,
                              f"昨收 {ystd:.0f} ≤ MA60 {ma60:.0f}(空)"))
    else:
        out.append(Signal("S1", "NONE", "weekly", 5, "資料不足60日"))

    # --- S2 大跌反彈(需今日收盤;盤前只能給警戒) ---
    if len(px) >= 5:
        ref = px.iloc[-5]                     # 5個交易日前收盤(以昨日為第1日回推)
        trigger_px = ref * 0.95
        dist = (px.iloc[-1] / ref - 1) * 100
        note = (f"觸發線={trigger_px:.0f}(5日前收 {ref:.0f}×0.95),"
                f"昨收距離 {dist:+.1f}%")
        action = "WATCH" if dist <= -3.0 else "NONE"   # 已跌逾3%列入警戒
        out.append(Signal("S2", action, "monthly", 10, note))

    # --- S3 月底效應(純日曆,盤前可定) ---
    td = trading_days_to_month_end(today, holidays)
    if td <= 5:
        out.append(Signal("S3", "BUY_CALL", "monthly", 8, f"距月底 {td} 個交易日"))
    else:
        out.append(Signal("S3", "NONE", "monthly", 8, f"距月底 {td} 個交易日(>5)"))

    # --- S4 季節效應(純日曆,盤前可定) ---
    if today.month in SEASONAL_MONTHS:
        out.append(Signal("S4", "BUY_CALL", "monthly", 12,
                          f"{today.month} 月屬季節月(多頭beta模組)"))
    else:
        out.append(Signal("S4", "NONE", "monthly", 12, f"{today.month} 月非季節月"))
    return out


def pick_contract(chain: pd.DataFrame, today: date, kind: str,
                  min_days: int, cp: str, underlying: float) -> dict | None:
    """從當日 TXO 行情表挑契約:kind=weekly/monthly, cp=CALL/PUT。
    回傳 {contract_date, strike, close} 或 None。
    週選=代碼含W且到期(該週三)距今≥min_days;月選=當月第三週三,不足改次月。
    履約價=最接近標的價(CALL 取≤標的最近檔、PUT 取≥標的最近檔)。"""
    if chain is None or chain.empty:
        return None
    df = chain.copy()
    df["cd"] = df["contract_date"].astype(str)
    cpcol = df["call_put"].astype(str).str.upper().str[0]
    df = df[cpcol == cp[0]]

    def expiry(cd: str) -> date | None:
        try:
            y, m = int(cd[:4]), int(cd[4:6])
            if "W" in cd:
                wk = int(cd.split("W")[1])
                c = calendar.Calendar()
                weds = [x for x in c.itermonthdates(y, m)
                        if x.month == m and x.weekday() == 2]
                return weds[wk - 1] if wk <= len(weds) else None
            return third_wednesday(y, m)
        except Exception:
            return None

    df["expiry"] = df["cd"].map(expiry)
    df = df.dropna(subset=["expiry"])
    df["dte"] = df["expiry"].map(lambda e: (e - today).days)
    if kind == "weekly":
        cand = df[df["cd"].str.contains("W") & (df["dte"] >= min_days)]
    else:
        cand = df[~df["cd"].str.contains("W") & (df["dte"] >= min_days)]
    if cand.empty:
        return None
    nearest_cd = cand.sort_values("dte").iloc[0]["cd"]
    cand = cand[cand["cd"] == nearest_cd].copy()
    cand["strike"] = pd.to_numeric(cand["strike_price"], errors="coerce")
    if cp == "CALL":
        atm = cand[cand["strike"] <= underlying].sort_values("strike").tail(1)
    else:
        atm = cand[cand["strike"] >= underlying].sort_values("strike").head(1)
    if atm.empty:
        atm = cand.iloc[(cand["strike"] - underlying).abs().argsort()[:1]]
    r = atm.iloc[0]
    return {"contract_date": r["cd"], "strike": float(r["strike"]),
            "close": float(pd.to_numeric(r.get("close"), errors="coerce")),
            "expiry": str(r["expiry"]), "dte": int(r["dte"])}
