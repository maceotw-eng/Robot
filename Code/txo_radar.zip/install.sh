#!/bin/bash
# TXO 雷達一鍵安裝(Debian/Ubuntu)
set -e
cd "$(dirname "$0")"
apt-get install -y python3-venv > /dev/null 2>&1 || true
python3 -m venv venv
./venv/bin/pip install -q --upgrade pip
./venv/bin/pip install -q pandas requests
cp -n env.example radar.env || true
chmod 600 radar.env
echo "✅ 環境建好。接下來兩步:"
echo "1) nano radar.env   ← 填入三個金鑰"
echo "2) 測試:  set -a; . ./radar.env; set +a; ./venv/bin/python radar.py morning"
echo ""
echo "測通後排程(crontab -e 加入,VPS 時區請先 timedatectl set-timezone Asia/Taipei):"
echo '20 8 * * 1-5  cd /root/txo_radar && set -a && . ./radar.env && set +a && ./venv/bin/python radar.py morning >> cron.log 2>&1'
echo '30 20 * * 1-5 cd /root/txo_radar && set -a && . ./radar.env && set +a && ./venv/bin/python radar.py evening >> cron.log 2>&1'
