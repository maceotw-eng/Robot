# -*- coding: utf-8 -*-
"""策略 D 消融引擎 — 依 D_preregistration.md 凍結文件
輸出開發段 8 組（base/a/b/c/ab/ac/bc/abc）× 2 成本版的
年化/t/P1/ES99/最差夜/停做夜數，與「交換比」表。"""
import json, os, math, sys, io
from collections import defaultdict
import statistics as st

BASE = os.path.dirname(os.path.abspath(__file__))
DEV = ("2001-01-01", "2018-12-31")
VAL = ("2019-01-01", "2026-06-30")
UNLOCK_VALIDATION = False

def build_nights():
    rows = json.load(open(os.path.join(BASE, "data", "tx_daily.json")))
    byd = {}
    for d, cd, o, h, l, c, v, sp, oi, sess in rows:
        if sess != "position" or "/" in str(cd) or not o or not c: continue
        byd.setdefault(d, {})[str(cd)] = (o, c, v or 0)
    dates = sorted(byd)
    nights = []          # (entry_date, overnight_ret_gross)
    cont_ret = []        # 連續日報酬(收收) 供濾網
    prev_front = None; prev_close = {}
    lvl = 100.0; levels = {}
    for d in dates:
        cmap = byd[d]
        front = max(cmap, key=lambda k: cmap[k][2])
        if prev_front and prev_front in cmap and prev_front in prev_close:
            o, c, v = cmap[prev_front]
            pc = prev_close[prev_front]
            nights.append([d_prev, o / pc - 1])          # 進場日=前一日
            r_cc = c / pc - 1
            cont_ret.append((d, r_cc)); lvl *= (1 + r_cc)
        levels[d] = lvl
        prev_front = front; prev_close = {k: v[1] for k, v in cmap.items()}
        d_prev = d
    return nights, cont_ret, levels, dates

def build_filters(cont_ret, levels, dates):
    # (a) 200DMA
    lv = [levels[d] for d in dates]
    ma_ok = {}
    for i, d in enumerate(dates):
        if i >= 200:
            ma = sum(lv[i - 199:i + 1]) / 200
            ma_ok[d] = lv[i] >= ma
    # (b) 20日已實現波動 > 自身252日80分位
    rd = [r for _, r in cont_ret]; rdd = [d for d, _ in cont_ret]
    vol20 = {}
    vals = []
    vol_ok = {}
    for i in range(len(rd)):
        if i >= 20:
            v = st.pstdev(rd[i - 19:i + 1])
            vol20[rdd[i]] = v; vals.append(v)
            if len(vals) > 252:
                hist = sorted(vals[-253:-1])
                thr = hist[int(0.8 * len(hist))]
                vol_ok[rdd[i]] = v <= thr
    fomc = set(json.load(open(os.path.join(BASE, "data", "fomc_dates.json"))))
    return ma_ok, vol_ok, fomc

def run(seg, cost, config, data):
    nights, ma_ok, vol_ok, fomc = data
    lo, hi = seg
    if hi > DEV[1] and not UNLOCK_VALIDATION:
        raise SystemExit("段別鎖：驗證段未解鎖。")
    taken, skipped = [], 0
    for d, r in nights:
        if not (lo <= d <= hi): continue
        if "a" in config and ma_ok.get(d) is False: skipped += 1; continue
        if "b" in config and vol_ok.get(d) is False: skipped += 1; continue
        if "c" in config and d in fomc: skipped += 1; continue
        taken.append(r - cost)
    return taken, skipped

def stats(rs):
    n = len(rs)
    if not n: return {}
    m = st.mean(rs); s = st.pstdev(rs)
    srt = sorted(rs)
    es99 = st.mean(srt[:max(1, int(0.01 * n))])
    return dict(n=n, ann=m * 240, t=m / (s / math.sqrt(n)) if s else 0,
                p1=srt[int(0.01 * n)], es99=es99, worst=srt[0],
                win=sum(1 for x in rs if x > 0) / n)

if __name__ == "__main__":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    nights, cont_ret, levels, dates = build_nights()
    ma_ok, vol_ok, fomc = build_filters(cont_ret, levels, dates)
    data = (nights, ma_ok, vol_ok, fomc)
    for cost, tag in ((0.00012, "基準0.012%"), (0.00024, "壓力0.024%")):
        print("\n==== 成本 %s ｜開發段 2001-2018 ====" % tag)
        base_s = None
        print("%-6s %6s %7s %6s %8s %8s %8s %7s %s" % ("組", "n", "年化", "t", "P1", "ES99", "最差夜", "停做", "交換比(棄年化pp/ES99改善pp)"))
        for cfg in ("", "a", "b", "c", "ab", "ac", "bc", "abc"):
            rs, sk = run(DEV, cost, cfg, data)
            s = stats(rs)
            if cfg == "": base_s = s
            tr = ""
            if cfg and base_s:
                give = (base_s["ann"] - s["ann"]) * 100
                gain = (s["es99"] - base_s["es99"]) * 100
                tr = "%.2f / %.2f" % (give, gain)
            print("%-6s %6d %6.1f%% %6.2f %7.2f%% %7.2f%% %7.2f%% %7d %s" % (
                cfg or "base", s["n"], 100 * s["ann"], s["t"],
                100 * s["p1"], 100 * s["es99"], 100 * s["worst"], sk, tr))
