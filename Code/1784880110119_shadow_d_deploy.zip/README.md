# D 影子監測器部署包（策略 D：台指隔夜偏移，濾網版凍結規格）

自足包，四個檔案跑天下，**純 Python 標準庫、零 pip 依賴**（Python 3.6+）：
```
shadow_D.py          # 主程式（update/signal/record/report/morning 五指令）
engine_D.py          # 連續合約與濾網計算（被 shadow_D 引用）
data/tx_daily.json   # TX 日資料倉 1998~今（update 會自動增量）
data/fomc_dates.json # FOMC 日期（engine 引用）
results/             # shadow_log.csv 會生在這
```
資料源＝期交所免費端點（futDataDown），無 API key、無訂閱依賴。

## VPS 部署三步

**1. 上 git（在你的電腦）**
```bash
cd Robot   # 你的 repo
mkdir shadow-d && cp -r <此資料夾>/* shadow-d/
git add shadow-d && git commit -m "D shadow monitor" && git push
```

**2. VPS 拉下來＋設 Telegram 推播**
```bash
git clone <你的repo> && cd Robot/shadow-d
# Telegram：跟 BotFather 建 bot 拿 token，跟 bot 說句話後
# 用 https://api.telegram.org/bot<TOKEN>/getUpdates 查你的 chat_id
```

**3. crontab -e（時區務必指定台北）**
```cron
CRON_TZ=Asia/Taipei
TELEGRAM_BOT_TOKEN=xxxx
TELEGRAM_CHAT_ID=yyyy
# 平日 13:40 更新資料＋產生今晚訊號（GO/SKIP 推播）
40 13 * * 1-5 cd /path/Robot/shadow-d && python3 shadow_D.py update && python3 shadow_D.py signal
# 平日 08:40 若有持倉推平倉提醒
40 8 * * 1-5 cd /path/Robot/shadow-d && python3 shadow_D.py morning
```
（舊版 cron 無 CRON_TZ 就把時間自己換算成 VPS 時區，或 `TZ=Asia/Taipei` 放最上面。）

## 日常
- 🟢 GO 推播 → 13:44 下單微台一口 → 次晨 08:46 平倉 → SSH 回填：
  `python3 shadow_D.py record 2026-07-28 --entry 42650 --exit 42710`
- ⚪ SKIP → 休息
- **週五照凍結版執行（該 GO 就 GO）**——變體考場需要凍結版的週五實測，提前跳過會污染數據（紅隊裁定 2026-07-26）
- 隨時 `python3 shadow_D.py report` 看滑價中位統計
- 90 天後開庭三案並審：滑價 vs 2tick 壓力假設／濾網即時盤後一致率／週五變體（同族 ×1.1）

## 規格出處
凍結文件：D_preregistration.md（sha256:bc41986e）｜驗證報告：D_validation_report.md
規則一句話：每日 13:44 買微台前月、次晨 08:46 平；指數 < 200DMA 或 20日波動 > 自身252日80分位 → 當夜停做。
