# -*- coding: utf-8 -*-
"""策略 D 影子監測器（影子模擬期 90 天，規格照 D_preregistration.md §4）
用法：
  python shadow_D.py update    # 從期交所抓最新日資料（免費、永續）並更新資料倉
  python shadow_D.py signal    # 產生今晚訊號（13:40 前跑）：進場/停做＋推播文字，寫入 shadow_log
  python shadow_D.py record 2026-07-28 --entry 42650 --exit 42710 [--note "..."]
                               # 回填實際成交，自動算滑價與損益（微台 NT$10/點）
資料源：TAIFEX futDataDown（免費）；FinMind 到期不影響。"""
import urllib.request, urllib.parse, json, os, sys, io, csv, datetime, math
import statistics as st

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
BASE = os.path.dirname(os.path.abspath(__file__))
TXD = os.path.join(BASE, "data", "tx_daily.json")
LOG = os.path.join(BASE, "results", "shadow_log.csv")
POINT_NTD = 10  # 微台每點

def push(msg):
    """Telegram 推播（設環境變數 TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID 即啟用；未設則僅印出）"""
    tok = os.environ.get("TELEGRAM_BOT_TOKEN"); chat = os.environ.get("TELEGRAM_CHAT_ID")
    if not tok or not chat: return
    try:
        url = "https://api.telegram.org/bot%s/sendMessage" % tok
        data = urllib.parse.urlencode(dict(chat_id=chat, text=msg)).encode()
        urllib.request.urlopen(urllib.request.Request(url, data=data), timeout=30)
    except Exception as e:
        print("push failed:", e)

def taifex_fetch(d0, d1):
    url = "https://www.taifex.com.tw/cht/3/futDataDown"
    data = urllib.parse.urlencode(dict(down_type=1, commodity_id="TX",
        queryStartDate=d0.strftime("%Y/%m/%d"), queryEndDate=d1.strftime("%Y/%m/%d"))).encode()
    req = urllib.request.Request(url, data=data, headers={"User-Agent": "Mozilla/5.0"})
    txt = urllib.request.urlopen(req, timeout=60).read().decode("big5", "replace")
    out = []
    for ln in txt.strip().splitlines()[1:]:
        p = [x.strip() for x in ln.split(",")]
        if len(p) < 18 or p[1] != "TX": continue
        cd = p[2].replace(" ", "")
        if "/" in cd: continue
        def num(x):
            try: return float(x)
            except Exception: return None
        sess = "position" if p[17] == "一般" else "after_market"
        d = p[0].replace("/", "-")
        out.append([d, cd, num(p[3]), num(p[4]), num(p[5]), num(p[6]),
                    int(float(p[9])) if num(p[9]) is not None else 0,
                    num(p[10]), int(float(p[11])) if num(p[11]) is not None else None, sess])
    return out

def cmd_update():
    rows = json.load(open(TXD))
    have = {(r[0], r[1], r[9]) for r in rows}
    today = datetime.date.today()
    new = [r for r in taifex_fetch(today - datetime.timedelta(days=14), today)
           if (r[0], r[1], r[9]) not in have]
    rows += new
    rows.sort(key=lambda r: (r[0], r[1]))
    json.dump(rows, open(TXD, "w"))
    print("更新完成：新增 %d 列，資料至 %s" % (len(new), max(r[0] for r in rows)))

def build_state():
    import engine_D as D
    nights, cont_ret, levels, dates = D.build_nights()
    ma_ok, vol_ok, fomc = D.build_filters(cont_ret, levels, dates)
    return dates, levels, ma_ok, vol_ok

def cmd_signal():
    rows = json.load(open(TXD))
    dates, levels, ma_ok, vol_ok = build_state()
    d = dates[-1]
    byc = {r[1]: r for r in rows if r[0] == d and r[9] == "position"}
    front = max(byc, key=lambda k: byc[k][6])
    close = byc[front][5]
    ok_a = ma_ok.get(d); ok_b = vol_ok.get(d)
    go = (ok_a is not False) and (ok_b is not False)
    if go:
        msg = "🟢 D 訊號【進場】%s：13:44 市價買 微台 %s 一口｜今日收盤參考 %s｜明日 08:46 市價平倉" % (d, front, close)
    else:
        why = []
        if ok_a is False: why.append("200DMA 下")
        if ok_b is False: why.append("波動>80分位")
        msg = "⚪ D 訊號【停做】%s：%s" % (d, "＋".join(why))
    print(msg)
    push(msg)
    hdr = ["date","signal","filter_ma","filter_vol","front","ref_entry","ref_exit",
           "fill_entry","fill_exit","slip_entry_pts","slip_exit_pts","pnl_pts","pnl_ntd","note"]
    exists = os.path.exists(LOG)
    with open(LOG, "a", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        if not exists: w.writerow(hdr)
        w.writerow([d, "GO" if go else "SKIP", ok_a, ok_b, front, close, "", "", "", "", "", "", "", ""])
    print("已寫入 shadow_log.csv")

def cmd_record(argv):
    d = argv[0]
    kv = dict(zip(argv[1::2], argv[2::2]))
    entry = float(kv.get("--entry")); exitp = float(kv.get("--exit"))
    note = kv.get("--note", "")
    rows = list(csv.reader(open(LOG, encoding="utf-8-sig")))
    hdr, body = rows[0], rows[1:]
    # 次日開盤參考
    tx = json.load(open(TXD))
    for r in body:
        if r[0] == d and r[1] == "GO":
            front = r[4]; ref_e = float(r[5])
            nxt = sorted({x[0] for x in tx if x[0] > d})
            ref_x = ""
            if nxt:
                for x in tx:
                    if x[0] == nxt[0] and x[1] == front and x[9] == "position":
                        ref_x = x[2]
            se = entry - ref_e
            sx = (float(ref_x) - exitp) if ref_x else ""
            pnl = exitp - entry
            r[6], r[7], r[8] = ref_x, entry, exitp
            r[9], r[10] = "%.1f" % se, ("%.1f" % sx if sx != "" else "")
            r[11], r[12], r[13] = "%.1f" % pnl, "%.0f" % (pnl * POINT_NTD), note
            print("已記錄 %s：滑價 進%.1f點/出%s點，損益 %+.1f 點（NT$%+.0f）" % (
                d, se, r[10] or "?", pnl, pnl * POINT_NTD))
    with open(LOG, "w", newline="", encoding="utf-8-sig") as f:
        csv.writer(f).writerows([hdr] + body)

def cmd_report():
    body = list(csv.reader(open(LOG, encoding="utf-8-sig")))[1:]
    slips = [float(r[9]) for r in body if r[9] not in ("", None)]
    if slips:
        print("影子期滑價：n=%d 中位=%.1f點 平均=%.1f點（G 解凍參考線=1 tick）" % (
            len(slips), sorted(slips)[len(slips)//2], st.mean(slips)))
    gos = sum(1 for r in body if r[1] == "GO"); print("GO %d / SKIP %d" % (gos, len(body) - gos))

def cmd_morning():
    """早盤提醒：若最近一筆 GO 尚未回填成交 → 推播 08:46 平倉提醒"""
    if not os.path.exists(LOG): return
    body = list(csv.reader(open(LOG, encoding="utf-8-sig")))[1:]
    if not body: return
    last = body[-1]
    if last[1] == "GO" and not last[7]:
        msg = "⏰ D 平倉提醒：%s 進場的微台 %s（參考 %s），今日 08:46 市價平倉，成交後回填 record" % (
            last[0], last[4], last[5])
        print(msg); push(msg)
    else:
        print("今晨無持倉")

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "signal"
    if cmd == "update": cmd_update()
    elif cmd == "signal": cmd_signal()
    elif cmd == "record": cmd_record(sys.argv[2:])
    elif cmd == "report": cmd_report()
    elif cmd == "morning": cmd_morning()
    else: print(__doc__)
