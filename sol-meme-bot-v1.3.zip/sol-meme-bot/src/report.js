// 績效報表：node src/report.js
import fs from "fs";
let s;
try { s = JSON.parse(fs.readFileSync("data/state.json", "utf8")); }
catch (e) { console.log("尚無交易紀錄"); process.exit(0); }
const sells = s.ledger.filter(l => l.side === "sell");
const pnl = sells.reduce((a, l) => a + (l.pnlSOL || 0), 0);
const wins = sells.filter(l => (l.pnlSOL || 0) > 0);
console.log("═══ 績效報表 ═══");
console.log("出場筆數:", sells.length, "| 勝率:", sells.length ? (wins.length / sells.length * 100).toFixed(0) + "%" : "-");
console.log("總 PnL:", pnl.toFixed(4), "SOL");
if (wins.length) console.log("平均獲利:", (wins.reduce((a, l) => a + l.pnlSOL, 0) / wins.length).toFixed(4), "SOL");
const losses = sells.filter(l => (l.pnlSOL || 0) <= 0);
if (losses.length) console.log("平均虧損:", (losses.reduce((a, l) => a + l.pnlSOL, 0) / losses.length).toFixed(4), "SOL");
console.log("目前持倉:", s.positions.filter(p => p.status === "open").map(p => p.symbol).join(", ") || "無");
console.log("黑名單:", s.blacklist.length, "個");
