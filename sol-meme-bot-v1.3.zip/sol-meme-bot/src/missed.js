// ═══════════════════════════════════════════════
// missed.js — 遺珠追蹤器：找出「雷達沒抓到的肥羊」
// 每次執行：抓 GeckoTerminal 熱門池，找 24H 漲幅 ≥100% 的大贏家，
// 比對 research.csv：完全沒掃到？掃到但分數太低？
// 結果累積到 data/missed.csv → 未來修正「找標的」的依據
// 用法：node src/missed.js
// ═══════════════════════════════════════════════
import fs from "fs";

const GT = "https://api.geckoterminal.com/api/v2";
const RESEARCH = "data/research.csv";
const OUT = "data/missed.csv";
const MIN_GAIN = 100;   // 24H 漲幅 ≥100% 才算肥羊
const MIN_LIQ = 20000;  // 流動性門檻（太小的池不算可交易機會）

async function jget(url) {
  const r = await fetch(url, { headers: { Accept: "application/json" } });
  if (!r.ok) throw new Error("HTTP " + r.status);
  return r.json();
}

// 1) 讀 research.csv：每個地址的最高分
const seen = new Map();
if (fs.existsSync(RESEARCH)) {
  const rows = fs.readFileSync(RESEARCH, "utf8").trim().split("\n").slice(1);
  for (const l of rows) {
    const c = l.split(",");
    const addr = c[1], score = parseFloat(c[5]) || 0;
    if (!seen.has(addr) || score > seen.get(addr)) seen.set(addr, score);
  }
}
console.log("雷達已掃過 " + seen.size + " 個地址");

// 2) 抓 GT 熱門池（trending + 依24H交易數排序的池，兩路合併）
const pools = [];
for (const path of ["/networks/solana/trending_pools", "/networks/solana/pools?sort=h24_tx_count_desc&page=1"]) {
  try {
    const d = await jget(GT + path);
    if (d && Array.isArray(d.data)) pools.push(...d.data);
  } catch (e) { console.log("抓取失敗:", path, e.message); }
  await new Promise(r => setTimeout(r, 800));
}

// 3) 篩肥羊 + 比對
const already = new Set(
  fs.existsSync(OUT)
    ? fs.readFileSync(OUT, "utf8").trim().split("\n").slice(1).map(l => l.split(",")[2] + ":" + l.split(",")[0].slice(0,10))
    : []
);
if (!fs.existsSync(OUT)) fs.writeFileSync(OUT, "time,symbol,addr,gain24hPct,liqUsd,fdvUsd,vol24hUsd,verdict,maxScoreSeen\n");

const today = new Date().toISOString().slice(0, 10);
let found = 0, blind = 0, lowScore = 0;
const dedup = new Set();
for (const p of pools) {
  const a = p.attributes || {};
  const gain = parseFloat((a.price_change_percentage || {}).h24) || 0;
  const liq = parseFloat(a.reserve_in_usd) || 0;
  if (gain < MIN_GAIN || liq < MIN_LIQ) continue;
  const baseId = ((p.relationships || {}).base_token || {}).data;
  const addr = baseId && baseId.id ? baseId.id.replace("solana_", "") : "";
  if (!addr || dedup.has(addr)) continue;
  dedup.add(addr);
  if (already.has(addr + ":" + today)) continue; // 今天記過了
  const sym = (a.name || "?").split(" / ")[0].replace(/,/g, ";");
  const maxScore = seen.get(addr);
  let verdict;
  if (maxScore === undefined) { verdict = "盲區:完全沒掃到"; blind++; }
  else if (maxScore < 78) { verdict = "掃到但分數不足"; lowScore++; }
  else { verdict = "有掃到高分(檢查為何未收錄)"; }
  found++;
  fs.appendFileSync(OUT, [new Date().toISOString(), sym, addr, gain.toFixed(0),
    Math.round(liq), Math.round(parseFloat(a.fdv_usd) || 0),
    Math.round(parseFloat((a.volume_usd || {}).h24) || 0), verdict, maxScore ?? ""].join(",") + "\n");
  console.log(`🐑 ${sym} +${gain.toFixed(0)}% LIQ $${(liq/1e3).toFixed(0)}K → ${verdict}${maxScore !== undefined ? "(最高" + maxScore + "分)" : ""}`);
}
console.log(`\n本次肥羊 ${found} 隻 | 盲區 ${blind} | 分數不足 ${lowScore}`);
console.log("累積紀錄: data/missed.csv（每天跑一次，一週後統計盲區來源）");
