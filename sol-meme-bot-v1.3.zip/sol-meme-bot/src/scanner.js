// ═══════════════════════════════════════════════
// scanner.js — DEX Screener 掃描 + 六維評分引擎
// （與網頁版「SOL 迷因雷達」同一套邏輯）
// ═══════════════════════════════════════════════
const API = "https://api.dexscreener.com";
const EXCLUDE = new Set([
  "So11111111111111111111111111111111111111112",
  "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
  "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",
]);

async function jget(url, timeoutMs = 15000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(url, { headers: { Accept: "application/json" }, signal: ctrl.signal });
    if (!r.ok) throw new Error("HTTP " + r.status + " " + url);
    return await r.json();
  } finally { clearTimeout(t); }
}

export async function collectPairs() {
  const addrs = new Set();
  const boostMap = {};
  const safe = u => jget(u).catch(() => []);
  const [top, latest, profiles] = await Promise.all([
    safe(API + "/token-boosts/top/v1"),
    safe(API + "/token-boosts/latest/v1"),
    safe(API + "/token-profiles/latest/v1"),
  ]);
  for (const arr of [top, latest, profiles]) {
    if (!Array.isArray(arr)) continue;
    for (const t of arr) {
      if (t.chainId === "solana" && t.tokenAddress && !EXCLUDE.has(t.tokenAddress)) {
        addrs.add(t.tokenAddress);
        const amt = t.totalAmount || t.amount || 0;
        if (amt) boostMap[t.tokenAddress] = (boostMap[t.tokenAddress] || 0) + amt;
      }
    }
  }
  const pairs = [];
  const list = [...addrs];
  for (let i = 0; i < list.length; i += 30) {
    try {
      const d = await jget(API + "/latest/dex/tokens/" + list.slice(i, i + 30).join(","));
      if (d && Array.isArray(d.pairs)) pairs.push(...d.pairs);
    } catch (e) { /* skip chunk */ }
  }
  for (const q of ["solana meme", "pump solana"]) {
    try {
      const d = await jget(API + "/latest/dex/search?q=" + encodeURIComponent(q));
      if (d && Array.isArray(d.pairs)) pairs.push(...d.pairs);
    } catch (e) {}
  }
  return { pairs: dedupe(pairs), boostMap };
}

export function dedupe(pairs) {
  const best = new Map();
  for (const p of pairs) {
    if (!p || p.chainId !== "solana") continue;
    const addr = p.baseToken && p.baseToken.address;
    if (!addr || EXCLUDE.has(addr)) continue;
    const liq = (p.liquidity && p.liquidity.usd) || 0;
    const prev = best.get(addr);
    if (!prev || liq > ((prev.liquidity && prev.liquidity.usd) || 0)) best.set(addr, p);
  }
  return [...best.values()];
}

// 抓指定代幣的最新報價 + 流動性（持倉管理用）
export async function fetchQuotes(addrs) {
  const map = new Map();
  for (let i = 0; i < addrs.length; i += 30) {
    try {
      const d = await jget(API + "/latest/dex/tokens/" + addrs.slice(i, i + 30).join(","));
      for (const p of dedupe((d && d.pairs) || [])) {
        map.set(p.baseToken.address, {
          price: parseFloat(p.priceUsd) || 0,
          liq: (p.liquidity && p.liquidity.usd) || 0,
        });
      }
    } catch (e) {}
  }
  return map;
}

// ── 六維評分（0–100）──
export function scoreToken(p, boost = 0) {
  const mcap = p.marketCap || p.fdv || 0;
  const liq = (p.liquidity && p.liquidity.usd) || 0;
  const vol = (p.volume && p.volume.h24) || 0;
  const vol6 = (p.volume && p.volume.h6) || 0;
  const ch = p.priceChange || {};
  const h1 = parseFloat(ch.h1) || 0, h6 = parseFloat(ch.h6) || 0;
  const h24 = parseFloat(ch.h24) || 0, m5 = parseFloat(ch.m5) || 0;
  const tx24 = (p.txns && p.txns.h24) || { buys: 0, sells: 0 };
  const tx1 = (p.txns && p.txns.h1) || { buys: 0, sells: 0 };
  const t24 = (tx24.buys || 0) + (tx24.sells || 0);
  const t1 = (tx1.buys || 0) + (tx1.sells || 0);
  const br24 = t24 > 0 ? (tx24.buys || 0) / t24 : 0.5;
  const br1 = t1 > 0 ? (tx1.buys || 0) / t1 : 0.5;
  const ageH = p.pairCreatedAt ? (Date.now() - p.pairCreatedAt) / 36e5 : null;
  let fatal = false;

  let s1 = 0;
  if (mcap > 0) {
    if (mcap <= 1e6) s1 = 17; else if (mcap <= 3e6) s1 = 20;
    else if (mcap <= 10e6) s1 = 17; else if (mcap <= 30e6) s1 = 11;
    else if (mcap <= 100e6) s1 = 6; else s1 = 2;
  }
  let s2 = 0;
  if (liq >= 20e3) {
    s2 = (liq >= 50e3 && liq <= 3e6) ? 10 : 6;
    const lr = mcap > 0 ? liq / mcap : 0;
    if (lr >= 0.05 && lr <= 0.6) s2 += 5; else if (lr >= 0.02) s2 += 3;
  }
  if (liq < 15e3) fatal = true;
  s2 = Math.min(s2, 15);

  let s3 = 0;
  const turnover = mcap > 0 ? vol / mcap : 0;
  if (turnover >= 2) s3 = 20; else if (turnover >= 1) s3 = 18;
  else if (turnover >= 0.5) s3 = 14; else if (turnover >= 0.2) s3 = 10;
  else if (turnover >= 0.05) s3 = 5;
  if (vol > 0 && vol6 / vol > 0.4) s3 = Math.min(20, s3 + 2);

  let s4 = 0;
  s4 += Math.max(0, Math.min(10, (br24 - 0.45) * 100));
  s4 += Math.max(0, Math.min(10, (br1 - 0.45) * 100));
  if (t24 < 100) s4 = Math.min(s4, 5);
  s4 = Math.round(s4);

  let s5 = 0;
  if (h1 > 0) s5 += 4;
  if (h6 > 0) s5 += 4;
  if (h24 > -15 && h24 < 120) s5 += 4;
  if (m5 > 0) s5 += 3;
  if (h24 >= 250) s5 = Math.max(0, s5 - 6);
  if (h24 <= -45) s5 = 0;

  let s6 = 4;
  if (ageH != null) {
    if (ageH < 1) s6 = 3;
    else if (ageH < 72) s6 = 10;
    else if (ageH < 24 * 14) s6 = 8;
    else if (ageH < 24 * 60) s6 = 5;
    else s6 = 3;
  }
  const bonus = boost ? Math.min(5, Math.round(Math.log2(1 + boost))) : 0;
  const score = Math.max(0, Math.min(100, s1 + s2 + s3 + s4 + s5 + s6 + bonus));
  return { score, fatal, mcap, liq, vol, turnover, br1, br24, t24, h1, h6, h24, ageH,
           dims: { mcapDim: s1, liqDim: s2, turnDim: s3, buyDim: s4, momDim: s5, ageDim: s6, boostDim: bonus } };
}
