// ═══════════════════════════════════════════════
// entry_timing.js — 進場時機研究：「訊號當下買」vs「等一等再買」
// 對每個首次達到高分(≥78)的代幣，用小時K比較四種進場法的結果：
//   T0    = 訊號當下市價進（現行做法）
//   T+1h  = 等1小時後進
//   T+3h  = 等3小時後進
//   DIP15 = 掛低15%限價單，3小時內觸到才進（不追式）
// 每種算：進場後48h內峰值倍數、≥2x率、陣亡率(收盤跌破-70%)
// 用法：node src/entry_timing.js [樣本上限,預設50]
// ═══════════════════════════════════════════════
import fs from "fs";
const MAXN = parseInt(process.argv[2]) || 50;
const CSV = "data/research.csv", CACHE = "data/ohlcv_cache.json";
if (!fs.existsSync(CSV)) { console.log("無 research.csv"); process.exit(0); }

const rows = fs.readFileSync(CSV, "utf8").trim().split("\n");
const col = Object.fromEntries(rows[0].split(",").map((h, i) => [h, i]));
// 每代幣的「首次 ≥78 分」快照
const first = new Map();
for (const l of rows.slice(1)) {
  const c = l.split(",");
  if ((parseFloat(c[col.score]) || 0) < 78) continue;
  const addr = c[col.addr];
  if (!first.has(addr)) first.set(addr, c);
}
const now = Date.now();
const ready = [...first.values()]
  .filter(c => now - Date.parse(c[col.time]) >= 51 * 36e5 && c[col.pairAddress]) // 需要 T+3h 之後還有48h窗
  .slice(0, MAXN);
console.log(`高分首見樣本 ${first.size} 個，可驗證 ${ready.length} 個（需滿51h）`);
if (!ready.length) process.exit(0);

const cache = fs.existsSync(CACHE) ? JSON.parse(fs.readFileSync(CACHE, "utf8")) : {};
async function ohlcv(pair) {
  if (cache[pair]) return cache[pair];
  try {
    const r = await fetch(`https://api.geckoterminal.com/api/v2/networks/solana/pools/${pair}/ohlcv/hour?aggregate=1&limit=300`);
    if (!r.ok) throw 0;
    const d = await r.json();
    cache[pair] = ((d.data || {}).attributes || {}).ohlcv_list || [];
  } catch (e) { cache[pair] = []; }
  return cache[pair];
}

const strat = { T0: [], T1h: [], T3h: [], DIP15: [] };
let i = 0;
for (const c of ready) {
  process.stdout.write(`\r${++i}/${ready.length}`);
  const t0 = Date.parse(c[col.time]);
  const rowsK = (await ohlcv(c[col.pairAddress])).slice().sort((a, b) => a[0] - b[0]);
  if (i % 4 === 0) { fs.writeFileSync(CACHE, JSON.stringify(cache)); await new Promise(r => setTimeout(r, 1000)); }
  const after = rowsK.filter(k => k[0] * 1000 >= t0 - 36e5);
  if (after.length < 6) continue;
  const px = t => { const k = after.find(k => k[0] * 1000 >= t); return k ? parseFloat(k[1]) : 0; }; // 該時點開盤價
  const evalEntry = (entryT, entryP) => {
    if (!entryP) return null;
    const win = after.filter(k => k[0] * 1000 >= entryT && k[0] * 1000 <= entryT + 48 * 36e5);
    if (win.length < 3) return null;
    let peak = 0, last = 0;
    for (const k of win) { peak = Math.max(peak, parseFloat(k[2]) || 0); last = parseFloat(k[4]) || last; }
    return { pm: peak / entryP, dead: last / entryP <= 0.3 };
  };
  const p0 = px(t0);
  const r0 = evalEntry(t0, p0); if (r0) strat.T0.push(r0);
  const r1 = evalEntry(t0 + 1 * 36e5, px(t0 + 1 * 36e5)); if (r1) strat.T1h.push(r1);
  const r3 = evalEntry(t0 + 3 * 36e5, px(t0 + 3 * 36e5)); if (r3) strat.T3h.push(r3);
  // DIP15：訊號後3小時內任一小時K最低價觸及 p0×0.85 → 以該價進場
  if (p0) {
    const w3 = after.filter(k => k[0] * 1000 >= t0 && k[0] * 1000 <= t0 + 3 * 36e5);
    const hit = w3.find(k => (parseFloat(k[3]) || 9e9) <= p0 * 0.85);
    if (hit) { const rd = evalEntry(hit[0] * 1000, p0 * 0.85); if (rd) strat.DIP15.push(rd); }
    else strat.DIP15.push({ pm: 1, dead: false, skip: true }); // 沒觸到=不進場，記為中性
  }
}
fs.writeFileSync(CACHE, JSON.stringify(cache));
console.log("\n\n═══ 進場時機對決（進場後48h窗）═══");
console.log("策略    | 樣本 | 平均峰值 | ≥2x率 | 陣亡率 | 備註");
for (const [k, arr] of Object.entries(strat)) {
  if (!arr.length) continue;
  const act = arr.filter(x => !x.skip);
  const avg = act.length ? act.reduce((a, x) => a + x.pm, 0) / act.length : 0;
  const p2 = act.length ? act.filter(x => x.pm >= 2).length / act.length * 100 : 0;
  const dd = act.length ? act.filter(x => x.dead).length / act.length * 100 : 0;
  const skip = arr.filter(x => x.skip).length;
  console.log(`${k.padEnd(7)} | ${String(act.length).padStart(3)}  | ×${avg.toFixed(2)}   | ${p2.toFixed(0)}%  | ${dd.toFixed(0)}%  | ${skip ? "未觸價跳過" + skip + "次" : ""}`);
}
console.log("\n判讀：哪個策略的平均峰值高＋陣亡率低 → 就是新進場機制的依據");
