// ═══════════════════════════════════════════════
// broker.js — 成交執行層
//   paper：模擬成交（含滑點與手續費，貼近真實）
//   live ：Jupiter v6 真實下單（僅在 mode=live 時載入依賴）
// ═══════════════════════════════════════════════
const WSOL = "So11111111111111111111111111111111111111112";

export function makeBroker(cfg, log) {
  if (cfg.mode === "live") return liveBroker(cfg, log);
  return paperBroker(cfg, log);
}

/* ────────── 模擬盤 ────────── */
function paperBroker(cfg, log) {
  return {
    kind: "paper",
    // 買入：以現價加滑點成交，回傳實際取得的代幣數量
    async buy(addr, priceUsd, solUsd, sizeSOL) {
      const fillPrice = priceUsd * (1 + cfg.slippagePct / 100);
      const usd = (sizeSOL - cfg.feeSOLPerTrade) * solUsd;
      const qty = usd / fillPrice;
      log(`[模擬買入] ${addr.slice(0, 6)}… ${sizeSOL} SOL @ $${fillPrice.toPrecision(4)}（含滑點${cfg.slippagePct}%）`);
      return { fillPrice, qty, costSOL: sizeSOL };
    },
    // 賣出：以現價減滑點成交，回傳取回的 SOL
    async sell(addr, priceUsd, solUsd, qty) {
      const fillPrice = priceUsd * (1 - cfg.slippagePct / 100);
      const solOut = (qty * fillPrice) / solUsd - cfg.feeSOLPerTrade;
      log(`[模擬賣出] ${addr.slice(0, 6)}… qty=${qty.toPrecision(5)} @ $${fillPrice.toPrecision(4)}`);
      return { fillPrice, solOut: Math.max(0, solOut) };
    },
  };
}

/* ────────── 實盤（Jupiter v6）────────── */
function liveBroker(cfg, log) {
  let ready = null;
  async function setup() {
    if (ready) return ready;
    ready = (async () => {
      const { Connection, Keypair, VersionedTransaction } = await import("@solana/web3.js");
      const bs58 = (await import("bs58")).default;
      const fs = await import("fs");
      const key = fs.readFileSync(cfg.live.privateKeyFile, "utf8").trim();
      const kp = Keypair.fromSecretKey(bs58.decode(key));
      const conn = new Connection(cfg.live.rpcUrl, "confirmed");
      log(`[實盤] 錢包 ${kp.publicKey.toBase58()} 已載入 — 請確認這是小額燒錢包！`);
      return { conn, kp, VersionedTransaction };
    })();
    return ready;
  }

  async function jupSwap(inputMint, outputMint, amountRaw, slippageBps) {
    const { conn, kp, VersionedTransaction } = await setup();
    const q = await (await fetch(
      `https://quote-api.jup.ag/v6/quote?inputMint=${inputMint}&outputMint=${outputMint}` +
      `&amount=${amountRaw}&slippageBps=${slippageBps}`
    )).json();
    if (!q || q.error) throw new Error("Jupiter 報價失敗: " + (q && q.error));
    const sw = await (await fetch("https://quote-api.jup.ag/v6/swap", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ quoteResponse: q, userPublicKey: kp.publicKey.toBase58(), wrapAndUnwrapSol: true }),
    })).json();
    if (!sw || !sw.swapTransaction) throw new Error("Jupiter 組單失敗");
    const tx = VersionedTransaction.deserialize(Buffer.from(sw.swapTransaction, "base64"));
    tx.sign([kp]);
    const sig = await conn.sendRawTransaction(tx.serialize(), { maxRetries: 3 });
    await conn.confirmTransaction(sig, "confirmed");
    return { sig, outAmount: Number(q.outAmount) };
  }

  return {
    kind: "live",
    async buy(addr, priceUsd, solUsd, sizeSOL) {
      const lamports = Math.floor(sizeSOL * 1e9);
      const r = await jupSwap(WSOL, addr, lamports, cfg.slippagePct * 100);
      log(`[實盤買入] ${addr.slice(0, 6)}… ${sizeSOL} SOL tx=${r.sig}`);
      // 注意：實際數量為鏈上回傳，decimals 由 Jupiter quote 處理（outAmount 為最小單位）
      return { fillPrice: priceUsd, qty: r.outAmount, costSOL: sizeSOL, sig: r.sig, rawQty: true };
    },
    async sell(addr, priceUsd, solUsd, qty) {
      const r = await jupSwap(addr, WSOL, Math.floor(qty), cfg.slippagePct * 100);
      const solOut = r.outAmount / 1e9;
      log(`[實盤賣出] ${addr.slice(0, 6)}… tx=${r.sig} 取回 ${solOut.toFixed(4)} SOL`);
      return { fillPrice: priceUsd, solOut };
    },
  };
}
