// ═══════════════════════════════════════════════
// analyze.js — 對答案：特徵快照 vs 之後的真實走勢
// 用法：node src/analyze.js [觀察窗小時,預設72] [最多驗證樣本數,預設120]
// 需要 research.csv 累積至少 24 小時以上的紀錄
// ═══════════════════════════════════════════════
import fs from "fs";

const WINDOW_H = parseInt(process.argv[2]) || 72;   // 快照後觀察多久
const MAX_SAMPLES = parseInt(process.argv[3]) || 120;
const CSV = "data/research.csv";
const CACHE = "data/outcome_cache.json";

if (!fs.existsSync(CSV)) { console.log("找不到 data/research.csv — 先讓機器人跑一陣子"); process.exit(0); }

const lines = fs.readFileSync(CSV, "utf8").trim().split("\n");
const header = lines[0].split(",");
const col = Object.fromEntries(header.map((h, i) => [h, i]));
const rows = lines.slice(1).map(l => l.split(","));

// 每個代幣取「最早的一筆快照」當作觀測起點（避免同幣重複計入）
const first = new Map();
for (const r of rows) {
  const addr = r[col.addr];
  if (!first.has(addr)) first.set(addr, r);
}
const now = Date.now();
// 只驗證「快照已滿觀察窗」的樣本（答案已經揭曉的）
const ready = [...first.values()].filter(r => now - Date.parse(r[col.time]) >= WINDOW_H * 36e5);
console.log(`快照代幣 ${first.size} 個，其中 ${ready.length} 個已滿 ${WINDOW_H}h 觀察窗`);
if (!ready.length) { console.log("尚無可驗證樣本，再等等。"); process.exit(0); }

const cache = fs.existsSync(CACHE) ? JSON.parse(fs.readFileSync(CACHE, "utf8")) : {};

async function peakAfter(pairAddr, sinceMs) {
  const key = pairAddr + ":" + sinceMs + ":" + WINDOW_H;
  if (cache[key] !== undefined) return cache[key];
  try {
    const r = await fetch(`https://api.geckoterminal.com/api/v2/networks/solana/pools/${pairAddr}/ohlcv/hour?aggregate=1&limit=500`);
    if (!r.ok) throw new Error("HTTP " + r.status);
    const d = await r.json();
    const list = (d.data && d.data.attributes && d.data.attributes.ohlcv_list) || [];
    let peak = 0, last = 0;
    for (const row of list) {
      const t = row[0] * 1000;
      if (t >= sinceMs && t <= sinceMs + WINDOW_H * 36e5) {
        peak = Math.max(peak, parseFloat(row[2]) || 0);
        last = parseFloat(row[4]) || last;
      }
    }
    cache[key] = { peak, last };
  } catch (e) { cache[key] = null; }
  return cache[key];
}

const samples = [];
const targets = ready.slice(0, MAX_SAMPLES);
let i = 0;
for (const r of targets) {
  process.stdout.write(`\r取回走勢 ${++i}/${targets.length}…`);
  const pair = r[col.pairAddress];
  const px = parseFloat(r[col.price]);
  if (!pair || !px) continue;
  const out = await peakAfter(pair, Date.parse(r[col.time]));
  if (i % 4 === 0) { fs.writeFileSync(CACHE, JSON.stringify(cache)); await new Promise(s => setTimeout(s, 1200)); }
  if (!out || !out.peak) { samples.push({ r, peakX: 0, dead: true }); continue; } // 抓不到K線多半=池已死
  samples.push({ r, peakX: out.peak / px, lastX: (out.last || 0) / px, dead: (out.last || 0) / px <= 0.3 });
}
fs.writeFileSync(CACHE, JSON.stringify(cache));
console.log(`\n有效樣本 ${samples.length} 個\n`);

// ── 分數分桶 → 命中率 ──
const buckets = [[0, 50], [50, 64], [64, 78], [78, 101]];
console.log("═══ 分數 vs 結果（觀察窗 " + WINDOW_H + "h）═══");
console.log("分數區間 | 樣本 | ≥5x | ≥2x | 陣亡(≤-70%)");
for (const [lo, hi] of buckets) {
  const g = samples.filter(s => +s.r[col.score] >= lo && +s.r[col.score] < hi);
  if (!g.length) continue;
  const p = f => (g.filter(f).length / g.length * 100).toFixed(0) + "%";
  console.log(`${String(lo).padStart(3)}–${hi - 1}   | ${String(g.length).padStart(3)}  | ${p(s => s.peakX >= 5)} | ${p(s => s.peakX >= 2)} | ${p(s => s.dead)}`);
}

// ── 各維度預測力：贏家(峰值≥2x) vs 輸家 的平均維度分差 ──
console.log("\n═══ 各維度預測力（贏家均分 − 輸家均分，越大越有用）═══");
const dims = ["mcapDim", "liqDim", "turnDim", "buyDim", "momDim", "ageDim", "boostDim"];
const win = samples.filter(s => s.peakX >= 2), lose = samples.filter(s => s.peakX < 2);
if (win.length >= 5 && lose.length >= 5) {
  const avg = (g, d) => g.reduce((a, s) => a + (+s.r[col[d]] || 0), 0) / g.length;
  const out = dims.map(d => ({ d, diff: avg(win, d) - avg(lose, d) })).sort((a, b) => b.diff - a.diff);
  for (const o of out) console.log(`${o.d.padEnd(9)} ${o.diff >= 0 ? "+" : ""}${o.diff.toFixed(2)}`);
  console.log("\n判讀：分差明顯為正 → 該維度有效；接近 0 或為負 → 該維度在此市場環境沒有預測力，可考慮降權。");
} else {
  console.log("贏家/輸家樣本尚不足（各需≥5），繼續累積。");
}
console.log(`\n贏家(峰值≥2x): ${win.length} | 輸家: ${lose.length} | 全體平均峰值: ×${(samples.reduce((a, s) => a + s.peakX, 0) / samples.length).toFixed(2)}`);
