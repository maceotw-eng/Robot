# SOL 迷因幣自動交易機器人 v1.2

**版本紀錄**
- v1.0 六維評分策略 + 四層出場 + 熔斷 + 模擬/實盤雙模式
- v1.1 流動性抽乾預警（慢刀 rug 逃生）
- v1.2 研究記錄器（research.csv 全樣本快照）+ 對答案分析器（analyze.js）

六維評分策略（與「SOL 迷因雷達」網頁版同源）＋ RugCheck 安全閘門 ＋ 四層出場機制 ＋ 熔斷保護。
**預設模擬盤（paper）**：用真實市場訊號跑假錢，交易全程記帳，先驗證再上實盤。

---

## 一、策略總覽

**進場（全部條件同時成立才買）**
- 六維評分 ≥ 78（S 級）
- 流動性 ≥ $40K、市值 ≤ $15M、24H 交易 ≥ 300 筆
- 1H 買單占比 ≥ 55%、24H 漲幅 ≤ 200%（不追高）
- RugCheck：零高危風險項、前 10 大持倉 ≤ 45%
- 未持倉、不在黑名單（停損過的幣永不回頭）

**出場（四層，依序檢查）**
1. **硬停損** −40% → 全出
2. **停利一段** +100% → 賣一半，剩下讓利潤跑（這是抓 5x 的關鍵：不會 +100% 就全跑掉）
3. **移動停損** 從峰值回落 30% → 剩餘全出（鎖住利潤）
4. **時間停損** 持有 48 小時仍 <+20% → 換標的

**帳戶保護**
- 單筆 0.05 SOL、最多同時 5 倉、每日最多 10 筆
- 當日虧 0.15 SOL → 今日熔斷；累計虧 0.4 SOL → 總熔斷停機
- 所有參數都在 `config.json` 可調

---

## 二、本機試跑（模擬盤）

需求：Node.js 18 以上

```bash
cd sol-meme-bot
cp config.example.json config.json
npm install            # 模擬盤其實不需依賴，裝了實盤才用得到
npm run paper          # 啟動模擬盤
```

畫面會即時顯示掃描、進出場與 PnL。交易明細寫入 `data/ledger.csv`（可用 Excel 開），
隨時 `npm run report` 看績效摘要。Ctrl+C 停止，狀態自動保存，重啟不掉單。

---

## 三、VPS 部署（24 小時運行）

任何最低規格 VPS 都夠（1 vCPU / 1GB RAM，月租 $4–6 美元，如 Vultr、DigitalOcean、Linode、Contabo）。

```bash
# 1. 建立 Ubuntu 22.04+ VPS，SSH 登入後安裝 Node
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 2. 上傳專案（本機執行）
scp -r sol-meme-bot root@你的VPS_IP:~/

# 3. VPS 上啟動並常駐（pm2 開機自啟、當機自動重啟）
cd ~/sol-meme-bot
cp config.example.json config.json
npm install
sudo npm install -g pm2
pm2 start src/index.js --name memebot
pm2 save && pm2 startup     # 照它印出的指令執行一次

# 日常操作
pm2 logs memebot     # 看即時日誌
pm2 restart memebot  # 改完 config 後重啟
node src/report.js   # 績效報表
```

---

## 四、切換實盤前的檢查清單（重要）

**先跑模擬盤至少 7–14 天**，`node src/report.js` 確認：
- [ ] 勝率與總 PnL 為正（或至少虧損在滑點解釋範圍內）
- [ ] 沒有大量「查無報價緊急出場」（代表 rug 閘門有效）
- [ ] 熔斷從未觸發，或觸發後你已據此調整參數

**確認合格後才做以下步驟：**
1. 用 Phantom **新建一個燒錢包**（不是你的主錢包！）
2. 匯出該錢包私鑰（base58 字串），在 VPS 上建立檔案：
   ```bash
   nano ~/sol-meme-bot/wallet.key    # 貼上私鑰，存檔
   chmod 600 wallet.key              # 只有你能讀
   ```
3. 轉入小額 SOL（建議 ≤ 0.5 SOL 起步）
4. `config.json` 改 `"mode": "live"`，`pm2 restart memebot`

**安全鐵律**
- 私鑰只存在於你的 VPS 的 `wallet.key`，不進 git（.gitignore 已擋）、不貼給任何人、不貼進任何對話
- 錢包裡永遠只放「全損也不痛」的金額——這就是你的真實最大風險
- RPC 建議換免費註冊的 Helius / QuickNode 端點（公共 RPC 實盤下單容易失敗）

---

## 五、誠實的風險聲明

模擬盤與實盤存在無法完全模擬的落差：真實滑點在池淺時可能遠超 5%、
新幣搶單搶不過付高額小費的狙擊 bot、極端行情下停損單成交價會更差。
模擬盤數據合格只代表「策略邏輯有篩選力」，不代表實盤必然獲利。
迷因幣可能歸零，本專案不構成投資建議，請自行承擔風險。
