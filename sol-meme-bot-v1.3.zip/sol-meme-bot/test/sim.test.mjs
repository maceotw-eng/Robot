// 離線模擬測試：node test/sim.test.mjs
import { scoreToken } from "../src/scanner.js";
import { shouldEnter, shouldExit, circuitBroken } from "../src/strategy.js";
import fs from "fs";
const cfg = JSON.parse(fs.readFileSync("config.example.json", "utf8"));
let fails = 0;
const T = (name, cond) => { console.log(cond ? "✓" : "✗ FAIL", name); if (!cond) fails++; };
const strong = { marketCap: 2e6, liquidity: { usd: 200e3 }, volume: { h24: 4e6, h6: 2e6 },
  priceChange: { m5: 1, h1: 6, h6: 15, h24: 45 },
  txns: { h24: { buys: 4000, sells: 2500 }, h1: { buys: 400, sells: 200 } },
  pairCreatedAt: Date.now() - 48 * 36e5, baseToken: { address: "AAA" }, priceUsd: "0.001" };
const ts = scoreToken(strong);
T("強勢幣高分", ts.score >= 78);
const state = { positions: [], ledger: [], blacklist: [] };
T("進場閘門通過", shouldEnter(ts, strong, cfg, state).ok);
const pos = { entryPrice: 0.001, peak: 0.001, openedAt: Date.now() - 2*36e5, tp1Done: false };
T("停利1段", (shouldExit(pos, 0.0021, cfg) || {}).markTp1 === true);
T("硬停損", (shouldExit({entryPrice:0.001,peak:0.001,openedAt:Date.now()}, 0.00055, cfg) || {}).ratio === 1);
T("熔斷", circuitBroken({ ledger: [{ time: new Date().toISOString(), side: "sell", pnlSOL: -0.2 }] }, cfg) !== null);
const posL = { entryPrice: 0.001, peak: 0.001, openedAt: Date.now(), entryLiq: 100000 };
const drain = shouldExit(posL, 0.00095, cfg, 50000); // 池從100K萎縮到50K = -50%
T("流動性抽乾預警觸發", drain && drain.ratio === 1 && drain.why.includes("流動性"));
T("池健康時不誤觸", shouldExit(posL, 0.00105, cfg, 95000) === null);
console.log(fails === 0 ? "══ 通過 ══" : "有失敗"); process.exit(fails ? 1 : 0);
