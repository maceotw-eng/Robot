// 一次性設定：node src/tg_setup.js <BOT_TOKEN>
// 前置：先在 Telegram 裡對你的 bot 按 Start 或傳任意訊息
import fs from "fs";
const token = process.argv[2];
if (!token) { console.log("用法: node src/tg_setup.js <BOT_TOKEN>"); process.exit(1); }
const r = await fetch(`https://api.telegram.org/bot${token}/getUpdates`);
const d = await r.json();
if (!d.ok) { console.log("Token 無效或 API 錯誤:", JSON.stringify(d)); process.exit(1); }
const msgs = (d.result || []).filter(u => u.message && u.message.chat);
if (!msgs.length) {
  console.log("❌ 還沒收到你的訊息。請先在 Telegram 打開你的 bot、按 Start（或隨便傳一句話），再重跑本指令。");
  process.exit(1);
}
const chat = msgs[msgs.length - 1].message.chat;
const cfg = JSON.parse(fs.readFileSync("config.json", "utf8"));
cfg.tg = { token, chatId: chat.id };
fs.writeFileSync("config.json", JSON.stringify(cfg, null, 2));
await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
  method: "POST", headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ chat_id: chat.id, text: "✅ 迷因機器人推播已連線！\n之後進出場、畢業生、熔斷警報都會推到這裡。" })
});
console.log(`✅ 設定完成，chatId=${chat.id}（${chat.first_name || chat.title || ""}），測試訊息已發送`);
