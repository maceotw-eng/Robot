// ═══════════════════════════════════════════════
// nursery.js — 新幣育嬰房（第三層：鏈上出生監聽 + 倖存者篩選）
// 原理：接 PumpPortal 免費 WebSocket，每個新幣出生即建檔；
//       出生後 1h / 3h / 6h 回訪體檢（DexScreener 查流動性/交易）；
//       6h 體檢及格 = 倖存者 → 寫入 graduates.csv（畢業生名單）
// 大多數 rug 發生在頭幾小時 → 讓時間當第一道濾網。
// pm2 start src/nursery.js --name nursery
// ═══════════════════════════════════════════════
import fs from "fs";
import WebSocket from "ws";
import { notify } from "./notify.js";

const STATE = "data/nursery_state.json";
const GRADS = "data/graduates.csv";
const CHECK_MIN = 10;          // 每10分鐘巡一次體檢排程
const MAX_BABIES = 600;        // 名單上限（防記憶體膨脹）
const SURVIVE = { liq: 25000, txns: 150 }; // 6h 畢業標準

fs.mkdirSync("data", { recursive: true });
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);

let S = { bornTotal: 0, babies: [] };
try { S = JSON.parse(fs.readFileSync(STATE, "utf8")); } catch (e) {}
const save = () => fs.writeFileSync(STATE, JSON.stringify(S));

/* ── 出生監聽（PumpPortal） ── */
function connect() {
  const ws = new WebSocket("wss://pumpportal.fun/api/data");
  ws.on("open", () => {
    ws.send(JSON.stringify({ method: "subscribeNewToken" }));
    log("已連線 PumpPortal，監聽新幣出生…");
  });
  ws.on("message", raw => {
    try {
      const d = JSON.parse(raw);
      if (!d.mint || d.txType !== "create") return;
      S.bornTotal++;
      S.babies.push({
        mint: d.mint,
        sym: (d.symbol || "?").slice(0, 12).replace(/,/g, ";"),
        name: (d.name || "").slice(0, 24).replace(/,/g, ";"),
        born: Date.now(),
        initSol: parseFloat(d.solAmount) || 0,
        checks: {}, done: false
      });
      if (S.babies.length > MAX_BABIES) {
        // 先丟已完成的最舊者，不夠再丟最舊的
        const i = S.babies.findIndex(b => b.done);
        S.babies.splice(i >= 0 ? i : 0, 1);
      }
      if (S.bornTotal % 20 === 0) { save(); log(`出生累計 ${S.bornTotal}（觀察中 ${S.babies.filter(b=>!b.done).length}）`); }
    } catch (e) {}
  });
  ws.on("close", () => { log("連線中斷，10秒後重連"); setTimeout(connect, 10000); });
  ws.on("error", () => ws.close());
}

/* ── 體檢：DexScreener 批次查詢 ── */
async function quotes(mints) {
  const map = new Map();
  for (let i = 0; i < mints.length; i += 30) {
    try {
      const r = await fetch("https://api.dexscreener.com/latest/dex/tokens/" + mints.slice(i, i + 30).join(","));
      if (!r.ok) continue;
      const d = await r.json();
      for (const p of (d.pairs || [])) {
        if (p.chainId !== "solana") continue;
        const a = p.baseToken && p.baseToken.address;
        const liq = (p.liquidity && p.liquidity.usd) || 0;
        const prev = map.get(a);
        if (!prev || liq > prev.liq) map.set(a, {
          liq, price: parseFloat(p.priceUsd) || 0,
          mcap: p.marketCap || p.fdv || 0,
          t24: ((p.txns||{}).h24 ? (p.txns.h24.buys||0)+(p.txns.h24.sells||0) : 0),
          vol: (p.volume||{}).h24 || 0
        });
      }
    } catch (e) {}
    await new Promise(r => setTimeout(r, 400));
  }
  return map;
}

async function checkup() {
  const now = Date.now();
  const due = [];
  for (const b of S.babies) {
    if (b.done) continue;
    const age = (now - b.born) / 36e5;
    if (age >= 1 && !b.checks.h1) due.push([b, "h1"]);
    else if (age >= 3 && !b.checks.h3) due.push([b, "h3"]);
    else if (age >= 6 && !b.checks.h6) due.push([b, "h6"]);
  }
  if (!due.length) return;
  const q = await quotes([...new Set(due.map(([b]) => b.mint))]);
  let grads = 0;
  for (const [b, stage] of due) {
    const info = q.get(b.mint) || { liq: 0, price: 0, mcap: 0, t24: 0, vol: 0 };
    b.checks[stage] = { t: now, ...info };
    if (stage === "h6") {
      b.done = true;
      const pass = info.liq >= SURVIVE.liq && info.t24 >= SURVIVE.txns;
      if (pass) {
        grads++;
        if (!fs.existsSync(GRADS)) fs.writeFileSync(GRADS, "gradTime,symbol,mint,liqUsd,mcapUsd,txns24,vol24,h1liq,initSol\n");
        fs.appendFileSync(GRADS, [new Date().toISOString(), b.sym, b.mint, Math.round(info.liq),
          Math.round(info.mcap), info.t24, Math.round(info.vol),
          Math.round((b.checks.h1 || {}).liq || 0), b.initSol].join(",") + "\n");
        log(`🎓 畢業生 ${b.sym}  LIQ $${(info.liq/1e3).toFixed(0)}K  MC $${(info.mcap/1e3).toFixed(0)}K  txns ${info.t24}`);
        notify(`🎓 育嬰房畢業生：${b.sym}\nLIQ $${(info.liq/1e3).toFixed(0)}K | MC $${(info.mcap/1e3).toFixed(0)}K | 24h交易 ${info.t24}\n${b.mint}`);
      }
    }
  }
  save();
  const alive = S.babies.filter(b => !b.done).length;
  log(`體檢 ${due.length} 名 | 本輪畢業 ${grads} | 觀察中 ${alive} | 出生累計 ${S.bornTotal}`);
}

connect();
setInterval(checkup, CHECK_MIN * 60 * 1000);
setInterval(save, 5 * 60 * 1000);
log("育嬰房啟動 | 體檢排程 1h/3h/6h | 畢業標準 LIQ≥$" + SURVIVE.liq/1000 + "K + 24h交易≥" + SURVIVE.txns);
