// 共用推播模組：讀 config.json 的 tg 設定，未設定則靜默跳過
import fs from "fs";
let c = null;
function conf() {
  if (c) return c;
  try { c = (JSON.parse(fs.readFileSync("config.json", "utf8")).tg) || null; } catch (e) { c = null; }
  return c;
}
export async function notify(text) {
  const t = conf();
  if (!t || !t.token || !t.chatId) return;
  try {
    await fetch(`https://api.telegram.org/bot${t.token}/sendMessage`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: t.chatId, text, disable_web_page_preview: true })
    });
  } catch (e) {}
}
