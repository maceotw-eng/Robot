// ═══════════════════════════════════════════════
// index.js — 主迴圈：掃描 → 進場閘門 → 持倉管理 → 記帳
// 預設模擬盤。實盤請先看 README 的切換條件。
// ═══════════════════════════════════════════════
import fs from "fs";
import path from "path";
import { collectPairs, scoreToken, fetchQuotes } from "./scanner.js";
import { rugGate, shouldEnter, shouldExit, circuitBroken } from "./strategy.js";
import { makeBroker } from "./broker.js";
import { notify } from "./notify.js";

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const CFG_PATH = path.join(ROOT, "config.json");
const STATE_PATH = path.join(ROOT, "data", "state.json");
const LEDGER_CSV = path.join(ROOT, "data", "ledger.csv");
const RESEARCH_CSV = path.join(ROOT, "data", "research.csv");

if (!fs.existsSync(CFG_PATH)) {
  console.error("找不到 config.json — 請先執行: cp config.example.json config.json");
  process.exit(1);
}
const cfg = JSON.parse(fs.readFileSync(CFG_PATH, "utf8"));
fs.mkdirSync(path.join(ROOT, "data"), { recursive: true });

const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);

/* ── 狀態持久化（重啟不掉單）── */
function loadState() {
  try { return JSON.parse(fs.readFileSync(STATE_PATH, "utf8")); }
  catch (e) { return { positions: [], ledger: [], blacklist: [], tradesToday: {}, solUsd: 0 }; }
}
function saveState(s) { fs.writeFileSync(STATE_PATH, JSON.stringify(s, null, 2)); }
function appendCsv(row) {
  if (!fs.existsSync(LEDGER_CSV)) {
    fs.writeFileSync(LEDGER_CSV, "time,side,symbol,addr,price,qty,sol,pnlSOL,why\n");
  }
  fs.appendFileSync(LEDGER_CSV, row.map(v => String(v).replace(/,/g, ";")).join(",") + "\n");
}

const state = loadState();
const broker = makeBroker(cfg, log);

if (cfg.mode === "live") {
  log("⚠️⚠️⚠️ 實盤模式 — 真金白銀。錢包內請只放可全損的小額 SOL。⚠️⚠️⚠️");
} else {
  log("📋 模擬盤模式 — 假錢真訊號，交易照樣記帳供驗證。");
}

/* ── SOL 現價（換算倉位）── */
async function refreshSolPrice() {
  try {
    const d = await (await fetch("https://api.dexscreener.com/latest/dex/tokens/So11111111111111111111111111111111111111112")).json();
    const p = (d.pairs || []).find(x => x.chainId === "solana" && parseFloat(x.priceUsd) > 10);
    if (p) state.solUsd = parseFloat(p.priceUsd);
  } catch (e) {}
  if (!state.solUsd) state.solUsd = 150; // 後備值
}

/* ── 進場流程 ── */
async function tryEnter(candidates) {
  const today = new Date().toISOString().slice(0, 10);
  state.tradesToday[today] = state.tradesToday[today] || 0;
  const openN = state.positions.filter(p => p.status === "open").length;

  for (const c of candidates) {
    if (state.positions.filter(p => p.status === "open").length >= cfg.maxOpenPositions) return;
    if (state.tradesToday[today] >= cfg.maxTradesPerDay) { log("已達每日交易上限"); return; }

    const gate = shouldEnter(c.t, c.pair, cfg, state);
    if (!gate.ok) continue;

    const addr = c.pair.baseToken.address;
    const rug = await rugGate(addr, cfg.entry.rugcheck);
    if (!rug.pass) { log(`❌ ${c.pair.baseToken.symbol} RugCheck 拒絕: ${rug.reason}`); continue; }

    const price = parseFloat(c.pair.priceUsd) || 0;
    if (!price) continue;
    try {
      const fill = await broker.buy(addr, price, state.solUsd, cfg.positionSizeSOL);
      state.positions.push({
        addr, pairAddress: c.pair.pairAddress || "",
        symbol: c.pair.baseToken.symbol || "?",
        entryPrice: fill.fillPrice, qty: fill.qty, rawQty: !!fill.rawQty,
        costSOL: fill.costSOL, peak: fill.fillPrice,
        entryLiq: c.t.liq,
        openedAt: Date.now(), status: "open", tp1Done: false,
        entryScore: c.t.score,
      });
      state.tradesToday[today]++;
      state.ledger.push({ time: new Date().toISOString(), side: "buy", symbol: c.pair.baseToken.symbol, addr, price: fill.fillPrice, sol: -fill.costSOL, why: `分數${c.t.score} ${gate.why}` });
      appendCsv([new Date().toISOString(), "buy", c.pair.baseToken.symbol, addr, fill.fillPrice, fill.qty, -fill.costSOL, "", `score=${c.t.score}`]);
      log(`✅ 進場 ${c.pair.baseToken.symbol} 分數${c.t.score} @ $${fill.fillPrice.toPrecision(4)}`);
      notify(`✅ 進場 ${c.pair.baseToken.symbol}\n分數 ${c.t.score} | ${cfg.positionSizeSOL} SOL @ $${fill.fillPrice.toPrecision(4)}\n模式 ${cfg.mode}`);
      saveState(state);
    } catch (e) { log(`買入失敗 ${c.pair.baseToken.symbol}: ${e.message}`); }
  }
}

/* ── 持倉管理 ── */
async function managePositions() {
  const open = state.positions.filter(p => p.status === "open");
  if (!open.length) return;
  const quotes = await fetchQuotes(open.map(p => p.addr));
  for (const pos of open) {
    const q = quotes.get(pos.addr) || { price: 0, liq: 0 };
    const cur = q.price;
    const decision = shouldExit(pos, cur, cfg, q.liq);
    if (!decision) continue;
    try {
      const sellQty = pos.qty * decision.ratio;
      const r = await broker.sell(pos.addr, cur || pos.entryPrice * 0.01, state.solUsd, sellQty);
      const costPortion = pos.costSOL * decision.ratio;
      const pnl = r.solOut - costPortion;
      pos.qty -= sellQty;
      pos.costSOL -= costPortion;
      if (decision.markTp1) pos.tp1Done = true;
      if (decision.ratio >= 1 || pos.qty <= 0) {
        pos.status = "closed";
        if (pnl < 0) state.blacklist.push(pos.addr); // 停損過的不再碰
      }
      state.ledger.push({ time: new Date().toISOString(), side: "sell", symbol: pos.symbol, addr: pos.addr, price: cur, sol: r.solOut, pnlSOL: pnl, why: decision.why });
      appendCsv([new Date().toISOString(), "sell", pos.symbol, pos.addr, cur, sellQty, r.solOut, pnl.toFixed(4), decision.why]);
      log(`${pnl >= 0 ? "🟢" : "🔴"} 出場 ${pos.symbol} ${decision.why} PnL ${pnl.toFixed(4)} SOL`);
      notify(`${pnl >= 0 ? "🟢" : "🔴"} 出場 ${pos.symbol}\n${decision.why}\nPnL ${pnl >= 0 ? "+" : ""}${pnl.toFixed(4)} SOL`);
      saveState(state);
    } catch (e) { log(`賣出失敗 ${pos.symbol}: ${e.message}`); }
  }
}

/* ── 主迴圈 ── */
let stopped = false;
async function tick() {
  if (stopped) return;
  const broken = circuitBroken(state, cfg);
  if (broken) { log("🛑 " + broken); notify("🛑 熔斷停機\n" + broken); stopped = true; return; }

  try {
    await refreshSolPrice();
    await managePositions(); // 先顧持倉（出場優先於進場）

    const { pairs, boostMap } = await collectPairs();
    const scored = pairs
      .map(p => ({ pair: p, t: scoreToken(p, boostMap[p.baseToken.address] || 0) }))
      .filter(c => c.t.mcap > 0)
      .sort((a, b) => b.t.score - a.t.score);
    logResearch(scored); // 研究記錄器：全樣本寫檔，供 analyze.js 事後對答案
    log(`掃描 ${scored.length} 個代幣 | 最高分 ${scored[0] ? scored[0].t.score : "-"} | 持倉 ${state.positions.filter(p => p.status === "open").length}/${cfg.maxOpenPositions}`);
    await tryEnter(scored.slice(0, 20));
  } catch (e) { log("tick 錯誤:", e.message); }

  printSummary();
}

/* ── 研究記錄器：每次掃描記錄全部代幣的特徵快照 ── */
const seenThisHour = new Map(); // addr → hourKey，避免同一小時重複記錄灌水
function logResearch(scored) {
  if (!fs.existsSync(RESEARCH_CSV)) {
    fs.writeFileSync(RESEARCH_CSV, "time,addr,pairAddress,symbol,price,score,mcap,liq,turnover,br1,br24,t24,h1,h6,h24,ageH,mcapDim,liqDim,turnDim,buyDim,momDim,ageDim,boostDim\n");
  }
  const hourKey = new Date().toISOString().slice(0, 13);
  const rows = [];
  for (const c of scored) {
    const addr = c.pair.baseToken.address;
    if (seenThisHour.get(addr) === hourKey) continue;
    seenThisHour.set(addr, hourKey);
    const t = c.t, d = t.dims || {};
    rows.push([new Date().toISOString(), addr, c.pair.pairAddress || "", (c.pair.baseToken.symbol || "?").replace(/,/g, ";"),
      parseFloat(c.pair.priceUsd) || 0, t.score, Math.round(t.mcap), Math.round(t.liq),
      t.turnover.toFixed(3), t.br1.toFixed(3), t.br24.toFixed(3), t.t24,
      t.h1, t.h6, t.h24, t.ageH == null ? "" : t.ageH.toFixed(1),
      d.mcapDim, d.liqDim, d.turnDim, d.buyDim, d.momDim, d.ageDim, d.boostDim].join(","));
  }
  if (rows.length) fs.appendFileSync(RESEARCH_CSV, rows.join("\n") + "\n");
}

let lastDay = new Date().toISOString().slice(0, 10);
function dailyDigest() {
  const today = new Date().toISOString().slice(0, 10);
  if (today === lastDay) return;
  const y = lastDay; lastDay = today;
  const sells = state.ledger.filter(l => l.side === "sell" && l.time.slice(0, 10) === y);
  const pnl = sells.reduce((a, l) => a + (l.pnlSOL || 0), 0);
  const openN = state.positions.filter(p => p.status === "open").length;
  notify(`📊 ${y} 日報\n出場 ${sells.length} 筆 | 勝 ${sells.filter(l=>(l.pnlSOL||0)>0).length}\n當日PnL ${pnl>=0?"+":""}${pnl.toFixed(4)} SOL\n目前持倉 ${openN} 檔`);
}

function printSummary() {
  dailyDigest();
  const sells = state.ledger.filter(l => l.side === "sell");
  const pnl = sells.reduce((a, l) => a + (l.pnlSOL || 0), 0);
  const wins = sells.filter(l => (l.pnlSOL || 0) > 0).length;
  log(`── 累計: ${sells.length} 筆出場 | 勝 ${wins} | 總PnL ${pnl.toFixed(4)} SOL | 模式 ${cfg.mode} ──`);
}

log(`啟動 SOL 迷因機器人 v1.2 | 掃描間隔 ${cfg.scanIntervalSec}s | 單筆 ${cfg.positionSizeSOL} SOL | 最多 ${cfg.maxOpenPositions} 倉`);
tick();
setInterval(tick, cfg.scanIntervalSec * 1000);

process.on("SIGINT", () => { log("收到停止訊號，保存狀態後退出"); saveState(state); process.exit(0); });
