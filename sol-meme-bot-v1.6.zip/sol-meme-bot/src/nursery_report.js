// 育嬰房統計：node src/nursery_report.js
import fs from "fs";
let S; try { S = JSON.parse(fs.readFileSync("data/nursery_state.json","utf8")); } catch(e){ console.log("育嬰房尚無數據"); process.exit(0); }
const done = S.babies.filter(b => b.done);
const h1ok = S.babies.filter(b => b.checks.h1 && b.checks.h1.liq > 5000).length;
const h1all = S.babies.filter(b => b.checks.h1).length;
console.log("═══ 育嬰房統計 ═══");
console.log("出生累計:", S.bornTotal, "| 觀察中:", S.babies.filter(b=>!b.done).length, "| 已完成6h全檢:", done.length);
if (h1all) console.log("1小時存活率(有池且LIQ>$5K):", (h1ok/h1all*100).toFixed(1) + "%（" + h1ok + "/" + h1all + "）");
if (fs.existsSync("data/graduates.csv")) {
  const g = fs.readFileSync("data/graduates.csv","utf8").trim().split("\n").slice(1);
  console.log("🎓 畢業生累計:", g.length, done.length ? "| 6h畢業率: " + (g.length/done.length*100).toFixed(2) + "%" : "");
  console.log("\n最近畢業生:");
  for (const l of g.slice(-8)) {
    const c = l.split(",");
    console.log(`  ${c[1].padEnd(12)} LIQ $${(c[3]/1e3).toFixed(0)}K  MC $${(c[4]/1e3).toFixed(0)}K  txns ${c[5]}`);
  }
} else console.log("🎓 畢業生: 尚無（等第一批滿6小時）");
console.log("\n判讀: 畢業率預期 <1%。畢業生名單就是「時間濾網篩過的新標的池」，");
console.log("下一步可將 graduates.csv 地址餵進雷達掃描，或人工抽查其後續走勢驗證濾網品質。");
