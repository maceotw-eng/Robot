# 資金費率觀察站 v0.1（純觀察模式）

免帳號、免 API key、不下單。接幣安與 OKX 公開行情 API。

## 功能
- 每小時記錄兩所全部 USDT 永續合約的資金費率 → data/funding_log.csv
- 即時標記「肥肉機會」：年化 ≥30% 的幣種即時寫入 data/fat_log.csv
- report.js 統計：全市場租金中位數、肥肉出現頻率與持續性、Top 幣種排行

## 部署（與 memebot/polyscan 同一台 VPS）
```bash
cd ~
wget -O funding.zip "<GitHub raw 連結>"
unzip funding.zip && cd funding-observer
pm2 start src/index.js --name fundscan
pm2 save
```

## 日常
```bash
node src/report.js                          # 租金統計報表
pm2 logs fundscan --lines 20 --nostream     # 看日誌
```

## 一週後的判讀
- 中位數年化 <5% 且肥肉稀少 → 租金太薄，不配本金
- 中位數 5-10% 且每週有數次肥肉 → 配 $3,000 級驗證
- 肥肉頻繁（每日多次、持續數期）→ 輪動策略有肉，值得寫交易模組
