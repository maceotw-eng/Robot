// ═══════════════════════════════════════════════
// 資金費率觀察站 — 幣安 + OKX 永續合約（純觀察）
// 每小時記錄全市場費率；年化 ≥30% 的「肥肉」即時另記一份
// 免帳號、免 key，只用公開行情端點。
// ═══════════════════════════════════════════════
import fs from "fs";

const SCAN_MIN = 60;              // 每 60 分鐘記錄一輪
const FAT_APR = 30;               // 年化 ≥30% 視為肥肉機會
const CSV = "data/funding_log.csv";
const FAT = "data/fat_log.csv";

fs.mkdirSync("data", { recursive: true });
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);

async function jget(url) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 15000);
  try {
    const r = await fetch(url, { headers: { Accept: "application/json" }, signal: ctrl.signal });
    if (!r.ok) throw new Error("HTTP " + r.status);
    return await r.json();
  } finally { clearTimeout(t); }
}

// ── 幣安：premiumIndex 一次回傳全部 USDT 永續的當前費率 ──
// lastFundingRate = 每 8 小時費率 → 年化 = rate × 3 × 365
async function binanceRates() {
  const d = await jget("https://fapi.binance.com/fapi/v1/premiumIndex");
  const out = [];
  for (const x of Array.isArray(d) ? d : []) {
    if (!x.symbol || !x.symbol.endsWith("USDT")) continue;
    const r = parseFloat(x.lastFundingRate);
    if (!isFinite(r)) continue;
    out.push({ ex: "binance", sym: x.symbol, rate8h: r, apr: r * 3 * 365 * 100 });
  }
  return out;
}

// ── OKX：SWAP tickers 拿清單，逐批抓 funding-rate ──
// OKX 部分合約為 8h 結算，統一以 fundingRate × 3 × 365 估算年化
async function okxRates() {
  const t = await jget("https://www.okx.com/api/v5/public/instruments?instType=SWAP");
  const insts = ((t && t.data) || []).filter(i => i.instId && i.instId.endsWith("-USDT-SWAP")).map(i => i.instId);
  const out = [];
  // 只取前 120 個（依字母序含所有主流），控制請求量
  for (const id of insts.slice(0, 120)) {
    try {
      const d = await jget("https://www.okx.com/api/v5/public/funding-rate?instId=" + id);
      const row = d && d.data && d.data[0];
      const r = row ? parseFloat(row.fundingRate) : NaN;
      if (isFinite(r)) out.push({ ex: "okx", sym: id.replace("-USDT-SWAP", "USDT"), rate8h: r, apr: r * 3 * 365 * 100 });
    } catch (e) {}
    await new Promise(s => setTimeout(s, 120)); // OKX 限流保護
  }
  return out;
}

function appendCsv(path, header, row) {
  if (!fs.existsSync(path)) fs.writeFileSync(path, header + "\n");
  fs.appendFileSync(path, row.join(",") + "\n");
}

let scanning = false;
async function tick() {
  if (scanning) return;
  scanning = true;
  try {
    const now = new Date().toISOString();
    const [bn, ok] = await Promise.all([
      binanceRates().catch(e => { log("幣安失敗:", e.message); return []; }),
      okxRates().catch(e => { log("OKX失敗:", e.message); return []; }),
    ]);
    const all = [...bn, ...ok];
    if (!all.length) { log("兩所皆無數據，本輪跳過"); scanning = false; return; }

    // 全量記錄
    for (const x of all) {
      appendCsv(CSV, "time,exchange,symbol,rate8h,aprPct",
        [now, x.ex, x.sym, x.rate8h.toFixed(6), x.apr.toFixed(2)]);
    }
    // 肥肉即時標記（正費率=空方收租；負得深也記，做多收租的反向機會）
    const fat = all.filter(x => Math.abs(x.apr) >= FAT_APR);
    for (const f of fat) {
      appendCsv(FAT, "time,exchange,symbol,aprPct,side",
        [now, f.ex, f.sym, f.apr.toFixed(2), f.apr > 0 ? "short-collect" : "long-collect"]);
    }
    const aprs = all.map(x => x.apr).sort((a, b) => a - b);
    const med = aprs[Math.floor(aprs.length / 2)];
    const top = [...all].sort((a, b) => b.apr - a.apr)[0];
    log(`記錄 ${all.length} 個合約（幣安${bn.length}/OKX${ok.length}）| 中位年化 ${med.toFixed(1)}% | 最肥 ${top.sym}@${top.ex} ${top.apr.toFixed(0)}% | 肥肉 ${fat.length} 個`);
  } catch (e) { log("tick 錯誤:", e.message); }
  scanning = false;
}

log(`資金費率觀察站啟動（純觀察）| 每 ${SCAN_MIN} 分鐘 | 肥肉門檻 年化≥${FAT_APR}%`);
tick();
setInterval(tick, SCAN_MIN * 60 * 1000);
