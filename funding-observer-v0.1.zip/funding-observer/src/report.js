// 租金統計報表：node src/report.js
import fs from "fs";
const CSV = "data/funding_log.csv", FAT = "data/fat_log.csv";
if (!fs.existsSync(CSV)) { console.log("尚無紀錄（讓 fundscan 先跑幾小時）"); process.exit(0); }
const rows = fs.readFileSync(CSV, "utf8").trim().split("\n").slice(1).map(l => l.split(","));
if (rows.length < 10) { console.log("紀錄太少，再等等"); process.exit(0); }

const hours = (Date.parse(rows[rows.length-1][0]) - Date.parse(rows[0][0])) / 36e5 || 1;
const aprs = rows.map(r => parseFloat(r[4])).filter(isFinite).sort((a,b)=>a-b);
const q = p => aprs[Math.floor(aprs.length * p)];
console.log("═══ 資金費率租金統計 ═══");
console.log(`觀察時長: ${hours.toFixed(1)} 小時 | 紀錄筆數: ${rows.length}`);
console.log(`全市場年化分布: 中位 ${q(0.5).toFixed(1)}% | P25 ${q(0.25).toFixed(1)}% | P75 ${q(0.75).toFixed(1)}% | P95 ${q(0.95).toFixed(1)}%`);

// 主流幣單獨看（套利首選，流動性深爆倉風險低）
for (const s of ["BTCUSDT","ETHUSDT","SOLUSDT"]) {
  const g = rows.filter(r => r[2] === s).map(r => parseFloat(r[4])).filter(isFinite);
  if (g.length) console.log(`${s.padEnd(9)} 平均年化 ${(g.reduce((a,b)=>a+b,0)/g.length).toFixed(1)}%（${g.length} 筆）`);
}

// 肥肉統計
if (fs.existsSync(FAT)) {
  const fat = fs.readFileSync(FAT, "utf8").trim().split("\n").slice(1).map(l => l.split(","));
  console.log(`\n肥肉機會（|年化|≥30%）: ${fat.length} 筆次 | 頻率 ${(fat.length/hours).toFixed(1)} 筆/小時`);
  const bySym = {};
  for (const f of fat) bySym[f[2]] = (bySym[f[2]]||0)+1;
  const top = Object.entries(bySym).sort((a,b)=>b[1]-a[1]).slice(0,8);
  console.log("最常出現肥肉的幣種（出現次數=持續小時數）:");
  for (const [s,n] of top) console.log(`  ${s.padEnd(14)} ${n} 小時`);
} else {
  console.log("\n尚無肥肉紀錄（|年化|≥30% 的機會還沒出現過）");
}
console.log("\n判讀基準: 主流幣平均年化<5%且肥肉稀少→租金太薄 | 5-10%→可配$3,000驗證 | 肥肉每日多次且持續→輪動策略有肉");
