#!/usr/bin/env node
/* ============================================================
   whale-bot v1.0 — 幼鯨雷達 VPS 版(少年期鯨魚 paper trading)
   Node 18+ · 零依賴 · 與 sol-meme-bot 完全隔離(獨立目錄/資料)
   用法:
     node bot.js daily    # 每日主循環:掃描→建檔→快照→確認→虛擬進場→持倉管理
     node bot.js patrol   # 每小時輕巡:持倉流動性驟降急殺
     node bot.js status   # 人類可讀的現況摘要
   ============================================================ */
'use strict';
const fs = require('fs');
const path = require('path');

const DIR = __dirname;
const CFG = JSON.parse(fs.readFileSync(path.join(DIR, 'config.json'), 'utf8'));
const LEECH = new RegExp(CFG.veto.leechKeywords, 'i');

const GT = 'https://api.geckoterminal.com/api/v2';
const DS = 'https://api.dexscreener.com';
const RUG = 'https://api.rugcheck.xyz/v1';

/* ---------- 儲存 ---------- */
const STATE_FILE = path.join(DIR, 'state.json');
const state = fs.existsSync(STATE_FILE)
  ? JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'))
  : { watch: {}, positions: {}, closed: [] };
const saveState = () => fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
const jsonl = (file, obj) =>
  fs.appendFileSync(path.join(DIR, file),
    JSON.stringify({ ts: new Date().toISOString(), cfg: CFG.configVersion, ...obj }) + '\n');
const say = m => console.log(new Date().toISOString().slice(11, 19), m);

/* ---------- HTTP ---------- */
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function jget(url) {
  for (let i = 0; i <= CFG.http.retries; i++) {
    try {
      const r = await fetch(url, { headers: { accept: 'application/json' } });
      if (r.status === 429) { await sleep(3000 * (i + 1)); continue; }
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return await r.json();
    } catch (e) { if (i === CFG.http.retries) throw e; await sleep(1200); }
  }
}
async function notify(text) {
  jsonl('alerts.log', { text });
  say('🔔 ' + text);
  if (CFG.notify.webhookUrl) {
    try {
      await fetch(CFG.notify.webhookUrl, {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ text })
      });
    } catch (e) { /* 通知失敗不影響主流程 */ }
  }
}

/* ---------- 少年期評分(與網頁版同源)---------- */
function scoreJuvenile(t) {
  const s = { liq: 0, turn: 0, buy: 0, mom: 0, res: 0, age: 0 };
  const flags = []; let cap = 100;
  const ratio = t.mcap > 0 ? t.liq / t.mcap : 0;
  const vr = t.mcap > 0 ? t.vol24 / t.mcap : 0;

  if (t.liq >= 150000) s.liq += 15; else if (t.liq >= 100000) s.liq += 12;
  else if (t.liq >= 60000) s.liq += 9; else if (t.liq >= 30000) s.liq += 5;
  if (ratio >= 0.12) s.liq += 10; else if (ratio >= 0.08) s.liq += 7; else if (ratio >= 0.05) s.liq += 4;
  if (t.liq < CFG.veto.liqHardFloorUSD) { cap = Math.min(cap, 59); flags.push('liq-veto'); }
  else if (ratio < CFG.veto.shallowLiqMcapRatio) { cap = Math.min(cap, 69); flags.push('shallow'); }

  if (vr >= 0.3 && vr <= 3) s.turn = 15;
  else if ((vr >= 0.15 && vr < 0.3) || (vr > 3 && vr <= 5)) s.turn = 9;
  else if (vr > 5 && vr <= 8) s.turn = 4;
  if (vr > CFG.veto.washTurnoverX) { cap = Math.min(cap, 59); flags.push('wash'); }

  const b24 = t.tx24.b + t.tx24.s > 0 ? t.tx24.b / (t.tx24.b + t.tx24.s) : 0;
  const b1 = t.tx1.b + t.tx1.s > 0 ? t.tx1.b / (t.tx1.b + t.tx1.s) : 0;
  if (b24 >= 0.55) s.buy += 9; else if (b24 >= 0.5) s.buy += 6; else if (b24 >= 0.45) s.buy += 3;
  if (b1 >= 0.55) s.buy += 6; else if (b1 >= 0.5) s.buy += 4; else if (b1 >= 0.45) s.buy += 2;

  if (t.h24 >= 0 && t.h24 <= 120) s.mom += 6; else if (t.h24 > -25 && t.h24 < 0) s.mom += 3;
  if (t.h6 >= -5) s.mom += 5;
  if (t.h1 >= -3) s.mom += 4;

  s.res = t.resilience != null ? t.resilience : ((t.h24 >= -20 && t.h24 <= 150) ? 8 : 4);
  s.age = (t.ageD >= 5 && t.ageD <= 21) ? 10 : 6;

  if (LEECH.test(t.name + ' ' + t.sym)) { cap = Math.min(cap, 65); flags.push('leech'); }

  let total = s.liq + s.turn + s.buy + s.mom + s.res + s.age;
  if (total > cap) total = cap;
  const grade = total >= 85 ? 'S' : total >= 75 ? 'A' : total >= 65 ? 'B' : total >= 50 ? 'C' : 'D';
  return { total, grade, s, flags };
}

/* ---------- 掃描 ---------- */
async function scanPools() {
  const urls = [];
  for (let p = 1; p <= CFG.filter.gtTrendingPages; p++) urls.push(`${GT}/networks/solana/trending_pools?page=${p}`);
  for (let p = 1; p <= CFG.filter.gtTopPoolPages; p++) urls.push(`${GT}/networks/solana/pools?page=${p}`);
  let pools = [];
  for (const u of urls) {
    try { const j = await jget(u); pools = pools.concat(j.data || []); } catch (e) { say('掃描頁失敗 ' + e.message); }
    await sleep(CFG.http.delayMs);
  }
  const byMint = {};
  for (const p of pools) {
    const a = p.attributes || {};
    const mint = ((p.relationships?.base_token?.data?.id) || '').replace('solana_', '');
    if (!mint) continue;
    const liq = +a.reserve_in_usd || 0;
    const mcap = +(a.market_cap_usd ?? a.fdv_usd) || 0;
    const ageD = a.pool_created_at ? (Date.now() - new Date(a.pool_created_at)) / 864e5 : 0;
    const t = {
      mint, pool: (p.id || '').replace('solana_', ''),
      name: (a.name || '').split(' / ')[0], sym: (a.name || '').split(' / ')[0],
      price: +a.base_token_price_usd || 0, liq, mcap,
      vol24: +(a.volume_usd?.h24) || 0, ageD,
      h1: +(a.price_change_percentage?.h1) || 0,
      h6: +(a.price_change_percentage?.h6) || 0,
      h24: +(a.price_change_percentage?.h24) || 0,
      tx24: { b: +(a.transactions?.h24?.buys) || 0, s: +(a.transactions?.h24?.sells) || 0 },
      tx1: { b: +(a.transactions?.h1?.buys) || 0, s: +(a.transactions?.h1?.sells) || 0 },
      resilience: null
    };
    if (!byMint[mint] || byMint[mint].liq < liq) byMint[mint] = t;
  }
  const F = CFG.filter;
  return Object.values(byMint).filter(t =>
    t.ageD >= F.ageMinDays && t.ageD <= F.ageMaxDays &&
    t.liq >= Math.min(F.liqMinUSD, CFG.veto.liqHardFloorUSD) &&
    t.mcap >= F.mcapMinUSD && t.mcap <= F.mcapMaxUSD);
}

/* ---------- 快照(DexScreener 單幣即時)---------- */
async function tokenSnap(mint) {
  const j = await jget(`${DS}/latest/dex/tokens/${mint}`);
  const p = (j.pairs || []).filter(x => x.chainId === 'solana')
    .sort((a, b) => (+b.liquidity?.usd || 0) - (+a.liquidity?.usd || 0))[0];
  if (!p) return null;
  return {
    ts: Date.now(), pool: p.pairAddress,
    price: +p.priceUsd || 0,
    mcap: +p.marketCap || +p.fdv || 0,
    liq: +p.liquidity?.usd || 0,
    vol: +p.volume?.h24 || 0
  };
}
async function rugTop10(mint) {
  try {
    const j = await jget(`${RUG}/tokens/${mint}/report`);
    return (j.topHolders || []).slice(0, 10).reduce((a, h) => a + (+h.pct || 0), 0);
  } catch (e) { return null; }
}
async function resilienceCheck(pool) {
  try {
    const j = await jget(`${GT}/networks/solana/pools/${pool}/ohlcv/day?aggregate=1&limit=100`);
    const cs = (j.data?.attributes?.ohlcv_list || []).slice().sort((a, b) => a[0] - b[0]);
    if (cs.length < 3) return { ok: false, note: '日K不足' };
    const closes = cs.map(c => +c[4]); const highs = cs.map(c => +c[2]);
    const ath = Math.max(...highs);
    let peak = closes[0], maxDD = 0;
    for (const c of closes) { peak = Math.max(peak, c); maxDD = Math.max(maxDD, (peak - c) / peak * 100); }
    const fromATH = closes[closes.length - 1] / ath;
    const survived = maxDD >= 40 && fromATH >= 0.5;
    const young = maxDD < 40 && cs.length < 7;      // 還沒摔過的太年輕者給緩衝
    return { ok: survived || young, maxDD, fromATH, note: survived ? '摔過已收復' : young ? '尚未經歷大回撤(年輕緩衝)' : '回撤未收復' };
  } catch (e) { return { ok: false, note: 'OHLCV失敗' }; }
}

/* ---------- 確認清單(五項)---------- */
function trendPct(a, b) { return a > 0 ? (b - a) / a * 100 : 0; }
async function runConfirm(mint, w) {
  const C = CFG.confirm;
  const sn = w.snaps;
  const first = sn[0], last = sn[sn.length - 1], prev = sn[sn.length - 2];
  const checks = {};
  // 1. 流動性趨勢
  const liqT = trendPct(first.liq, last.liq);
  const liqDrop1 = prev ? trendPct(prev.liq, last.liq) : 0;
  checks.liqTrend = liqT >= C.liqTrendMinPct && liqDrop1 > C.liqSingleDropVetoPct;
  // 2. 市值/流動性同步
  checks.liqMcapSync = last.mcap > 0 && (last.liq / last.mcap) >= C.minLiqMcapRatio;
  // 3. 籌碼:前十占比不升且未過上限
  const top10 = await rugTop10(mint); await sleep(CFG.http.delayMs);
  if (top10 != null) {
    w.top10Hist = w.top10Hist || [];
    w.top10Hist.push({ ts: Date.now(), pct: top10 });
    const t0 = w.top10Hist[0].pct;
    checks.chips = top10 <= C.top10MaxPct && (top10 - t0) <= C.top10RiseVetoPct;
  } else checks.chips = true;   // 無資料視為中性
  // 4. 量能仍活著
  checks.turnover = last.mcap > 0 && (last.vol / last.mcap) >= C.minTurnoverX;
  // 5. 存活韌性(日K)
  const res = await resilienceCheck(last.pool); await sleep(CFG.http.delayMs);
  checks.resilience = res.ok;

  const passCount = Object.values(checks).filter(Boolean).length;
  return { pass: passCount >= C.requirePassCount, passCount, checks, top10, resNote: res.note };
}

/* ---------- 虛擬持倉管理 ---------- */
function openPosition(mint, w, snap, confirm) {
  state.positions[mint] = {
    name: w.name, entry: snap.price, entryLiq: snap.liq, entryTs: Date.now(),
    sizeUSD: CFG.paper.positionSizeUSD, remainPct: 100,
    peak: snap.price, principalOut: false, nextLadderX: CFG.paper.ladderFirstX,
    pool: snap.pool
  };
  jsonl('trades.jsonl', { ev: 'OPEN', mint, name: w.name, price: snap.price, liq: snap.liq, mcap: snap.mcap, confirm });
  notify(`🐋 虛擬進場 ${w.name} @ $${snap.price} (確認 ${confirm.passCount}/5)`);
}
function realize(pos, pct, price, reason, mint) {
  const part = pos.remainPct * pct / 100;
  const pnlX = pos.entry > 0 ? price / pos.entry : 0;
  pos.remainPct -= part;
  jsonl('trades.jsonl', { ev: 'TAKE', mint, name: pos.name, price, pctOfPosition: +part.toFixed(1), atX: +pnlX.toFixed(2), reason });
}
function closePosition(mint, price, reason) {
  const pos = state.positions[mint];
  const pnlX = pos.entry > 0 ? price / pos.entry : 0;
  jsonl('trades.jsonl', { ev: 'CLOSE', mint, name: pos.name, price, atX: +pnlX.toFixed(2), remainPct: +pos.remainPct.toFixed(1), reason });
  state.closed.push({ mint, name: pos.name, entry: pos.entry, exit: price, atX: +pnlX.toFixed(2), reason, ts: Date.now() });
  delete state.positions[mint];
  notify(`🏁 平倉 ${pos.name} @ ${pnlX.toFixed(2)}x(${reason})`);
}
function managePosition(mint, pos, snap) {
  const E = CFG.eliminate, P = CFG.paper;
  const price = snap.price;
  pos.peak = Math.max(pos.peak, price);
  const x = pos.entry > 0 ? price / pos.entry : 0;

  // 出場階梯
  if (!pos.principalOut && x >= P.ladderFirstX) {
    realize(pos, P.ladderFirstTakePct / P.ladderFirstX * 10, price, '10x出本金', mint); // 出 1/10x 對應本金
    pos.principalOut = true; pos.nextLadderX = P.ladderFirstX * P.ladderStepX;
    notify(`🎉 ${pos.name} 達 ${P.ladderFirstX}x,本金已出,剩餘為免費彩券`);
  } else if (pos.principalOut && x >= pos.nextLadderX) {
    realize(pos, P.ladderStepTakePct, price, pos.nextLadderX + 'x階梯', mint);
    pos.nextLadderX *= P.ladderStepX;
  }
  // 淘汰訊號
  if (trendPct(pos.entryLiq, snap.liq) <= E.liqDropFromEntryPct) return closePosition(mint, price, '流動性較進場縮水');
  if (snap.mcap > 0 && snap.vol / snap.mcap < E.turnoverDeadX) return closePosition(mint, price, '量能熄火');
  if (pos.peak > 0 && trendPct(pos.peak, price) <= E.priceFromPeakPct) return closePosition(mint, price, '自峰值深跌');
}

/* ---------- 每日主循環 ---------- */
async function daily() {
  say(`=== whale-bot daily (${CFG.configVersion}) ===`);
  // 1. 掃描 + S/A 自動建檔
  const list = await scanPools();
  for (const t of list) t.score = scoreJuvenile(t);
  const cands = list.filter(t => ['S', 'A'].includes(t.score.grade));
  jsonl('scan.jsonl', { pools: list.length, candidates: cands.map(t => ({ mint: t.mint, name: t.name, score: t.score.total, grade: t.score.grade, flags: t.score.flags })) });
  for (const t of cands) {
    if (!state.watch[t.mint] && !state.positions[t.mint]) {
      state.watch[t.mint] = { name: t.name, addedAt: Date.now(), auto: true, snaps: [] };
      say(`⚡ 自動建檔 ${t.name} (${t.score.total}/${t.score.grade})`);
    }
  }
  say(`掃描:通過篩選 ${list.length},S/A 候選 ${cands.length}`);

  // 2. 全名單刷快照
  for (const [mint, w] of Object.entries(state.watch)) {
    const snap = await tokenSnap(mint); await sleep(CFG.http.delayMs);
    if (!snap) { w.missCount = (w.missCount || 0) + 1; if (w.missCount >= 3) { delete state.watch[mint]; say(`🗑 ${w.name} 連續無資料,移除`); } continue; }
    w.missCount = 0;
    w.snaps.push(snap);
    jsonl('snapshots.jsonl', { mint, name: w.name, ...snap });
  }

  // 3. 觀察期滿者跑確認清單
  const C = CFG.confirm;
  for (const [mint, w] of Object.entries(state.watch)) {
    const days = (Date.now() - w.addedAt) / 864e5;
    if (w.snaps.length < C.minSnapshots || days < C.minWatchDays) continue;
    if (days > C.maxWatchDays) {
      jsonl('trades.jsonl', { ev: 'EXPIRE', mint, name: w.name, days: +days.toFixed(1) });
      delete state.watch[mint]; say(`⌛ ${w.name} 觀察逾期未確認,移除`); continue;
    }
    if (Object.keys(state.positions).length >= CFG.paper.maxOpenPositions) break;
    const confirm = await runConfirm(mint, w);
    jsonl('confirm.jsonl', { mint, name: w.name, ...confirm });
    if (confirm.pass) {
      const snap = w.snaps[w.snaps.length - 1];
      openPosition(mint, w, snap, confirm);
      delete state.watch[mint];
    } else {
      // 硬性淘汰:流動性趨勢崩壞直接踢出名單
      if (!confirm.checks.liqTrend) { delete state.watch[mint]; say(`🗑 ${w.name} 流動性趨勢淘汰`); }
      else say(`⏳ ${w.name} 確認 ${confirm.passCount}/5,續觀察`);
    }
  }

  // 4. 持倉管理
  for (const [mint, pos] of Object.entries(state.positions)) {
    const snap = await tokenSnap(mint); await sleep(CFG.http.delayMs);
    if (!snap) continue;
    pos.lastLiq = snap.liq;
    managePosition(mint, pos, snap);
  }
  saveState();
  say(`名單 ${Object.keys(state.watch).length} · 持倉 ${Object.keys(state.positions).length} · 已平倉 ${state.closed.length}`);
}

/* ---------- 每小時輕巡:池子被抽急殺 ---------- */
async function patrol() {
  const mints = Object.keys(state.positions);
  if (!mints.length) return;
  for (const mint of mints) {
    const pos = state.positions[mint];
    const snap = await tokenSnap(mint); await sleep(CFG.http.delayMs);
    if (!snap) continue;
    const ref = pos.lastLiq || pos.entryLiq;
    if (ref > 0 && trendPct(ref, snap.liq) <= CFG.eliminate.patrolLiqCrashPct) {
      await notify(`🚨 ${pos.name} 池子驟降 ${trendPct(ref, snap.liq).toFixed(0)}%,急殺平倉`);
      closePosition(mint, snap.price, '巡邏:流動性驟降');
    } else pos.lastLiq = snap.liq;
  }
  saveState();
}

/* ---------- 現況摘要 ---------- */
function status() {
  console.log(`\n🐋 whale-bot 現況(config ${CFG.configVersion})`);
  console.log(`\n📁 觀察名單 ${Object.keys(state.watch).length}:`);
  for (const [m, w] of Object.entries(state.watch)) {
    const d = ((Date.now() - w.addedAt) / 864e5).toFixed(1);
    const s0 = w.snaps[0], s1 = w.snaps[w.snaps.length - 1];
    const lt = s0 && s1 ? trendPct(s0.liq, s1.liq).toFixed(0) + '%' : '—';
    console.log(`  ${w.name.padEnd(12)} ${d}天 快照${w.snaps.length} 流動性趨勢 ${lt}  ${m.slice(0, 6)}…`);
  }
  console.log(`\n💼 虛擬持倉 ${Object.keys(state.positions).length}:`);
  for (const [m, p] of Object.entries(state.positions))
    console.log(`  ${p.name.padEnd(12)} 進場 $${p.entry}  峰值 ${(p.peak / p.entry).toFixed(2)}x  剩餘 ${p.remainPct.toFixed(0)}%`);
  console.log(`\n🏁 已平倉 ${state.closed.length}:`);
  for (const c of state.closed.slice(-15))
    console.log(`  ${c.name.padEnd(12)} ${String(c.atX).padStart(6)}x  ${c.reason}`);
  const xs = state.closed.map(c => c.atX);
  if (xs.length) {
    const avg = xs.reduce((a, b) => a + b, 0) / xs.length;
    const win = xs.filter(x => x >= 1).length;
    console.log(`\n📐 平倉統計:n=${xs.length} 平均 ${avg.toFixed(2)}x 勝率 ${(win / xs.length * 100).toFixed(0)}%(冪律遊戲,平均比勝率重要)`);
  }
  console.log('');
}

/* ---------- 入口 ---------- */
(async () => {
  const cmd = process.argv[2];
  try {
    if (cmd === 'daily') await daily();
    else if (cmd === 'patrol') await patrol();
    else if (cmd === 'status') status();
    else console.log('用法: node bot.js daily | patrol | status');
  } catch (e) {
    jsonl('alerts.log', { text: 'FATAL ' + e.message });
    console.error('FATAL', e);
    process.exit(1);
  }
})();
