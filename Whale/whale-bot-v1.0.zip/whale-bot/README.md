# whale-bot v1.0 — 幼鯨雷達 VPS 版(少年期 Paper Trading)

零依賴 Node.js(需 Node 18+,內建 fetch)。與 sol-meme-bot 完全隔離:獨立目錄、獨立 process、獨立資料檔,唯一共同點是同一台機器。

## 部署(Vultr VPS)

```bash
# 1. 上傳(在本機執行,路徑自行調整)
scp -r whale-bot root@你的VPS:/root/whale-bot

# 2. VPS 上確認 Node 版本 ≥ 18
node --version

# 3. 手動跑一次確認能通
cd /root/whale-bot
node bot.js daily
node bot.js status
```

## 排程(crontab -e)

VPS 通常是 UTC,台灣 = UTC+8。以下設定為台灣時間每天 09:10 與 21:10 跑主循環,每小時 05 分輕巡:

```cron
10 1,13 * * * cd /root/whale-bot && /usr/bin/node bot.js daily  >> cron.log 2>&1
5  *    * * * cd /root/whale-bot && /usr/bin/node bot.js patrol >> cron.log 2>&1
```

## 每日循環做的事(daily)

1. 掃描 GeckoTerminal 熱門池 → 少年期篩選(3–30 天、市值/流動性門檻)→ 評分
2. S/A 級自動建檔進觀察名單,開始累積快照
3. 全名單刷每日快照(寫入 `snapshots.jsonl`)
4. 觀察滿 3 天且快照 ≥3 筆者跑**五項確認清單**:
   流動性趨勢 / 市值流動性同步 / 籌碼分散(RugCheck)/ 量能存活 / 回撤韌性(日K)
   → 過 4 項即虛擬進場;流動性趨勢崩壞直接淘汰;逾 10 天未確認自動過期
5. 持倉管理:出場階梯(10x 出本金 → 之後每翻倍出 25%)+ 淘汰訊號
   (流動性較進場 -35% / 量能 vol/mcap < 0.1 / 自峰值 -70%)

## 輕巡(patrol,每小時)

只查持倉標的:池子相較上次驟降 ≥30% → 急殺平倉 + 通知。

## 檔案說明

| 檔案 | 內容 |
|---|---|
| `config.json` | 所有參數。**改參數請同步改 configVersion**,每筆日誌都會蓋版本章,統計時可分版比較 |
| `state.json` | 觀察名單 + 持倉現況(bot 自己維護) |
| `scan.jsonl` | 每輪掃描結果與候選 |
| `snapshots.jsonl` | 每日快照流水 |
| `confirm.jsonl` | 每次確認清單的五項結果 |
| `trades.jsonl` | OPEN / TAKE / CLOSE / EXPIRE 全紀錄 —— **paper 驗證的統計母體** |
| `alerts.log` | 通知紀錄 |

## 通知(可選)

`config.json → notify.webhookUrl` 填入 webhook(Telegram Bot / Discord / LINE Notify 中繼皆可),
急殺、進場、平倉會 POST `{"text": "..."}`;留空則只寫 log。

## 畢業條件(paper → 微額實盤)

- `trades.jsonl` 累積 ≥15 筆完整平倉
- `node bot.js status` 的平均倍數 > 1(冪律遊戲看平均不看勝率)
- 期間你沒有手動干預 state.json 推翻規則

⚠ 僅供研究,不構成投資建議。迷因幣預設結局是歸零。
